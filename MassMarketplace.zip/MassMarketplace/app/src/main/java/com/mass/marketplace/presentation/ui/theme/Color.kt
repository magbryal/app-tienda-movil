package com.mass.marketplace.presentation.ui.theme

import androidx.compose.ui.graphics.Color

// Colores principales de MASS
val MassOrange = Color(0xFFFF9500)
val MassOrangeLight = Color(0xFFFFB347)
val MassOrangeDark = Color(0xFFE8860A)

val MassBlue = Color(0xFF1E3A8A)
val MassBlueLight = Color(0xFF3B82F6)
val MassBlueDark = Color(0xFF1E40AF)

val MassYellow = Color(0xFFFBBF24)
val MassYellowLight = Color(0xFFFDE047)
val MassYellowDark = Color(0xFFF59E0B)

// Colores glassmórficos
val GlassWhite = Color(0x80FFFFFF)
val GlassBlack = Color(0x40000000)
val GlassBlue = Color(0x801E3A8A)
val GlassOrange = Color(0x80FF9500)

// Colores de superficie
val SurfaceLight = Color(0xFFFFFBFE)
val SurfaceDark = Color(0xFF1C1B1F)
val SurfaceVariantLight = Color(0xFFE7E0EC)
val SurfaceVariantDark = Color(0xFF49454F)

// Colores de texto
val OnSurfaceLight = Color(0xFF1C1B1F)
val OnSurfaceDark = Color(0xFFE6E1E5)
val OnSurfaceVariantLight = Color(0xFF49454F)
val OnSurfaceVariantDark = Color(0xFFCAC4D0)

// Gradientes
val MassGradient = listOf(MassOrange, MassYellow)
val BlueGradient = listOf(MassBlue, MassBlueLight)
val SunsetGradient = listOf(MassOrange, Color(0xFFFF6B6B), MassYellow)
val OceanGradient = listOf(MassBlue, Color(0xFF4ECDC4), MassBlueLight)

// Estados
val SuccessColor = Color(0xFF10B981)
val WarningColor = Color(0xFFF59E0B)
val ErrorColor = Color(0xFFEF4444)
val InfoColor = Color(0xFF3B82F6)