package com.mass.marketplace.core.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.data.local.UserInfo
import com.mass.marketplace.domain.repository.CartRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProfileUiState(
    val userInfo: UserInfo? = null,
    val isLoading: Boolean = false,
    val isLoggedOut: Boolean = false,
    val errorMessage: String? = null
)

class ProfileViewModel(
    private val sessionManager: SessionManager,
    private val cartRepository: CartRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        loadUserInfo()
    }

    private fun loadUserInfo() {
        viewModelScope.launch {
            try {
                val userInfo = sessionManager.getUserInfo()
                _uiState.value = _uiState.value.copy(
                    userInfo = userInfo
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al cargar información del usuario"
                )
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isLoading = true)

                // Limpiar carrito
                cartRepository.clearCart()

                // Limpiar sesión
                sessionManager.clearSession()

                // Marcar como deslogueado
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isLoggedOut = true,
                    userInfo = null
                )

                println("ProfileViewModel: Logout completado exitosamente")

            } catch (e: Exception) {
                println("ProfileViewModel: Error durante logout: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al cerrar sesión: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun resetLogoutState() {
        _uiState.value = _uiState.value.copy(isLoggedOut = false)
    }
}
