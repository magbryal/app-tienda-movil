package com.mass.marketplace.presentation.ui.screens.auth

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.mass.marketplace.R
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    onNavigateToHome: () -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(key1 = true) {
        isVisible = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.3f),
                        MassBlue.copy(alpha = 0.4f),
                        MassYellow.copy(alpha = 0.2f)
                    ),
                    radius = 1000f
                )
            )
    ) {
        // Animated background elements
        AnimatedBackgroundElements(isVisible = isVisible)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(60.dp))

            // Logo and title
            AuthHeader(isVisible = isVisible)

            Spacer(modifier = Modifier.height(40.dp))

            // Tab selector
            AuthTabSelector(
                selectedTab = pagerState.currentPage,
                onTabSelected = { tab ->
                    scope.launch {
                        pagerState.animateScrollToPage(tab)
                    }
                },
                isVisible = isVisible
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Pager content
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                when (page) {
                    0 -> LoginForm(
                        onNavigateToHome = onNavigateToHome,
                        isVisible = isVisible
                    )
                    1 -> RegisterForm(
                        onNavigateToHome = onNavigateToHome,
                        isVisible = isVisible
                    )
                }
            }
        }
    }
}

@Composable
private fun AnimatedBackgroundElements(isVisible: Boolean) {
    rememberInfiniteTransition(label = "background")

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 0.6f else 0f,
        animationSpec = tween(2000),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .alpha(alpha)
    ) {
        // Floating elements
        repeat(6) { index ->
            val size = (60 + index * 20).dp
            val offsetX = (index * 80).dp
            val offsetY = (index * 120).dp

            Box(
                modifier = Modifier
                    .offset(x = offsetX, y = offsetY)
                    .size(size)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.1f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(50)
                    )
                    .blur(20.dp)
            )
        }
    }
}

@Composable
private fun AuthHeader(isVisible: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.8f,
        animationSpec = tween(800, easing = FastOutSlowInEasing),
        label = "scale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.alpha(if (isVisible) 1f else 0f)
    ) {
        // Logo
        GlassmorphicCard(
            modifier = Modifier
                .size(100.dp)
                .scale(scale),
            alpha = 1f,
            cornerRadius = 50.dp
        ) {
            Box(
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_mass_logo),
                    contentDescription = "MASS Logo",
                    modifier = Modifier
                        .size(96.dp)
                        .clip(RoundedCornerShape(24.dp)),
                    contentScale = ContentScale.Fit
                )
            }
        }
    }
}

@Composable
private fun AuthTabSelector(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600, delayMillis = 300),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .alpha(alpha),
        alpha = 0.2f
    ) {
        Row(
            modifier = Modifier.fillMaxSize()
        ) {
            AuthTab(
                text = "Iniciar Sesión",
                isSelected = selectedTab == 0,
                onClick = { onTabSelected(0) },
                modifier = Modifier.weight(1f)
            )

            AuthTab(
                text = "Registrarse",
                isSelected = selectedTab == 1,
                onClick = { onTabSelected(1) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun AuthTab(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor by animateColorAsState(
        targetValue = if (isSelected) MassOrange.copy(alpha = 0.3f) else Color.Transparent,
        animationSpec = tween(300),
        label = "backgroundColor"
    )

    Box(
        modifier = modifier
            .fillMaxHeight()
            .background(
                color = backgroundColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = if (isSelected) androidx.compose.ui.text.font.FontWeight.Bold
                else androidx.compose.ui.text.font.FontWeight.Normal
            )
        )
    }
}
