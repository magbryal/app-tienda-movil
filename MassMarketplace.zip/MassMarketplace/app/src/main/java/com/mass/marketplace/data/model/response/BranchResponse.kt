package com.mass.marketplace.data.model.response

import com.google.gson.annotations.SerializedName
import com.mass.marketplace.domain.model.Branch

data class BranchResponse(
    @SerializedName("branch_id")
    val id: Int,

    @SerializedName("name")
    val name: String,

    @SerializedName("address")
    val address: String,

    @SerializedName("phone")
    val phone: String,

    @SerializedName("schedule")
    val schedule: String,

    @SerializedName("latitude")
    val latitude: Double,

    @SerializedName("longitude")
    val longitude: Double,

    @SerializedName("is_active")
    val isActive: Boolean,

    @SerializedName("created_at")
    val createdAt: String? = null,

    @SerializedName("updated_at")
    val updatedAt: String? = null,

    // Nuevos campos opcionales
    @SerializedName("email")
    val email: String? = null,

    @SerializedName("description")
    val description: String? = null,

    @SerializedName("opening_hours")
    val openingHours: String? = null,

    @SerializedName("manager_id")
    val managerId: Int? = null,

    @SerializedName("capacity")
    val capacity: Int? = null,

    @SerializedName("has_parking")
    val hasParking: Boolean? = null,

    @SerializedName("has_wifi")
    val hasWifi: Boolean? = null,

    @SerializedName("has_accessibility")
    val hasAccessibility: Boolean? = null,

    @SerializedName("is_24_hours")
    val is24Hours: Boolean? = null,

    @SerializedName("has_drive_through")
    val hasDriveThrough: Boolean? = null,

    @SerializedName("rating")
    val rating: Double? = null
)

fun BranchResponse.toDomain(): Branch {
    return Branch(
        id = this.id,
        name = this.name,
        address = this.address,
        phone = this.phone,
        schedule = this.schedule,
        latitude = this.latitude,
        longitude = this.longitude,
        isActive = this.isActive,
        createdAt = this.createdAt ?: "",
        updatedAt = this.updatedAt ?: "",
        email = this.email,
        description = this.description,
        openingHours = this.openingHours,
        managerId = this.managerId,
        capacity = this.capacity,
        hasParking = this.hasParking,
        hasWifi = this.hasWifi,
        hasAccessibility = this.hasAccessibility,
        is24Hours = this.is24Hours,
        hasDriveThrough = this.hasDriveThrough,
        rating = this.rating
    )
}