package com.mass.marketplace.domain.usecase.auth

import com.mass.marketplace.domain.repository.AuthRepository

class RegisterUseCase(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(
        name: String,
        lastName: String,
        email: String,
        password: String,
        phone: String,
        address: String
    ) = authRepository.register(name, lastName, email, password, phone, address)
}
