package com.mass.marketplace.data.model.request

data class OrderItemRequest(
    val order_id: Int,
    val product_id: Int,
    val quantity: Int,
    val unit_price: Double,
    val subtotal: Double
)
