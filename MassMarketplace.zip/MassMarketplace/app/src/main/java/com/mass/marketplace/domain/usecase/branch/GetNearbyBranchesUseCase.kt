package com.mass.marketplace.domain.usecase.branch

import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.repository.BranchRepository

class GetNearbyBranchesUseCase(
    private val branchRepository: BranchRepository
) {
    suspend operator fun invoke(
        userLatitude: Double,
        userLongitude: Double,
        maxDistanceKm: Double = 10.0
    ): Result<List<Branch>> {
        return branchRepository.getNearbyBranches(
            latitude = userLatitude,
            longitude = userLongitude,
            radiusKm = maxDistanceKm
        )
    }
}