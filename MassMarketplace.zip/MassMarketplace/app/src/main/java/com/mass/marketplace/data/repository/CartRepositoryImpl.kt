package com.mass.marketplace.data.repository

import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.domain.repository.CartRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class CartRepositoryImpl : CartRepository {
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())

    override fun getCartItems(): Flow<List<CartItem>> = _cartItems.asStateFlow()

    override suspend fun addToCart(item: CartItem) {
        val currentItems = _cartItems.value.toMutableList()
        val existingItemIndex = currentItems.indexOfFirst { it.productId == item.productId }

        if (existingItemIndex >= 0) {
            // Si el producto ya existe, aumentar cantidad
            val existingItem = currentItems[existingItemIndex]
            val newQuantity = (existingItem.quantity + item.quantity).coerceAtMost(item.maxStock)
            currentItems[existingItemIndex] = existingItem.copy(
                quantity = newQuantity,
                subtotal = existingItem.unitPrice * newQuantity
            )
            println("Producto existente actualizado: ${existingItem.productName}, nueva cantidad: $newQuantity")
        } else {
            // Si es un producto nuevo, agregarlo como nuevo item
            val newItem = item.copy(
                id = generateCartItemId(), // Generar ID único para el cart item
                subtotal = item.unitPrice * item.quantity
            )
            currentItems.add(newItem)
            println("Nuevo producto agregado: ${newItem.productName}, cantidad: ${newItem.quantity}")
        }

        _cartItems.value = currentItems
        println("Total items en carrito: ${currentItems.size}")
        println("Total productos: ${currentItems.sumOf { it.quantity }}")
    }

    override suspend fun removeFromCart(productId: Int) {
        val beforeCount = _cartItems.value.size
        _cartItems.value = _cartItems.value.filter { it.productId != productId }
        val afterCount = _cartItems.value.size
        println("Producto removido. Items antes: $beforeCount, después: $afterCount")
    }

    override suspend fun updateQuantity(productId: Int, quantity: Int) {
        val currentItems = _cartItems.value.toMutableList()
        val itemIndex = currentItems.indexOfFirst { it.productId == productId }

        if (itemIndex >= 0) {
            if (quantity <= 0) {
                currentItems.removeAt(itemIndex)
                println("Producto removido por cantidad 0: $productId")
            } else {
                val item = currentItems[itemIndex]
                val newQuantity = quantity.coerceAtMost(item.maxStock)
                currentItems[itemIndex] = item.copy(
                    quantity = newQuantity,
                    subtotal = item.unitPrice * newQuantity
                )
                println("Cantidad actualizada para ${item.productName}: $newQuantity")
            }
            _cartItems.value = currentItems
        }
    }

    override suspend fun clearCart() {
        val itemCount = _cartItems.value.size
        _cartItems.value = emptyList()
        println("Carrito limpiado. Se removieron $itemCount items")
    }

    override suspend fun getCartTotal(): Double {
        return _cartItems.value.sumOf { it.subtotal }
    }

    override suspend fun getCartItemCount(): Int {
        return _cartItems.value.sumOf { it.quantity }
    }

    private fun generateCartItemId(): String {
        return "cart_${System.currentTimeMillis()}_${(1000..9999).random()}"
    }
}
