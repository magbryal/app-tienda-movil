package com.mass.marketplace.data.model.response

import com.mass.marketplace.presentation.ui.screens.home.Product

data class ProductResponse(
    val product_id: Int,
    val name: String,
    val description: String,
    val category_id: Int,
    val price: Double,
    val sale_price: Double?,
    val barcode: String,
    val brand: String,
    val stock: Int,
    val main_image: String,
    val created_at: String,
    val updated_at: String
)

// Extensión para convertir a modelo de dominio
fun ProductResponse.toDomain(): Product {
    val uniqueId = "${this.product_id}_${System.currentTimeMillis()}_${(1000..9999).random()}"

    println("📦 Producto mapeado: Backend ID=${this.product_id}, Unique ID=$uniqueId, Name=${this.name}")

    return Product(
        id = this.product_id,
        name = this.name,
        price = this.sale_price ?: this.price,
        originalPrice = if (this.sale_price != null) this.price else null,
        imageUrl = this.main_image,
        store = this.brand,
        rating = (4.0f + (Math.random() * 1.0f)).toFloat(),
        distance = "${(0.5 + Math.random() * 3.0).format(1)} km",
        description = this.description,
        stock = this.stock,
        barcode = this.barcode,
        categoryId = this.category_id
    )
}

private fun Double.format(digits: Int) = "%.${digits}f".format(this)
