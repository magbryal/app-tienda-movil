package com.mass.marketplace.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

// Extensión para crear DataStore
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mass_session")

class SessionManager(private val context: Context) {

    companion object {
        private val KEY_ACCESS_TOKEN = stringPreferencesKey("access_token")
        private val KEY_REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        private val KEY_USER_ID = stringPreferencesKey("user_id")
        private val KEY_USER_EMAIL = stringPreferencesKey("user_email")
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        private val KEY_LAST_LOGIN = longPreferencesKey("last_login")
        private val KEY_TOKEN_EXPIRY = longPreferencesKey("token_expiry")
    }

    suspend fun saveUserSession(
        accessToken: String,
        refreshToken: String,
        userId: String,
        userEmail: String,
        userName: String = "",
        tokenExpiryTime: Long = System.currentTimeMillis() + (24 * 60 * 60 * 1000)
    ) {
        context.dataStore.edit { preferences ->
            preferences[KEY_ACCESS_TOKEN] = accessToken
            preferences[KEY_REFRESH_TOKEN] = refreshToken
            preferences[KEY_USER_ID] = userId
            preferences[KEY_USER_EMAIL] = userEmail
            preferences[KEY_USER_NAME] = userName
            preferences[KEY_IS_LOGGED_IN] = true
            preferences[KEY_LAST_LOGIN] = System.currentTimeMillis()
            preferences[KEY_TOKEN_EXPIRY] = tokenExpiryTime
        }
    }

    suspend fun getAccessToken(): String? {
        val preferences = context.dataStore.data.first()
        return preferences[KEY_ACCESS_TOKEN]
    }

    suspend fun getRefreshToken(): String? {
        val preferences = context.dataStore.data.first()
        return preferences[KEY_REFRESH_TOKEN]
    }

    suspend fun getUserId(): String? {
        val preferences = context.dataStore.data.first()
        return preferences[KEY_USER_ID]
    }

    suspend fun getUserEmail(): String? {
        val preferences = context.dataStore.data.first()
        return preferences[KEY_USER_EMAIL]
    }

    suspend fun getUserName(): String? {
        val preferences = context.dataStore.data.first()
        return preferences[KEY_USER_NAME]
    }

    suspend fun isLoggedIn(): Boolean {
        val preferences = context.dataStore.data.first()
        val hasToken = !preferences[KEY_ACCESS_TOKEN].isNullOrEmpty()
        val isMarkedLoggedIn = preferences[KEY_IS_LOGGED_IN] ?: false
        return hasToken && isMarkedLoggedIn
    }

    suspend fun isTokenValid(): Boolean {
        val preferences = context.dataStore.data.first()
        val tokenExpiry = preferences[KEY_TOKEN_EXPIRY] ?: 0
        val currentTime = System.currentTimeMillis()
        return currentTime < tokenExpiry
    }

    suspend fun hasValidSession(): Boolean {
        return isLoggedIn() && isTokenValid()
    }

    fun observeUserSession(): Flow<UserInfo?> {
        return context.dataStore.data.map { preferences ->
            val isLoggedIn = preferences[KEY_IS_LOGGED_IN] ?: false
            if (isLoggedIn) {
                UserInfo(
                    id = preferences[KEY_USER_ID] ?: "",
                    email = preferences[KEY_USER_EMAIL] ?: "",
                    name = preferences[KEY_USER_NAME] ?: "",
                    isLoggedIn = true
                )
            } else null
        }
    }

    suspend fun updateAccessToken(newToken: String, expiryTime: Long) {
        context.dataStore.edit { preferences ->
            preferences[KEY_ACCESS_TOKEN] = newToken
            preferences[KEY_TOKEN_EXPIRY] = expiryTime
            preferences[KEY_LAST_LOGIN] = System.currentTimeMillis()
        }
    }

    suspend fun clearSession() {
        try {
            println("SessionManager: Limpiando sesión...")
            context.dataStore.edit { preferences ->
                preferences.clear()
            }
            println("SessionManager: Sesión limpiada exitosamente")
        } catch (e: Exception) {
            println("SessionManager: Error al limpiar sesión: ${e.message}")
            throw e
        }
    }

    suspend fun updateLastLogin() {
        context.dataStore.edit { preferences ->
            preferences[KEY_LAST_LOGIN] = System.currentTimeMillis()
        }
    }

    suspend fun getUserInfo(): UserInfo? {
        return if (isLoggedIn()) {
            val preferences = context.dataStore.data.first()
            UserInfo(
                id = preferences[KEY_USER_ID] ?: "",
                email = preferences[KEY_USER_EMAIL] ?: "",
                name = preferences[KEY_USER_NAME] ?: "",
                isLoggedIn = true
            )
        } else null
    }
}

// Data class para información del usuario
data class UserInfo(
    val id: String,
    val email: String,
    val name: String,
    val isLoggedIn: Boolean
)
