package com.mass.marketplace.presentation.ui.screens.profile

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.core.viewmodel.ProfileViewModel
import com.mass.marketplace.presentation.ui.components.buttons.MassButton
import com.mass.marketplace.presentation.ui.components.buttons.MassButtonSize
import com.mass.marketplace.presentation.ui.components.buttons.MassButtonVariant
import com.mass.marketplace.presentation.ui.components.cards.BentoCard
import com.mass.marketplace.presentation.ui.components.cards.BentoRow
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
import com.mass.marketplace.presentation.ui.theme.*
import kotlinx.coroutines.delay
import org.koin.androidx.compose.koinViewModel

data class ProfileMenuItem(
    val title: String,
    val subtitle: String? = null,
    val icon: ImageVector,
    val onClick: () -> Unit,
    val showArrow: Boolean = true,
    val color: Color = MassBlue
)

@Composable
fun ProfileScreen(
    onNavigateBack: () -> Unit,
    onNavigateToAuth: () -> Unit,
    onNavigateToOrders: () -> Unit = {},
    viewModel: ProfileViewModel = koinViewModel()
) {
    var isVisible by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    val uiState by viewModel.uiState.collectAsState()

    // Observar el estado de logout
    LaunchedEffect(uiState.isLoggedOut) {
        if (uiState.isLoggedOut) {
            println("ProfileScreen: Usuario deslogueado, navegando a Auth")
            onNavigateToAuth()
            viewModel.resetLogoutState()
        }
    }

    // Mostrar error si existe
    uiState.errorMessage?.let { error ->
        LaunchedEffect(error) {
            println("ProfileScreen: Error: $error")
            // Aquí podrías mostrar un Snackbar
            delay(3000)
            viewModel.clearError()
        }
    }

    LaunchedEffect(key1 = true) {
        isVisible = true
    }

    val profileMenuItems = remember {
        listOf(
            ProfileMenuItem(
                title = "Mis pedidos",
                subtitle = "Ver historial de compras",
                icon = Icons.Default.ShoppingCart,
                onClick = { onNavigateToOrders() },
                color = MassOrange
            ),
            ProfileMenuItem(
                title = "Favoritos",
                subtitle = "Productos guardados",
                icon = Icons.Default.Favorite,
                onClick = { /* Navigate to favorites */ },
                color = Color.Red
            ),
            ProfileMenuItem(
                title = "Direcciones",
                subtitle = "Gestionar direcciones de entrega",
                icon = Icons.Default.LocationOn,
                onClick = { /* Navigate to addresses */ },
                color = MassBlue
            ),
            ProfileMenuItem(
                title = "Métodos de pago",
                subtitle = "Tarjetas y métodos de pago",
                icon = Icons.Default.CheckCircle,
                onClick = { /* Navigate to payment methods */ },
                color = Color(0xFF10B981)
            ),
            ProfileMenuItem(
                title = "Notificaciones",
                subtitle = "Configurar notificaciones",
                icon = Icons.Default.Notifications,
                onClick = { /* Navigate to notifications */ },
                color = MassYellow
            ),
            ProfileMenuItem(
                title = "Ayuda y soporte",
                subtitle = "Centro de ayuda",
                icon = Icons.Default.Phone,
                onClick = { /* Navigate to help */ },
                color = Color(0xFF8B5CF6)
            ),
            ProfileMenuItem(
                title = "Configuración",
                subtitle = "Preferencias de la app",
                icon = Icons.Default.Settings,
                onClick = { /* Navigate to settings */ },
                color = Color.Gray
            ),
            ProfileMenuItem(
                title = "Cerrar sesión",
                icon = Icons.Default.ExitToApp,
                onClick = { showLogoutDialog = true },
                showArrow = false,
                color = Color.Red
            )
        )
    }

    // Loading overlay
    LoadingOverlay(
        isVisible = uiState.isLoading,
        message = "Cerrando sesión..."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.1f),
                        Color.White,
                        MassBlue.copy(alpha = 0.05f)
                    )
                )
            )
    ) {
        // Header
        ProfileHeader(
            onNavigateBack = onNavigateBack,
            isVisible = isVisible
        )

        // Content
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile info card
            item {
                ProfileInfoCard(
                    userInfo = uiState.userInfo,
                    isVisible = isVisible
                )
            }

            // Stats cards
            item {
                ProfileStatsRow(isVisible = isVisible)
            }

            // Menu items
            items(profileMenuItems.size) { index ->
                val item = profileMenuItems[index]
                ProfileMenuItemCard(
                    item = item,
                    isVisible = isVisible,
                    delay = index * 100
                )
            }

            // App info
            item {
                AppInfoCard(isVisible = isVisible)
            }
        }
    }

    // Logout confirmation dialog
    if (showLogoutDialog) {
        LogoutConfirmationDialog(
            onConfirm = {
                showLogoutDialog = false
                viewModel.logout()
            },
            onDismiss = {
                showLogoutDialog = false
            }
        )
    }
}

@Composable
private fun LogoutConfirmationDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = null,
                    tint = Color.Red,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Cerrar sesión",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            }
        },
        text = {
            Text(
                text = "¿Estás seguro de que quieres cerrar sesión? Se eliminarán todos los datos locales incluyendo tu carrito de compras.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.Gray
                )
            )
        },
        confirmButton = {
            MassButton(
                text = "Cerrar sesión",
                onClick = onConfirm,
                variant = MassButtonVariant.Outline,
                size = MassButtonSize.Small
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = "Cancelar",
                    color = MassBlue
                )
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
private fun ProfileInfoCard(
    userInfo: com.mass.marketplace.data.local.UserInfo?,
    isVisible: Boolean
) {
    val scale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.8f,
        animationSpec = tween(800, delayMillis = 200),
        label = "scale"
    )

    BentoCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .scale(scale),
        gradient = MassGradient
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "👤",
                    fontSize = 32.sp
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // User info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = userInfo?.name?.takeIf { it.isNotEmpty() } ?: "Usuario MASS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = userInfo?.email ?: "usuario@mass.com",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.White.copy(alpha = 0.8f)
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Miembro desde 2024",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.White.copy(alpha = 0.7f)
                    )
                )
            }

            // Status indicator
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(SuccessColor.copy(alpha = 0.2f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "ACTIVO",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}

@Composable
private fun ProfileHeader(
    onNavigateBack: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
            .background(Color.White)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onNavigateBack,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MassOrange.copy(alpha = 0.1f))
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Volver",
                tint = MassOrange
            )
        }

        Text(
            text = "Mi Perfil",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

        IconButton(
            onClick = { /* Edit profile */ },
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MassBlue.copy(alpha = 0.1f))
        ) {
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Editar",
                tint = MassBlue
            )
        }
    }
}

@Composable
private fun ProfileStatsRow(isVisible: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.8f,
        animationSpec = tween(800, delayMillis = 300),
        label = "scale"
    )

    BentoRow(
        modifier = Modifier.scale(scale),
        spacing = 12
    ) {
        // Pedidos
        GlassmorphicCard(
            modifier = Modifier
                .weight(1f)
                .height(100.dp),
            alpha = 0.1f
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "12",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = MassOrange,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Pedidos",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        // Favoritos
        GlassmorphicCard(
            modifier = Modifier
                .weight(1f)
                .height(100.dp),
            alpha = 0.1f
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "8",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = Color.Red,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Favoritos",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        // Reseñas
        GlassmorphicCard(
            modifier = Modifier
                .weight(1f)
                .height(100.dp),
            alpha = 0.1f
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "4.8",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = MassYellow,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = "Rating",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }
    }
}

@Composable
private fun ProfileMenuItemCard(
    item: ProfileMenuItem,
    isVisible: Boolean,
    delay: Int
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600, delayMillis = delay),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .scale(scale)
            .alpha(alpha),
        onClick = {
            isPressed = true
            item.onClick()
        }
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(item.color.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = item.color,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold
                    )
                )
                if (item.subtitle != null) {
                    Text(
                        text = item.subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }

            // Arrow
            if (item.showArrow) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            delay(100)
            isPressed = false
        }
    }
}

@Composable
private fun AppInfoCard(isVisible: Boolean) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600, delayMillis = 800),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
            .padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "MASS Marketplace v1.0.0",
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.Gray
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Términos y condiciones",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MassBlue
                ),
                modifier = Modifier.clickable { /* Navigate to terms */ }
            )

            Text(
                text = " • ",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray
                )
            )

            Text(
                text = "Política de privacidad",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MassBlue
                ),
                modifier = Modifier.clickable { /* Navigate to privacy */ }
            )
        }
    }
}
