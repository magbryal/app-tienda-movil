//package com.mass.marketplace.presentation.ui.screens.branch
//
//import androidx.compose.animation.core.*
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.rememberScrollState
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.foundation.text.KeyboardActions
//import androidx.compose.foundation.text.KeyboardOptions
//import androidx.compose.foundation.verticalScroll
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//import androidx.compose.runtime.*
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.alpha
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.draw.scale
//import androidx.compose.ui.focus.FocusDirection
//import androidx.compose.ui.graphics.Brush
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.platform.LocalFocusManager
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.input.ImeAction
//import androidx.compose.ui.text.input.KeyboardType
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import com.google.android.gms.maps.model.CameraPosition
//import com.google.android.gms.maps.model.LatLng
//import com.google.maps.android.compose.*
//import com.mass.marketplace.core.viewmodel.BranchViewModel
//import com.mass.marketplace.domain.model.Branch
//import com.mass.marketplace.presentation.ui.components.buttons.MassButton
//import com.mass.marketplace.presentation.ui.components.buttons.MassButtonVariant
//import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
//import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
//import com.mass.marketplace.presentation.ui.theme.*
//import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
//import kotlinx.coroutines.launch
//import org.koin.androidx.compose.koinViewModel
//
//// Estados del formulario
//data class BranchFormState(
//    val name: String = "",
//    val address: String = "",
//    val phone: String = "",
//    val email: String = "",
//    val latitude: Double = -12.0464, // Lima por defecto
//    val longitude: Double = -77.0428,
//    val isActive: Boolean = true,
//    val description: String = "",
//    val openingHours: String = "",
//    val managerId: Int? = null,
//    val capacity: Int = 0,
//    val hasParking: Boolean = false,
//    val hasWifi: Boolean = false,
//    val hasAccessibility: Boolean = false
//)
//
//// Errores de validación
//data class BranchFormErrors(
//    val name: String? = null,
//    val address: String? = null,
//    val phone: String? = null,
//    val email: String? = null,
//    val latitude: String? = null,
//    val longitude: String? = null,
//    val description: String? = null,
//    val openingHours: String? = null,
//    val capacity: String? = null
//)
//
//@Composable
//fun BranchCreateEditScreen(
//    branchId: Int? = null, // null para crear, id para editar
//    onNavigateBack: () -> Unit,
//    onBranchSaved: () -> Unit,
//    viewModel: BranchViewModel = koinViewModel()
//) {
//    SetupEdgeToEdge()
//
//    val uiState by viewModel.uiState.collectAsState()
//    var formState by remember { mutableStateOf(BranchFormState()) }
//    var formErrors by remember { mutableStateOf(BranchFormErrors()) }
//    var showMapPicker by remember { mutableStateOf(false) }
//    var showDeleteDialog by remember { mutableStateOf(false) }
//    var currentStep by remember { mutableStateOf(0) }
//
//    val isEditMode = branchId != null
//    val scrollState = rememberScrollState()
//    val focusManager = LocalFocusManager.current
//    val scope = rememberCoroutineScope()
//
//    // Cargar datos si es modo edición
//    LaunchedEffect(branchId) {
//        if (branchId != null) {
//            viewModel.getBranchById(branchId)
//        }
//    }
//
//    // Actualizar formulario cuando se carga la sucursal
//    LaunchedEffect(uiState.selectedBranch) {
//        uiState.selectedBranch?.let { branch ->
//            formState = formState.copy(
//                name = branch.name,
//                address = branch.address,
//                phone = branch.phone,
//                email = branch.email ?: "",
//                latitude = branch.latitude,
//                longitude = branch.longitude,
//                isActive = branch.isActive,
//                description = branch.description ?: "",
//                openingHours = branch.openingHours ?: "",
//                managerId = branch.managerId,
//                capacity = branch.capacity ?: 0,
//                hasParking = branch.hasParking ?: false,
//                hasWifi = branch.hasWifi ?: false,
//                hasAccessibility = branch.hasAccessibility ?: false
//            )
//        }
//    }
//
//    // Manejar mensajes de éxito
//    LaunchedEffect(uiState.successMessage) {
//        if (uiState.successMessage != null) {
//            onBranchSaved()
//            viewModel.clearSuccessMessage()
//        }
//    }
//
//    LoadingOverlay(
//        isVisible = uiState.isLoading || uiState.isLoadingBranchDetail,
//        message = if (isEditMode) "Actualizando sucursal..." else "Creando sucursal..."
//    )
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(
//                brush = Brush.verticalGradient(
//                    colors = listOf(
//                        MassBlue.copy(alpha = 0.1f),
//                        Color.White,
//                        MassOrange.copy(alpha = 0.05f)
//                    )
//                )
//            )
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .windowInsetsPadding(WindowInsets.systemBars)
//        ) {
//            // Header
//            BranchFormHeader(
//                title = if (isEditMode) "Editar Sucursal" else "Nueva Sucursal",
//                subtitle = if (isEditMode) formState.name else "Completa la información",
//                currentStep = currentStep,
//                totalSteps = 3,
//                onNavigateBack = onNavigateBack,
//                onDeleteClick = if (isEditMode) { { showDeleteDialog = true } } else null
//            )
//
//            // Stepper Progress
//            BranchFormStepper(
//                currentStep = currentStep,
//                steps = listOf("Información", "Ubicación", "Configuración"),
//                modifier = Modifier.padding(horizontal = 20.dp)
//            )
//
//            Spacer(modifier = Modifier.height(20.dp))
//
//            // Form Content
//            Column(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .verticalScroll(scrollState)
//                    .padding(horizontal = 20.dp)
//            ) {
//                when (currentStep) {
//                    0 -> BranchBasicInfoStep(
//                        formState = formState,
//                        formErrors = formErrors,
//                        onFormStateChange = { formState = it },
//                        onValidationErrors = { formErrors = it },
//                        focusManager = focusManager
//                    )
//                    1 -> BranchLocationStep(
//                        formState = formState,
//                        formErrors = formErrors,
//                        onFormStateChange = { formState = it },
//                        onOpenMapPicker = { showMapPicker = true }
//                    )
//                    2 -> BranchConfigurationStep(
//                        formState = formState,
//                        onFormStateChange = { formState = it }
//                    )
//                }
//
//                Spacer(modifier = Modifier.height(100.dp))
//            }
//        }
//
//        // Bottom Action Bar
//        BranchFormBottomBar(
//            currentStep = currentStep,
//            totalSteps = 3,
//            isEditMode = isEditMode,
//            isLoading = uiState.isLoading,
//            onPreviousStep = {
//                if (currentStep > 0) currentStep--
//            },
//            onNextStep = {
//                val errors = validateCurrentStep(formState, currentStep)
//                formErrors = errors
//
//                if (hasNoErrors(errors, currentStep)) {
//                    if (currentStep < 2) {
//                        currentStep++
//                    } else {
//                        // Guardar sucursal
//                        saveBranch(formState, branchId, viewModel)
//                    }
//                }
//            },
//            modifier = Modifier.align(Alignment.BottomCenter)
//        )
//    }
//
//    // Map Picker Dialog
//    if (showMapPicker) {
//        BranchMapPickerDialog(
//            initialLocation = LatLng(formState.latitude, formState.longitude),
//            onLocationSelected = { latLng ->
//                formState = formState.copy(
//                    latitude = latLng.latitude,
//                    longitude = latLng.longitude
//                )
//                showMapPicker = false
//            },
//            onDismiss = { showMapPicker = false }
//        )
//    }
//
//    // Delete Confirmation Dialog
//    if (showDeleteDialog) {
//        BranchDeleteDialog(
//            branchName = formState.name,
//            onConfirm = {
//                branchId?.let { id ->
//                    viewModel.deleteBranch(id)
//                    showDeleteDialog = false
//                    onNavigateBack()
//                }
//            },
//            onDismiss = { showDeleteDialog = false }
//        )
//    }
//
//    // Error Snackbar
//    uiState.errorMessage?.let { error ->
//        LaunchedEffect(error) {
//            // Mostrar snackbar de error
//            viewModel.clearError()
//        }
//    }
//}
//
//@Composable
//private fun BranchFormHeader(
//    title: String,
//    subtitle: String,
//    currentStep: Int,
//    totalSteps: Int,
//    onNavigateBack: () -> Unit,
//    onDeleteClick: (() -> Unit)? = null
//) {
//    GlassmorphicCard(
//        modifier = Modifier.fillMaxWidth(),
//        alpha = 0.1f,
//        cornerRadius = 0.dp
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.horizontalGradient(
//                        colors = listOf(
//                            MassBlue.copy(alpha = 0.05f),
//                            MassOrange.copy(alpha = 0.05f)
//                        )
//                    )
//                )
//                .padding(20.dp),
//            horizontalArrangement = Arrangement.SpaceBetween,
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                GlassmorphicCard(
//                    modifier = Modifier.size(48.dp),
//                    alpha = 0.2f,
//                    cornerRadius = 24.dp,
//                    onClick = onNavigateBack
//                ) {
//                    Box(
//                        modifier = Modifier.fillMaxSize(),
//                        contentAlignment = Alignment.Center
//                    ) {
//                        Icon(
//                            imageVector = Icons.Default.ArrowBack,
//                            contentDescription = "Volver",
//                            tint = MassBlue,
//                            modifier = Modifier.size(24.dp)
//                        )
//                    }
//                }
//
//                Spacer(modifier = Modifier.width(16.dp))
//
//                Column {
//                    Text(
//                        text = title,
//                        style = MaterialTheme.typography.titleLarge.copy(
//                            fontWeight = FontWeight.Bold,
//                            color = MassBlue
//                        )
//                    )
//                    Text(
//                        text = subtitle,
//                        style = MaterialTheme.typography.bodyMedium.copy(
//                            color = Color.Gray
//                        )
//                    )
//                }
//            }
//
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                // Progress indicator
//                GlassmorphicCard(
//                    alpha = 0.2f,
//                    cornerRadius = 16.dp
//                ) {
//                    Row(
//                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
//                        verticalAlignment = Alignment.CenterVertically
//                    ) {
//                        Icon(
//                            imageVector = Icons.Default.Timeline,
//                            contentDescription = "Progreso",
//                            tint = MassOrange,
//                            modifier = Modifier.size(16.dp)
//                        )
//                        Spacer(modifier = Modifier.width(6.dp))
//                        Text(
//                            text = "${currentStep + 1}/$totalSteps",
//                            style = MaterialTheme.typography.labelMedium.copy(
//                                color = MassOrange,
//                                fontWeight = FontWeight.Bold
//                            )
//                        )
//                    }
//                }
//
//                // Delete button (solo en modo edición)
//                onDeleteClick?.let { onClick ->
//                    Spacer(modifier = Modifier.width(8.dp))
//                    GlassmorphicCard(
//                        modifier = Modifier.size(48.dp),
//                        alpha = 0.2f,
//                        cornerRadius = 24.dp,
//                        onClick = onClick
//                    ) {
//                        Box(
//                            modifier = Modifier.fillMaxSize(),
//                            contentAlignment = Alignment.Center
//                        ) {
//                            Icon(
//                                imageVector = Icons.Default.Delete,
//                                contentDescription = "Eliminar",
//                                tint = ErrorColor,
//                                modifier = Modifier.size(24.dp)
//                            )
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchFormStepper(
//    currentStep: Int,
//    steps: List<String>,
//    modifier: Modifier = Modifier
//) {
//    Row(
//        modifier = modifier.fillMaxWidth(),
//        horizontalArrangement = Arrangement.SpaceBetween
//    ) {
//        steps.forEachIndexed { index, step ->
//            BranchStepItem(
//                stepNumber = index + 1,
//                stepName = step,
//                isActive = index == currentStep,
//                isCompleted = index < currentStep,
//                modifier = Modifier.weight(1f)
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchStepItem(
//    stepNumber: Int,
//    stepName: String,
//    isActive: Boolean,
//    isCompleted: Boolean,
//    modifier: Modifier = Modifier
//) {
//    val animatedScale by animateFloatAsState(
//        targetValue = if (isActive) 1.1f else 1f,
//        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
//        label = "step_scale"
//    )
//
//    Column(
//        modifier = modifier.scale(animatedScale),
//        horizontalAlignment = Alignment.CenterAlignment
//    ) {
//        GlassmorphicCard(
//            modifier = Modifier.size(48.dp),
//            alpha = if (isActive || isCompleted) 0.3f else 0.1f,
//            cornerRadius = 24.dp
//        ) {
//            Box(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .background(
//                        brush = when {
//                            isCompleted -> Brush.radialGradient(
//                                colors = listOf(SuccessColor, Color(0xFF059669))
//                            )
//                            isActive -> Brush.radialGradient(
//                                colors = listOf(MassOrange, MassYellow)
//                            )
//                            else -> Brush.radialGradient(
//                                colors = listOf(Color.Gray, Color.LightGray)
//                            )
//                        }
//                    ),
//                contentAlignment = Alignment.Center
//            ) {
//                if (isCompleted) {
//                    Icon(
//                        imageVector = Icons.Default.Check,
//                        contentDescription = "Completado",
//                        tint = Color.White,
//                        modifier = Modifier.size(24.dp)
//                    )
//                } else {
//                    Text(
//                        text = stepNumber.toString(),
//                        style = MaterialTheme.typography.titleMedium.copy(
//                            fontWeight = FontWeight.Bold,
//                            color = Color.White
//                        )
//                    )
//                }
//            }
//        }
//
//        Spacer(modifier = Modifier.height(8.dp))
//
//        Text(
//            text = stepName,
//            style = MaterialTheme.typography.labelMedium.copy(
//                color = when {
//                    isActive -> MassOrange
//                    isCompleted -> SuccessColor
//                    else -> Color.Gray
//                },
//                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
//            )
//        )
//    }
//}
//
//@Composable
//private fun BranchBasicInfoStep(
//    formState: BranchFormState,
//    formErrors: BranchFormErrors,
//    onFormStateChange: (BranchFormState) -> Unit,
//    onValidationErrors: (BranchFormErrors) -> Unit,
//    focusManager: androidx.compose.ui.focus.FocusManager
//) {
//    Column(
//        verticalArrangement = Arrangement.spacedBy(20.dp)
//    ) {
//        // Section Header
//        BranchFormSectionHeader(
//            icon = Icons.Default.Info,
//            title = "Información Básica",
//            subtitle = "Datos principales de la sucursal"
//        )
//
//        // Name Field
//        BranchFormField(
//            label = "Nombre de la Sucursal",
//            value = formState.name,
//            onValueChange = {
//                onFormStateChange(formState.copy(name = it))
//                if (formErrors.name != null) {
//                    onValidationErrors(formErrors.copy(name = null))
//                }
//            },
//            error = formErrors.name,
//            placeholder = "Ej: Sucursal Centro",
//            leadingIcon = Icons.Default.Store,
//            keyboardOptions = KeyboardOptions(
//                imeAction = ImeAction.Next
//            ),
//            keyboardActions = KeyboardActions(
//                onNext = { focusManager.moveFocus(FocusDirection.Down) }
//            )
//        )
//
//        // Address Field
//        BranchFormField(
//            label = "Dirección Completa",
//            value = formState.address,
//            onValueChange = {
//                onFormStateChange(formState.copy(address = it))
//                if (formErrors.address != null) {
//                    onValidationErrors(formErrors.copy(address = null))
//                }
//            },
//            error = formErrors.address,
//            placeholder = "Ej: Av. Javier Prado 123, San Isidro",
//            leadingIcon = Icons.Default.LocationOn,
//            maxLines = 2,
//            keyboardOptions = KeyboardOptions(
//                imeAction = ImeAction.Next
//            ),
//            keyboardActions = KeyboardActions(
//                onNext = { focusManager.moveFocus(FocusDirection.Down) }
//            )
//        )
//
//        // Phone Field
//        BranchFormField(
//            label = "Teléfono",
//            value = formState.phone,
//            onValueChange = {
//                onFormStateChange(formState.copy(phone = it))
//                if (formErrors.phone != null) {
//                    onValidationErrors(formErrors.copy(phone = null))
//                }
//            },
//            error = formErrors.phone,
//            placeholder = "Ej: +51 999 888 777",
//            leadingIcon = Icons.Default.Phone,
//            keyboardOptions = KeyboardOptions(
//                keyboardType = KeyboardType.Phone,
//                imeAction = ImeAction.Next
//            ),
//            keyboardActions = KeyboardActions(
//                onNext = { focusManager.moveFocus(FocusDirection.Down) }
//            )
//        )
//
//        // Email Field
//        BranchFormField(
//            label = "Email (Opcional)",
//            value = formState.email,
//            onValueChange = {
//                onFormStateChange(formState.copy(email = it))
//                if (formErrors.email != null) {
//                    onValidationErrors(formErrors.copy(email = null))
//                }
//            },
//            error = formErrors.email,
//            placeholder = "Ej: sucursal@empresa.com",
//            leadingIcon = Icons.Default.Email,
//            keyboardOptions = KeyboardOptions(
//                keyboardType = KeyboardType.Email,
//                imeAction = ImeAction.Next
//            ),
//            keyboardActions = KeyboardActions(
//                onNext = { focusManager.moveFocus(FocusDirection.Down) }
//            )
//        )
//
//        // Description Field
//        BranchFormField(
//            label = "Descripción (Opcional)",
//            value = formState.description,
//            onValueChange = {
//                onFormStateChange(formState.copy(description = it))
//            },
//            placeholder = "Describe las características especiales de esta sucursal...",
//            leadingIcon = Icons.Default.Description,
//            maxLines = 3,
//            keyboardOptions = KeyboardOptions(
//                imeAction = ImeAction.Done
//            ),
//            keyboardActions = KeyboardActions(
//                onDone = { focusManager.clearFocus() }
//            )
//        )
//
//        // Status Switch
//        BranchFormSwitch(
//            label = "Sucursal Activa",
//            description = "La sucursal estará visible para los usuarios",
//            checked = formState.isActive,
//            onCheckedChange = {
//                onFormStateChange(formState.copy(isActive = it))
//            },
//            icon = if (formState.isActive) Icons.Default.CheckCircle else Icons.Default.Cancel
//        )
//    }
//}
//
//@Composable
//private fun BranchLocationStep(
//    formState: BranchFormState,
//    formErrors: BranchFormErrors,
//    onFormStateChange: (BranchFormState) -> Unit,
//    onOpenMapPicker: () -> Unit
//) {
//    Column(
//        verticalArrangement = Arrangement.spacedBy(20.dp)
//    ) {
//        // Section Header
//        BranchFormSectionHeader(
//            icon = Icons.Default.LocationOn,
//            title = "Ubicación",
//            subtitle = "Establece la ubicación exacta de la sucursal"
//        )
//
//        // Interactive Map Preview
//        BranchLocationPreview(
//            latitude = formState.latitude,
//            longitude = formState.longitude,
//            branchName = formState.name.ifEmpty { "Nueva Sucursal" },
//            onEditLocation = onOpenMapPicker
//        )
//
//        // Coordinates Display
//        Row(
//            modifier = Modifier.fillMaxWidth(),
//            horizontalArrangement = Arrangement.spacedBy(12.dp)
//        ) {
//            BranchFormField(
//                label = "Latitud",
//                value = String.format("%.6f", formState.latitude),
//                onValueChange = { value ->
//                    value.toDoubleOrNull()?.let { lat ->
//                        onFormStateChange(formState.copy(latitude = lat))
//                    }
//                },
//                error = formErrors.latitude,
//                leadingIcon = Icons.Default.MyLocation,
//                keyboardOptions = KeyboardOptions(
//                    keyboardType = KeyboardType.Decimal
//                ),
//                modifier = Modifier.weight(1f)
//            )
//
//            BranchFormField(
//                label = "Longitud",
//                value = String.format("%.6f", formState.longitude),
//                onValueChange = { value ->
//                    value.toDoubleOrNull()?.let { lng ->
//                        onFormStateChange(formState.copy(longitude = lng))
//                    }
//                },
//                error = formErrors.longitude,
//                leadingIcon = Icons.Default.MyLocation,
//                keyboardOptions = KeyboardOptions(
//                    keyboardType = KeyboardType.Decimal
//                ),
//                modifier = Modifier.weight(1f)
//            )
//        }
//
//        // Location Actions
//        BranchLocationActions(
//            onUseCurrentLocation = {
//                // TODO: Implementar obtención de ubicación actual
//            },
//            onSearchAddress = {
//                // TODO: Implementar búsqueda de dirección
//            },
//            onOpenMapPicker = onOpenMapPicker
//        )
//    }
//}
//
//@Composable
//private fun BranchConfigurationStep(
//    formState: BranchFormState,
//    onFormStateChange: (BranchFormState) -> Unit
//) {
//    Column(
//        verticalArrangement = Arrangement.spacedBy(20.dp)
//    ) {
//        // Section Header
//        BranchFormSectionHeader(
//            icon = Icons.Default.Settings,
//            title = "Configuración",
//            subtitle = "Ajustes adicionales y servicios"
//        )
//
//        // Opening Hours
//        BranchFormField(
//            label = "Horario de Atención",
//            value = formState.openingHours,
//            onValueChange = {
//                onFormStateChange(formState.copy(openingHours = it))
//            },
//            placeholder = "Ej: Lunes a Viernes 8:00 - 18:00",
//            leadingIcon = Icons.Default.AccessTime,
//            maxLines = 2
//        )
//
//        // Capacity
//        BranchFormField(
//            label = "Capacidad (Personas)",
//            value = if (formState.capacity > 0) formState.capacity.toString() else "",
//            onValueChange = { value ->
//                val capacity = value.toIntOrNull() ?: 0
//                onFormStateChange(formState.copy(capacity = capacity))
//            },
//            placeholder = "Ej: 50",
//            leadingIcon = Icons.Default.People,
//            keyboardOptions = KeyboardOptions(
//                keyboardType = KeyboardType.Number
//            )
//        )
//
//        // Services Section
//        BranchFormSectionHeader(
//            icon = Icons.Default.RoomService,
//            title = "Servicios Disponibles",
//            subtitle = "Selecciona los servicios que ofrece esta sucursal"
//        )
//
//        // Service Switches
//        BranchFormSwitch(
//            label = "Estacionamiento",
//            description = "La sucursal cuenta con estacionamiento",
//            checked = formState.hasParking,
//            onCheckedChange = {
//                onFormStateChange(formState.copy(hasParking = it))
//            },
//            icon = Icons.Default.LocalParking
//        )
//
//        BranchFormSwitch(
//            label = "WiFi Gratuito",
//            description = "Internet inalámbrico disponible para clientes",
//            checked = formState.hasWifi,
//            onCheckedChange = {
//                onFormStateChange(formState.copy(hasWifi = it))
//            },
//            icon = Icons.Default.Wifi
//        )
//
//        BranchFormSwitch(
//            label = "Accesibilidad",
//            description = "Instalaciones adaptadas para personas con discapacidad",
//            checked = formState.hasAccessibility,
//            onCheckedChange = {
//                onFormStateChange(formState.copy(hasAccessibility = it))
//            },
//            icon = Icons.Default.Accessible
//        )
//    }
//}
//
//@Composable
//private fun BranchFormSectionHeader(
//    icon: androidx.compose.ui.graphics.vector.ImageVector,
//    title: String,
//    subtitle: String,
//    modifier: Modifier = Modifier
//) {
//    Row(
//        modifier = modifier.fillMaxWidth(),
//        verticalAlignment = Alignment.CenterVertically
//    ) {
//        GlassmorphicCard(
//            modifier = Modifier.size(48.dp),
//            alpha = 0.2f,
//            cornerRadius = 24.dp
//        ) {
//            Box(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .background(
//                        brush = Brush.radialGradient(
//                            colors = listOf(MassBlue, MassBlue.copy(alpha = 0.7f))
//                        )
//                    ),
//                contentAlignment = Alignment.Center
//            ) {
//                Icon(
//                    imageVector = icon,
//                    contentDescription = title,
//                    tint = Color.White,
//                    modifier = Modifier.size(24.dp)
//                )
//            }
//        }
//
//        Spacer(modifier = Modifier.width(16.dp))
//
//        Column {
//            Text(
//                text = title,
//                style = MaterialTheme.typography.titleMedium.copy(
//                    fontWeight = FontWeight.Bold,
//                    color = MassBlue
//                )
//            )
//            Text(
//                text = subtitle,
//                style = MaterialTheme.typography.bodySmall.copy(
//                    color = Color.Gray
//                )
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchFormField(
//    label: String,
//    value: String,
//    onValueChange: (String) -> Unit,
//    modifier: Modifier = Modifier,
//    error: String? = null,
//    placeholder: String = "",
//    leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
//    trailingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
//    maxLines: Int = 1,
//    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
//    keyboardActions: KeyboardActions = KeyboardActions.Default
//) {
//    Column(
//        modifier = modifier
//    ) {
//        Text(
//            text = label,
//            style = MaterialTheme.typography.labelLarge.copy(
//                fontWeight = FontWeight.Medium,
//                color = MassBlue
//            ),
//            modifier = Modifier.padding(bottom = 8.dp)
//        )
//
//        GlassmorphicCard(
//            alpha = 0.1f,
//            cornerRadius = 16.dp
//        ) {
//            OutlinedTextField(
//                value = value,
//                onValueChange = onValueChange,
//                placeholder = {
//                    Text(
//                        text = placeholder,
//                        style = MaterialTheme.typography.bodyMedium.copy(
//                            color = Color.Gray.copy(alpha = 0.7f)
//                        )
//                    )
//                },
//                leadingIcon = leadingIcon?.let { icon ->
//                    {
//                        Icon(
//                            imageVector = icon,
//                            contentDescription = label,
//                            tint = if (error != null) ErrorColor else MassOrange,
//                            modifier = Modifier.size(20.dp)
//                        )
//                    }
//                },
//                trailingIcon = trailingIcon?.let { icon ->
//                    {
//                        Icon(
//                            imageVector = icon,
//                            contentDescription = null,
//                            tint = Color.Gray,
//                            modifier = Modifier.size(20.dp)
//                        )
//                    }
//                },
//                isError = error != null,
//                maxLines = maxLines,
//                keyboardOptions = keyboardOptions,
//                keyboardActions = keyboardActions,
//                modifier = Modifier.fillMaxWidth(),
//                colors = OutlinedTextFieldDefaults.colors(
//                    focusedBorderColor = if (error != null) ErrorColor else MassOrange,
//                    unfocusedBorderColor = if (error != null) ErrorColor else Color.Gray.copy(alpha = 0.3f),
//                    focusedTextColor = MassBlue,
//                    unfocusedTextColor = MassBlue,
//                    cursorColor = MassOrange,
//                    errorBorderColor = ErrorColor,
//                    errorCursorColor = ErrorColor
//                ),
//                shape = RoundedCornerShape(16.dp)
//            )
//        }
//
//        if (error != null) {
//            Spacer(modifier = Modifier.height(4.dp))
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Error,
//                    contentDescription = "Error",
//                    tint = ErrorColor,
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text(
//                    text = error,
//                    style = MaterialTheme.typography.labelSmall.copy(
//                        color = ErrorColor
//                    )
//                )
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchFormSwitch(
//    label: String,
//    description: String,
//    checked: Boolean,
//    onCheckedChange: (Boolean) -> Unit,
//    icon: androidx.compose.ui.graphics.vector.ImageVector,
//    modifier: Modifier = Modifier
//) {
//    GlassmorphicCard(
//        modifier = modifier.fillMaxWidth(),
//        alpha = 0.1f,
//        cornerRadius = 16.dp
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = if (checked) {
//                        Brush.horizontalGradient(
//                            colors = listOf(
//                                SuccessColor.copy(alpha = 0.1f),
//                                Color.Transparent
//                            )
//                        )
//                    } else {
//                        Brush.horizontalGradient(
//                            colors = listOf(
//                                Color.Transparent,
//                                Color.Transparent
//                            )
//                        )
//                    }
//                )
//                .padding(16.dp),
//            horizontalArrangement = Arrangement.SpaceBetween,
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            Row(
//                verticalAlignment = Alignment.CenterVertically,
//                modifier = Modifier.weight(1f)
//            ) {
//                GlassmorphicCard(
//                    modifier = Modifier.size(40.dp),
//                    alpha = 0.2f,
//                    cornerRadius = 20.dp
//                ) {
//                    Box(
//                        modifier = Modifier
//                            .fillMaxSize()
//                            .background(
//                                brush = Brush.radialGradient(
//                                    colors = if (checked) {
//                                        listOf(SuccessColor, Color(0xFF059669))
//                                    } else {
//                                        listOf(Color.Gray, Color.LightGray)
//                                    }
//                                )
//                            ),
//                        contentAlignment = Alignment.Center
//                    ) {
//                        Icon(
//                            imageVector = icon,
//                            contentDescription = label,
//                            tint = Color.White,
//                            modifier = Modifier.size(20.dp)
//                        )
//                    }
//                }
//
//                Spacer(modifier = Modifier.width(12.dp))
//
//                Column {
//                    Text(
//                        text = label,
//                        style = MaterialTheme.typography.bodyLarge.copy(
//                            fontWeight = FontWeight.Medium,
//                            color = MassBlue
//                        )
//                    )
//                    Text(
//                        text = description,
//                        style = MaterialTheme.typography.bodySmall.copy(
//                            color = Color.Gray
//                        )
//                    )
//                }
//            }
//
//            Switch(
//                checked = checked,
//                onCheckedChange = onCheckedChange,
//                colors = SwitchDefaults.colors(
//                    checkedThumbColor = SuccessColor,
//                    checkedTrackColor = SuccessColor.copy(alpha = 0.3f),
//                    uncheckedThumbColor = Color.Gray,
//                    uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
//                )
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchLocationPreview(
//    latitude: Double,
//    longitude: Double,
//    branchName: String,
//    onEditLocation: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    GlassmorphicCard(
//        modifier = modifier
//            .fillMaxWidth()
//            .height(200.dp),
//        alpha = 0.1f,
//        cornerRadius = 16.dp
//    ) {
//        Box(
//            modifier = Modifier.fillMaxSize()
//        ) {
//            // Google Map Preview
//            GoogleMap(
//                modifier = Modifier.fillMaxSize(),
//                cameraPositionState = rememberCameraPositionState {
//                    position = CameraPosition.fromLatLngZoom(
//                        LatLng(latitude, longitude),
//                        15f
//                    )
//                },
//                uiSettings = MapUiSettings(
//                    zoomControlsEnabled = false,
//                    scrollGesturesEnabled = false,
//                    zoomGesturesEnabled = false,
//                    tiltGesturesEnabled = false,
//                    rotationGesturesEnabled = false
//                )
//            ) {
//                Marker(
//                    state = MarkerState(position = LatLng(latitude, longitude)),
//                    title = branchName,
//                    snippet = "Ubicación de la sucursal"
//                )
//            }
//
//            // Edit overlay
//            Box(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .background(Color.Black.copy(alpha = 0.3f))
//                    .clip(RoundedCornerShape(16.dp)),
//                contentAlignment = Alignment.Center
//            ) {
//                MassButton(
//                    text = "Editar Ubicación",
//                    onClick = onEditLocation,
//                    variant = MassButtonVariant.Primary,
//                    icon = Icons.Default.Edit
//                )
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchLocationActions(
//    onUseCurrentLocation: () -> Unit,
//    onSearchAddress: () -> Unit,
//    onOpenMapPicker: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    Column(
//        modifier = modifier,
//        verticalArrangement = Arrangement.spacedBy(12.dp)
//    ) {
//        Text(
//            text = "Acciones Rápidas",
//            style = MaterialTheme.typography.titleSmall.copy(
//                fontWeight = FontWeight.Bold,
//                color = MassBlue
//            )
//        )
//
//        Row(
//            modifier = Modifier.fillMaxWidth(),
//            horizontalArrangement = Arrangement.spacedBy(12.dp)
//        ) {
//            // Current Location Button
//            OutlinedButton(
//                onClick = onUseCurrentLocation,
//                modifier = Modifier.weight(1f),
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = MassBlue
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.MyLocation,
//                    contentDescription = "Mi ubicación",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text(
//                    text = "Mi Ubicación",
//                    fontSize = 12.sp
//                )
//            }
//
//            // Search Address Button
//            OutlinedButton(
//                onClick = onSearchAddress,
//                modifier = Modifier.weight(1f),
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = MassOrange
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Search,
//                    contentDescription = "Buscar",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text(
//                    text = "Buscar",
//                    fontSize = 12.sp
//                )
//            }
//        }
//
//        // Map Picker Button
//        MassButton(
//            text = "Seleccionar en Mapa",
//            onClick = onOpenMapPicker,
//            variant = MassButtonVariant.Secondary,
//            icon = Icons.Default.Map,
//            modifier = Modifier.fillMaxWidth()
//        )
//    }
//}
//
//@Composable
//private fun BranchFormBottomBar(
//    currentStep: Int,
//    totalSteps: Int,
//    isEditMode: Boolean,
//    isLoading: Boolean,
//    onPreviousStep: () -> Unit,
//    onNextStep: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    GlassmorphicCard(
//        modifier = modifier.fillMaxWidth(),
//        alpha = 0.95f,
//        cornerRadius = 0.dp
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.horizontalGradient(
//                        colors = listOf(
//                            Color.White.copy(alpha = 0.9f),
//                            Color.White.copy(alpha = 0.95f)
//                        )
//                    )
//                )
//                .padding(20.dp),
//            horizontalArrangement = Arrangement.SpaceBetween,
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            // Previous Button
//            if (currentStep > 0) {
//                OutlinedButton(
//                    onClick = onPreviousStep,
//                    enabled = !isLoading,
//                    colors = ButtonDefaults.outlinedButtonColors(
//                        contentColor = Color.Gray
//                    )
//                ) {
//                    Icon(
//                        imageVector = Icons.Default.ArrowBack,
//                        contentDescription = "Anterior",
//                        modifier = Modifier.size(16.dp)
//                    )
//                    Spacer(modifier = Modifier.width(6.dp))
//                    Text("Anterior")
//                }
//            } else {
//                Spacer(modifier = Modifier.width(1.dp))
//            }
//
//            // Progress Indicator
//            Row(
//                horizontalArrangement = Arrangement.spacedBy(8.dp),
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                repeat(totalSteps) { index ->
//                    Box(
//                        modifier = Modifier
//                            .size(8.dp)
//                            .background(
//                                color = if (index <= currentStep) MassOrange else Color.Gray.copy(alpha = 0.3f),
//                                shape = androidx.compose.foundation.shape.CircleShape
//                            )
//                    )
//                }
//            }
//
//            // Next/Save Button
//            val buttonText = when {
//                currentStep < totalSteps - 1 -> "Siguiente"
//                isEditMode -> "Actualizar"
//                else -> "Crear Sucursal"
//            }
//
//            val buttonIcon = when {
//                currentStep < totalSteps - 1 -> Icons.Default.ArrowForward
//                isEditMode -> Icons.Default.Update
//                else -> Icons.Default.Save
//            }
//
//            MassButton(
//                text = buttonText,
//                onClick = onNextStep,
//                variant = MassButtonVariant.Primary,
//                icon = buttonIcon,
//                isLoading = isLoading,
//                enabled = !isLoading
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchMapPickerDialog(
//    initialLocation: LatLng,
//    onLocationSelected: (LatLng) -> Unit,
//    onDismiss: () -> Unit
//) {
//    var selectedLocation by remember { mutableStateOf(initialLocation) }
//    val cameraPositionState = rememberCameraPositionState {
//        position = CameraPosition.fromLatLngZoom(initialLocation, 15f)
//    }
//
//    AlertDialog(
//        onDismissRequest = onDismiss,
//        title = {
//            Text(
//                text = "📍 Seleccionar Ubicación",
//                style = MaterialTheme.typography.titleLarge.copy(
//                    fontWeight = FontWeight.Bold,
//                    color = MassBlue
//                )
//            )
//        },
//        text = {
//            Column {
//                Text(
//                    text = "Toca en el mapa para seleccionar la ubicación exacta de la sucursal",
//                    style = MaterialTheme.typography.bodyMedium.copy(
//                        color = Color.Gray
//                    )
//                )
//
//                Spacer(modifier = Modifier.height(16.dp))
//
//                Box(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .height(300.dp)
//                        .clip(RoundedCornerShape(12.dp))
//                ) {
//                    GoogleMap(
//                        modifier = Modifier.fillMaxSize(),
//                        cameraPositionState = cameraPositionState,
//                        onMapClick = { latLng ->
//                            selectedLocation = latLng
//                        }
//                    ) {
//                        Marker(
//                            state = MarkerState(position = selectedLocation),
//                            title = "Ubicación Seleccionada"
//                        )
//                    }
//                }
//
//                Spacer(modifier = Modifier.height(12.dp))
//
//                // Coordinates display
//                GlassmorphicCard(
//                    alpha = 0.1f,
//                    cornerRadius = 8.dp
//                ) {
//                    Column(
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .padding(12.dp)
//                    ) {
//                        Text(
//                            text = "Coordenadas Seleccionadas:",
//                            style = MaterialTheme.typography.labelMedium.copy(
//                                fontWeight = FontWeight.Bold,
//                                color = MassBlue
//                            )
//                        )
//                        Text(
//                            text = "Lat: ${String.format("%.6f", selectedLocation.latitude)}",
//                            style = MaterialTheme.typography.bodySmall.copy(
//                                color = Color.Gray
//                            )
//                        )
//                        Text(
//                            text = "Lng: ${String.format("%.6f", selectedLocation.longitude)}",
//                            style = MaterialTheme.typography.bodySmall.copy(
//                                color = Color.Gray
//                            )
//                        )
//                    }
//                }
//            }
//        },
//        confirmButton = {
//            MassButton(
//                text = "Confirmar",
//                onClick = { onLocationSelected(selectedLocation) },
//                variant = MassButtonVariant.Primary,
//                icon = Icons.Default.Check
//            )
//        },
//        dismissButton = {
//            OutlinedButton(
//                onClick = onDismiss,
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = Color.Gray
//                )
//            ) {
//                Text("Cancelar")
//            }
//        },
//        containerColor = Color.White,
//        shape = RoundedCornerShape(20.dp)
//    )
//}
//
//@Composable
//private fun BranchDeleteDialog(
//    branchName: String,
//    onConfirm: () -> Unit,
//    onDismiss: () -> Unit
//) {
//    AlertDialog(
//        onDismissRequest = onDismiss,
//        icon = {
//            Icon(
//                imageVector = Icons.Default.Warning,
//                contentDescription = "Advertencia",
//                tint = ErrorColor,
//                modifier = Modifier.size(48.dp)
//            )
//        },
//        title = {
//            Text(
//                text = "⚠️ Eliminar Sucursal",
//                style = MaterialTheme.typography.titleLarge.copy(
//                    fontWeight = FontWeight.Bold,
//                    color = ErrorColor
//                )
//            )
//        },
//        text = {
//            Column {
//                Text(
//                    text = "¿Estás seguro de que deseas eliminar la sucursal:",
//                    style = MaterialTheme.typography.bodyMedium
//                )
//
//                Spacer(modifier = Modifier.height(8.dp))
//
//                Text(
//                    text = "\"$branchName\"",
//                    style = MaterialTheme.typography.bodyLarge.copy(
//                        fontWeight = FontWeight.Bold,
//                        color = MassBlue
//                    )
//                )
//
//                Spacer(modifier = Modifier.height(8.dp))
//
//                Text(
//                    text = "Esta acción no se puede deshacer.",
//                    style = MaterialTheme.typography.bodySmall.copy(
//                        color = ErrorColor,
//                        fontWeight = FontWeight.Medium
//                    )
//                )
//            }
//        },
//        confirmButton = {
//            Button(
//                onClick = onConfirm,
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = ErrorColor
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Delete,
//                    contentDescription = "Eliminar",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text("Eliminar")
//            }
//        },
//        dismissButton = {
//            OutlinedButton(
//                onClick = onDismiss,
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = Color.Gray
//                )
//            ) {
//                Text("Cancelar")
//            }
//        },
//        containerColor = Color.White,
//        shape = RoundedCornerShape(20.dp)
//    )
//}
//
//// Funciones de validación
//private fun validateCurrentStep(formState: BranchFormState, currentStep: Int): BranchFormErrors {
//    return when (currentStep) {
//        0 -> validateBasicInfo(formState)
//        1 -> validateLocation(formState)
//        2 -> validateConfiguration(formState)
//        else -> BranchFormErrors()
//    }
//}
//
//private fun validateBasicInfo(formState: BranchFormState): BranchFormErrors {
//    return BranchFormErrors(
//        name = when {
//            formState.name.isBlank() -> "El nombre es obligatorio"
//            formState.name.length < 3 -> "El nombre debe tener al menos 3 caracteres"
//            formState.name.length > 100 -> "El nombre no puede exceder 100 caracteres"
//            else -> null
//        },
//        address = when {
//            formState.address.isBlank() -> "La dirección es obligatoria"
//            formState.address.length < 10 -> "La dirección debe ser más específica"
//            formState.address.length > 200 -> "La dirección no puede exceder 200 caracteres"
//            else -> null
//        },
//        phone = when {
//            formState.phone.isBlank() -> "El teléfono es obligatorio"
//            !isValidPhone(formState.phone) -> "Formato de teléfono inválido"
//            else -> null
//        },
//        email = when {
//            formState.email.isNotBlank() && !isValidEmail(formState.email) -> "Formato de email inválido"
//            else -> null
//        }
//    )
//}
//
//private fun validateLocation(formState: BranchFormState): BranchFormErrors {
//    return BranchFormErrors(
//        latitude = when {
//            formState.latitude < -90 || formState.latitude > 90 -> "Latitud inválida"
//            else -> null
//        },
//        longitude = when {
//            formState.longitude < -180 || formState.longitude > 180 -> "Longitud inválida"
//            else -> null
//        }
//    )
//}
//
//private fun validateConfiguration(formState: BranchFormState): BranchFormErrors {
//    return BranchFormErrors(
//        capacity = when {
//            formState.capacity < 0 -> "La capacidad no puede ser negativa"
//            formState.capacity > 10000 -> "La capacidad parece demasiado alta"
//            else -> null
//        }
//    )
//}
//
//private fun hasNoErrors(errors: BranchFormErrors, step: Int): Boolean {
//    return when (step) {
//        0 -> errors.name == null && errors.address == null && errors.phone == null && errors.email == null
//        1 -> errors.latitude == null && errors.longitude == null
//        2 -> errors.capacity == null
//        else -> true
//    }
//}
//
//private fun isValidEmail(email: String): Boolean {
//    return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
//}
//
//private fun isValidPhone(phone: String): Boolean {
//    return phone.replace(Regex("[^\\d]"), "").length >= 7
//}
//
//private fun saveBranch(
//    formState: BranchFormState,
//    branchId: Int?,
//    viewModel: BranchViewModel
//) {
//    val branch = Branch(
//        id = branchId ?: 0,
//        name = formState.name.trim(),
//        address = formState.address.trim(),
//        phone = formState.phone.trim(),
//        email = formState.email.trim().takeIf { it.isNotBlank() },
//        latitude = formState.latitude,
//        longitude = formState.longitude,
//        isActive = formState.isActive,
//        description = formState.description.trim().takeIf { it.isNotBlank() },
//        openingHours = formState.openingHours.trim().takeIf { it.isNotBlank() },
//        managerId = formState.managerId,
//        capacity = formState.capacity.takeIf { it > 0 },
//        hasParking = formState.hasParking,
//        hasWifi = formState.hasWifi,
//        hasAccessibility = formState.hasAccessibility,
//        createdAt = "", // Se asigna en el backend
//        updatedAt = ""  // Se asigna en el backend
//    )
//
//    if (branchId != null) {
//        viewModel.updateBranch(branchId, branch)
//    } else {
//        viewModel.createBranch(branch)
//    }
//}