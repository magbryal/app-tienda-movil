package com.mass.marketplace.data.model.response

data class OrderResponse(
    val id: Int,
    val user_id: Int,
    val total_amount: Double,
    val status: String,
    val created_at: String,
    val payment_proof_url: String? = null,
    val items: List<OrderItemResponse>? = null
)