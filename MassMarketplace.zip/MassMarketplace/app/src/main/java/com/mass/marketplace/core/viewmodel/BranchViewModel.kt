package com.mass.marketplace.core.viewmodel

import android.annotation.SuppressLint
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.usecase.branch.CreateBranchUseCase
import com.mass.marketplace.domain.usecase.branch.DeleteBranchUseCase
import com.mass.marketplace.domain.usecase.branch.GetBranchByIdUseCase
import com.mass.marketplace.domain.usecase.branch.GetBranchesUseCase
import com.mass.marketplace.domain.usecase.branch.GetNearbyBranchesUseCase
import com.mass.marketplace.domain.usecase.branch.UpdateBranchUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class BranchUiState(
    val branches: List<Branch> = emptyList(),
    val nearbyBranches: List<Branch> = emptyList(),
    val selectedBranch: Branch? = null,
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val isLoadingBranchDetail: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val userLocation: Pair<Double, Double>? = null
)

class BranchViewModel(
    private val getBranchesUseCase: GetBranchesUseCase,
    private val createBranchUseCase: CreateBranchUseCase,
    private val updateBranchUseCase: UpdateBranchUseCase,
    private val deleteBranchUseCase: DeleteBranchUseCase,
    private val getBranchByIdUseCase: GetBranchByIdUseCase,
    private val getNearbyBranchesUseCase: GetNearbyBranchesUseCase
): ViewModel() {

    private val _uiState = MutableStateFlow(BranchUiState())
    val uiState: StateFlow<BranchUiState> = _uiState.asStateFlow()

    // Flag para saber si tenemos ubicación real del usuario
    private var _hasRealUserLocation = false

    init {
        loadBranches()
    }

    fun loadBranches() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            getBranchesUseCase().fold(
                onSuccess = { branches ->
                    println("BranchViewModel: Cargando sucursales exitosamente: ${branches.size}")

                    // Filtramos las sucursales activas
                    val activeBranches = branches.filter { it.isActive }

                    println("BranchViewModel: Sucursales activas: ${activeBranches.size}")

                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        branches = activeBranches
                    )

                    // Si tenemos ubicación del usuario, cargar sucursales cercanas
                    _uiState.value.userLocation?.let { (lat, lng) ->
                        loadNearbyBranches(lat, lng)
                    }
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al cargar sucursales: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Error al cargar sucursales"
                    )
                }
            )
        }
    }

    fun refreshBranches() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRefreshing = true, errorMessage = null)

            getBranchesUseCase().fold(
                onSuccess = { branches ->
                    println("BranchViewModel: Refrescando sucursales exitosamente: ${branches.size}")

                    val activeBranches = branches.filter { it.isActive }

                    _uiState.value = _uiState.value.copy(
                        isRefreshing = false,
                        branches = activeBranches
                    )

                    // Actualizar sucursales cercanas si tenemos ubicación
                    _uiState.value.userLocation?.let { (lat, lng) ->
                        loadNearbyBranches(lat, lng)
                    }
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al refrescar sucursales: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        isRefreshing = false,
                        errorMessage = error.message ?: "Error al refrescar sucursales"
                    )
                }
            )
        }
    }

    fun getBranchById(id: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoadingBranchDetail = true, errorMessage = null)

            getBranchByIdUseCase(id).fold(
                onSuccess = { branch ->
                    println("BranchViewModel: Sucursal obtenida por ID $id: ${branch.name}")
                    _uiState.value = _uiState.value.copy(
                        isLoadingBranchDetail = false,
                        selectedBranch = branch
                    )
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al obtener sucursal por ID $id: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoadingBranchDetail = false,
                        errorMessage = error.message ?: "Error al obtener sucursal"
                    )
                }
            )
        }
    }

    fun createBranch(branch: Branch) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            createBranchUseCase(branch).fold(
                onSuccess = { message ->
                    println("BranchViewModel: Sucursal creada exitosamente: $message")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        successMessage = message
                    )
                    // Recargar la lista para mostrar la nueva sucursal
                    loadBranches()
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al crear sucursal: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Error al crear sucursal"
                    )
                }
            )
        }
    }

    fun updateBranch(id: Int, branch: Branch) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            updateBranchUseCase(id, branch).fold(
                onSuccess = { message ->
                    println("BranchViewModel: Sucursal actualizada exitosamente: $message")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        successMessage = message
                    )
                    // Recargar la lista para mostrar los cambios
                    loadBranches()
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al actualizar sucursal: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Error al actualizar sucursal"
                    )
                }
            )
        }
    }

    fun deleteBranch(id: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            deleteBranchUseCase(id).fold(
                onSuccess = { message ->
                    println("BranchViewModel: Sucursal eliminada exitosamente: $message")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        successMessage = message
                    )
                    // Recargar la lista para reflejar la eliminación
                    loadBranches()
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al eliminar sucursal: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Error al eliminar sucursal"
                    )
                }
            )
        }
    }

    fun selectBranch(branch: Branch) {
        println("BranchViewModel: Sucursal seleccionada: ${branch.name}")
        _uiState.value = _uiState.value.copy(selectedBranch = branch)
    }

    fun clearSelectedBranch() {
        println("BranchViewModel: Limpiando sucursal seleccionada")
        _uiState.value = _uiState.value.copy(selectedBranch = null)
    }

    // Ahora actualiza el userLocation en el uiState y maneja ubicación real vs fallback
    fun setUserLocation(latitude: Double, longitude: Double, isRealLocation: Boolean = true) {
        println("BranchViewModel: Estableciendo ubicación - Lat: $latitude, Lng: $longitude, Real: $isRealLocation")

        _hasRealUserLocation = isRealLocation

        _uiState.value = _uiState.value.copy(
            userLocation = Pair(latitude, longitude)
        )

        // Ordenar sucursales por distancia
        val sortedBranches = _uiState.value.branches.sortedBy { branch ->
            branch.distanceTo(latitude, longitude)
        }

        _uiState.value = _uiState.value.copy(branches = sortedBranches)

        // Si es ubicación real, cargar sucursales cercanas
        if (isRealLocation) {
            loadNearbyBranches(latitude, longitude)
        }
    }

    @SuppressLint("DefaultLocale")
    fun loadNearbyBranches(latitude: Double, longitude: Double, maxDistance: Double = 10.0) {
        viewModelScope.launch {
            println("BranchViewModel: Buscando sucursales cercanas dentro de ${maxDistance}km")

            getNearbyBranchesUseCase(latitude, longitude, maxDistance).fold(
                onSuccess = { nearbyBranches ->
                    println("BranchViewModel: Sucursales cercanas encontradas: ${nearbyBranches.size}")
                    nearbyBranches.forEach { branch ->
                        val distance = branch.distanceTo(latitude, longitude)
                        println("   - ${branch.name}: ${String.format("%.2f", distance)}km")
                    }

                    _uiState.value = _uiState.value.copy(
                        nearbyBranches = nearbyBranches
                    )
                },
                onFailure = { error ->
                    println("BranchViewModel: Error al cargar sucursales cercanas: ${error.message}")
                    // No mostramos error al usuario para funcionalidad secundaria
                }
            )
        }
    }

    fun searchBranches(query: String) {
        val allBranches = _uiState.value.branches
        val filteredBranches = if (query.isBlank()) {
            allBranches
        } else {
            allBranches.filter { branch ->
                branch.name.contains(query, ignoreCase = true) ||
                        branch.address.contains(query, ignoreCase = true) ||
                        branch.phone.contains(query, ignoreCase = true)
            }
        }

        println("BranchViewModel: Búsqueda '$query' - Resultados: ${filteredBranches.size}")
        _uiState.value = _uiState.value.copy(branches = filteredBranches)
    }

    fun sortBranchesByDistance() {
        val userLocation = _uiState.value.userLocation
        if (userLocation != null) {
            val (lat, lng) = userLocation
            val sortedBranches = _uiState.value.branches.sortedBy { branch ->
                branch.distanceTo(lat, lng)
            }

            println("BranchViewModel: Sucursales ordenadas por distancia")
            _uiState.value = _uiState.value.copy(branches = sortedBranches)
        } else {
            println("BranchViewModel: No se puede ordenar por distancia - ubicación no disponible")
        }
    }

    fun sortBranchesByName() {
        val sortedBranches = _uiState.value.branches.sortedBy { it.name }
        println("BranchViewModel: Sucursales ordenadas por nombre")
        _uiState.value = _uiState.value.copy(branches = sortedBranches)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun clearSuccessMessage() {
        _uiState.value = _uiState.value.copy(successMessage = null)
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(
            errorMessage = null,
            successMessage = null
        )
    }

    fun getBranchCount(): Int = _uiState.value.branches.size

    fun getNearbyBranchCount(): Int = _uiState.value.nearbyBranches.size

    // MÉTODO CORREGIDO: Ahora verifica si tenemos ubicación real del usuario
    fun hasUserLocation(): Boolean = _hasRealUserLocation

    fun getSelectedBranchDistance(): Double? {
        val selectedBranch = _uiState.value.selectedBranch
        val userLocation = _uiState.value.userLocation

        return if (selectedBranch != null && userLocation != null) {
            val (lat, lng) = userLocation
            selectedBranch.distanceTo(lat, lng)
        } else {
            null
        }
    }

    fun getBranches() {
        loadBranches()
    }

    fun getUserLocation(): Pair<Double, Double>? {
        return _uiState.value.userLocation
    }

    fun getAvailableRegions(branches: List<Branch>): List<String> {
        return branches.map { branch ->
            branch.address.split(",").lastOrNull()?.trim() ?: ""
        }.filter { it.isNotEmpty() }.distinct().sorted()
    }
}