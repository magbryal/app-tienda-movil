package com.mass.marketplace.core.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.domain.usecase.auth.LoginUseCase
import com.mass.marketplace.domain.usecase.auth.RegisterUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val isSuccess: Boolean = false,
    val errorMessage: String? = null,
    val userInfo: com.mass.marketplace.data.local.UserInfo? = null
)

class AuthViewModel(
    private val registerUseCase: RegisterUseCase,
    private val loginUseCase: LoginUseCase,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun register(
        name: String,
        lastName: String,
        email: String,
        password: String,
        phone: String,
        address: String
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            registerUseCase(name, lastName, email, password, phone, address)
                .onSuccess { response ->
                    if (response.message.contains("creado correctamente", ignoreCase = true)) {
                        login(email, password)
                    } else {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isSuccess = false,
                            errorMessage = response.message
                        )
                    }
                }
                .onFailure { exception ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        isSuccess = false,
                        errorMessage = exception.message ?: "Error desconocido durante el registro"
                    )
                }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            loginUseCase(email, password)
                .onSuccess { response ->
                    if (response.token != null) {
                        val userName = response.user?.name ?: extractNameFromMessage(response.message) ?: "Usuario"

                        sessionManager.saveUserSession(
                            accessToken = response.token,
                            refreshToken = response.token,
                            userId = response.user?.id?.toString() ?: "temp_${System.currentTimeMillis()}",
                            userEmail = response.user?.email ?: email,
                            userName = userName,
                            tokenExpiryTime = System.currentTimeMillis() + (24 * 60 * 60 * 1000)
                        )

                        val userInfo = sessionManager.getUserInfo()

                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isSuccess = true,
                            errorMessage = null,
                            userInfo = userInfo
                        )
                    } else {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isSuccess = false,
                            errorMessage = "Error: No se recibió token de autenticación"
                        )
                    }
                }
                .onFailure { exception ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        isSuccess = false,
                        errorMessage = exception.message
                    )
                }
        }
    }

    private fun extractNameFromMessage(message: String): String? {
        return try {
            when {
                message.startsWith("Bienvenido ") -> {
                    message.substring("Bienvenido ".length).trim()
                }
                message.startsWith("Usuario creado correctamente") -> {
                    null
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun logout() {
        viewModelScope.launch {
            sessionManager.clearSession()
            _uiState.value = AuthUiState()
        }
    }

    fun checkCurrentSession() {
        viewModelScope.launch {
            val userInfo = sessionManager.getUserInfo()
            _uiState.value = _uiState.value.copy(
                userInfo = userInfo,
                isSuccess = userInfo != null
            )
        }
    }
}
