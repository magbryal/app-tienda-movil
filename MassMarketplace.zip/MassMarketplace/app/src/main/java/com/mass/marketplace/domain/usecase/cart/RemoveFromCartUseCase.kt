package com.mass.marketplace.domain.usecase.cart

import com.mass.marketplace.domain.repository.CartRepository

class RemoveFromCartUseCase(
    private val cartRepository: CartRepository
) {
    suspend operator fun invoke(productId: Int) {
        cartRepository.removeFromCart(productId)
    }
}