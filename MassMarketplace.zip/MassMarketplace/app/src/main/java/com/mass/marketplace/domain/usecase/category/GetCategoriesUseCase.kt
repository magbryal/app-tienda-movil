package com.mass.marketplace.domain.usecase.category

import com.mass.marketplace.domain.repository.CategoryRepository
import com.mass.marketplace.presentation.ui.screens.home.Category

class GetCategoriesUseCase(
    private val categoryRepository: CategoryRepository
) {
    suspend operator fun invoke(): Result<List<Category>> {
        return categoryRepository.getCategories()
    }
}
