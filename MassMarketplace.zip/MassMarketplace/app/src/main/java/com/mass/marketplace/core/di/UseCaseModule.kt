package com.mass.marketplace.core.di

import com.mass.marketplace.domain.usecase.category.GetCategoriesUseCase
import com.mass.marketplace.domain.usecase.product.GetProductsUseCase
import com.mass.marketplace.domain.usecase.auth.LoginUseCase
import com.mass.marketplace.domain.usecase.auth.RegisterUseCase
import com.mass.marketplace.domain.usecase.branch.CreateBranchUseCase
import com.mass.marketplace.domain.usecase.branch.DeleteBranchUseCase
import com.mass.marketplace.domain.usecase.branch.GetBranchByIdUseCase
import com.mass.marketplace.domain.usecase.branch.GetBranchesUseCase
import com.mass.marketplace.domain.usecase.branch.GetNearbyBranchesUseCase
import com.mass.marketplace.domain.usecase.branch.UpdateBranchUseCase
import com.mass.marketplace.domain.usecase.cart.AddToCartUseCase
import com.mass.marketplace.domain.usecase.cart.ClearCartUseCase
import com.mass.marketplace.domain.usecase.cart.GetCartItemsUseCase
import com.mass.marketplace.domain.usecase.cart.RemoveFromCartUseCase
import com.mass.marketplace.domain.usecase.cart.UpdateCartQuantityUseCase
import com.mass.marketplace.domain.usecase.order.CreateOrderUseCase
import com.mass.marketplace.domain.usecase.order.GetOrdersUseCase // AGREGAR IMPORT
import com.mass.marketplace.domain.usecase.payment.UploadPaymentProofUseCase
import com.mass.marketplace.domain.usecase.payment.UploadPaymentProofUseCaseImpl
import org.koin.dsl.module

val useCaseModule = module {
    factory { RegisterUseCase(get()) }
    factory { LoginUseCase(get()) }
    factory { GetProductsUseCase(get()) }
    factory { GetCategoriesUseCase(get()) }

    // cart
    factory { GetCartItemsUseCase(get()) }
    factory { AddToCartUseCase(get()) }
    factory { UpdateCartQuantityUseCase(get()) }
    factory { RemoveFromCartUseCase(get()) }
    factory { ClearCartUseCase(get()) }

    // orders
    factory { CreateOrderUseCase(get()) }
    factory { GetOrdersUseCase(get()) }

    // branch
    factory { GetBranchesUseCase(get()) }
    factory { CreateBranchUseCase(get()) }
    factory { UpdateBranchUseCase(get()) }
    factory { DeleteBranchUseCase(get()) }
    factory { GetBranchByIdUseCase(get()) }
    factory { GetNearbyBranchesUseCase(get()) }

    // SUBIDA DE COMPROBANTES
    factory<UploadPaymentProofUseCase> { UploadPaymentProofUseCaseImpl(get()) }
}
