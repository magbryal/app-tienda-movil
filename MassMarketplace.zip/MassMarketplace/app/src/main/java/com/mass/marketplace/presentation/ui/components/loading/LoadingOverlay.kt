package com.mass.marketplace.presentation.ui.components.loading

import android.annotation.SuppressLint
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mass.marketplace.R
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.theme.*

@Composable
fun LoadingOverlay(
    isVisible: Boolean,
    message: String = "Cargando...",
    @SuppressLint("ModifierParameter") modifier: Modifier = Modifier
) {
    if (isVisible) {
        Dialog(
            onDismissRequest = { /* No se puede cerrar */ },
            properties = DialogProperties(
                dismissOnBackPress = false,
                dismissOnClickOutside = false,
                usePlatformDefaultWidth = false
            )
        ) {
            LoadingContent(
                message = message,
                modifier = modifier
            )
        }
    }
}

@Composable
private fun LoadingContent(
    message: String,
    modifier: Modifier = Modifier
) {
    // Animaciones infinitas
    val infiniteTransition = rememberInfiniteTransition(label = "loading")

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    // Fondo con opacidad
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = 0.7f),
                        Color.Black.copy(alpha = 0.5f),
                        Color.Black.copy(alpha = 0.3f)
                    ),
                    radius = 1000f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Elementos de fondo animados
        AnimatedBackgroundElements(pulseAlpha)

        // Contenido principal
        GlassmorphicCard(
            modifier = Modifier
                .size(200.dp)
                .scale(scale.coerceIn(0.9f, 1.1f)),
            alpha = 0.2f,
            cornerRadius = 24.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier.size(80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(rotation)
                            .background(
                                brush = Brush.sweepGradient(
                                    colors = listOf(
                                        MassOrange,
                                        MassYellow,
                                        MassBlue,
                                        MassOrange
                                    )
                                ),
                                shape = RoundedCornerShape(50)
                            )
                            .alpha(pulseAlpha)
                    )

                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(
                                Color.White.copy(alpha = 0.9f),
                                RoundedCornerShape(50)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_mass_logo),
                            contentDescription = "MASS Logo",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(24.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Texto del mensaje
                Text(
                    text = message,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Indicador de progreso personalizado
                LoadingDots()
            }
        }
    }
}


@Composable
private fun AnimatedBackgroundElements(alpha: Float) {
    val infiniteTransition = rememberInfiniteTransition(label = "background")

    val rotation1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation1"
    )

    val rotation2 by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation2"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Elementos flotantes
        repeat(8) { index ->
            val size = (40 + index * 15).dp
            val offsetX = (index * 60).dp
            val offsetY = (index * 80).dp
            val rotation = if (index % 2 == 0) rotation1 else rotation2

            Box(
                modifier = Modifier
                    .offset(x = offsetX, y = offsetY)
                    .size(size)
                    .rotate(rotation)
                    .alpha(alpha * 0.3f)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.3f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(50)
                    )
                    .blur(10.dp)
            )
        }
    }
}

@Composable
private fun LoadingDots() {
    val infiniteTransition = rememberInfiniteTransition(label = "dots")

    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(3) { index ->
            val scale by infiniteTransition.animateFloat(
                initialValue = 0.5f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(600, delayMillis = index * 200),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "dot_$index"
            )

            Box(
                modifier = Modifier
                    .size(8.dp)
                    .scale(scale)
                    .background(
                        MassOrange,
                        RoundedCornerShape(50)
                    )
            )
        }
    }
}
