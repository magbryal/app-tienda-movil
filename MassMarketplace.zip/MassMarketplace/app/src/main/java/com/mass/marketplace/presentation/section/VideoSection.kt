package com.mass.marketplace.presentation.section

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.mass.marketplace.presentation.ui.theme.ErrorColor
import com.mass.marketplace.presentation.ui.theme.MassBlue
import com.mass.marketplace.presentation.ui.theme.MassOrange
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.YouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(DelicateCoroutinesApi::class)
@Composable
fun VideoSection(
    videoUrl: String = "https://youtu.be/twfivvPo4D4",
    isVisible: Boolean,
    @SuppressLint("ModifierParameter") modifier: Modifier = Modifier
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 400),
        label = "alpha"
    )

    var showVideo by remember { mutableStateOf(false) }
    var isVideoLoading by remember { mutableStateOf(false) }
    var videoError by remember { mutableStateOf<String?>(null) }
    var retryCount by remember { mutableStateOf(0) }

    Column(
        modifier = modifier.alpha(alpha)
    ) {
        // Header de la sección
        VideoSectionHeader(
            onPlayClick = {
                if (!showVideo) {
                    showVideo = true
                    isVideoLoading = true
                    videoError = null
                } else {
                    showVideo = false
                    isVideoLoading = false
                }
            },
            isPlaying = showVideo,
            isLoading = isVideoLoading,
            hasError = videoError != null
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Video player o preview
        if (showVideo) {
            Box {
                val videoId = remember(videoUrl) {
                    when {
                        videoUrl.contains("youtu.be/") ->
                            videoUrl.substringAfter("youtu.be/").substringBefore("?")
                        videoUrl.contains("youtube.com/watch?v=") ->
                            videoUrl.substringAfter("watch?v=").substringBefore("&")
                        else -> "twfivvPo4D4" // ID por defecto
                    }
                }

                NativeYouTubePlayer(
                    videoId = videoId,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    onReady = {
                        isVideoLoading = false
                    },
                    onError = { error ->
                        videoError = error
                        isVideoLoading = false
                        if (retryCount < 1) {
                            retryCount++
                            GlobalScope.launch {
                                delay(2000)
                                videoError = null
                                isVideoLoading = true
                            }
                        }
                    }
                )

                // Error overlay
                if (videoError != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.8f))
                            .clip(RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Error al cargar video",
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = videoError!!,
                                color = Color.White.copy(alpha = 0.8f),
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                TextButton(
                                    onClick = {
                                        videoError = null
                                        isVideoLoading = true
                                        retryCount++
                                    }
                                ) {
                                    Text("Reintentar", color = MassOrange)
                                }

                                TextButton(
                                    onClick = {
                                        showVideo = false
                                        videoError = null
                                        isVideoLoading = false
                                    }
                                ) {
                                    Text("Cerrar", color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            VideoPreviewCard(
                onPlayClick = {
                    showVideo = true
                    isVideoLoading = true
                    videoError = null
                    retryCount = 0
                },
                videoUrl = videoUrl
            )
        }
    }
}

@Composable
private fun VideoSectionHeader(
    onPlayClick: () -> Unit,
    isPlaying: Boolean,
    isLoading: Boolean = false,
    hasError: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "🎥 Contenido Destacado",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )
            Text(
                text = when {
                    isLoading -> "Cargando video..."
                    hasError -> "Error en la reproducción"
                    isPlaying -> "Reproduciendo video..."
                    else -> "Toca para reproducir"
                },
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = when {
                        hasError -> ErrorColor
                        isLoading -> MassOrange
                        else -> Color.Gray
                    }
                )
            )
        }

        IconButton(
            onClick = onPlayClick,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(
                    when {
                        hasError -> ErrorColor.copy(alpha = 0.2f)
                        isPlaying -> MassOrange.copy(alpha = 0.2f)
                        else -> MassBlue.copy(alpha = 0.1f)
                    }
                )
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MassOrange,
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = when {
                        hasError -> Icons.Default.Refresh
                        isPlaying -> Icons.AutoMirrored.Filled.Send
                        else -> Icons.Default.PlayArrow
                    },
                    contentDescription = when {
                        hasError -> "Reintentar"
                        isPlaying -> "Ocultar video"
                        else -> "Reproducir video"
                    },
                    tint = when {
                        hasError -> ErrorColor
                        isPlaying -> MassOrange
                        else -> MassBlue
                    },
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun rememberErrorColor() = Color(0xFFD32F2F)

@Composable
private fun VideoPreviewCard(
    onPlayClick: () -> Unit,
    videoUrl: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        onClick = onPlayClick
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Gradient background
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                MassBlue.copy(alpha = 0.8f),
                                MassOrange.copy(alpha = 0.6f)
                            )
                        )
                    )
            )

            // Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Play button
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(
                            Color.White.copy(alpha = 0.9f),
                            RoundedCornerShape(40.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Reproducir",
                        tint = MassBlue,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Video Promocional",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )

                Text(
                    text = "Descubre nuestras características",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.White.copy(alpha = 0.9f)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // URL indicator
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "📺 YouTube",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun YouTubeVideoPlayerImproved(
    videoUrl: String,
    modifier: Modifier = Modifier,
    onLoadingStateChanged: (Boolean) -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }

    val embedUrl = remember(videoUrl) {
        val videoId = when {
            videoUrl.contains("youtu.be/") -> {
                videoUrl.substringAfter("youtu.be/").substringBefore("?")
            }
            videoUrl.contains("youtube.com/watch?v=") -> {
                videoUrl.substringAfter("watch?v=").substringBefore("&")
            }
            else -> "twfivvPo4D4"
        }

        "https://www.youtube.com/embed/$videoId?" +
                "autoplay=1" +
                "&mute=0" +
                "&controls=1" +
                "&showinfo=0" +
                "&rel=0" +
                "&modestbranding=1" +
                "&playsinline=1" +
                "&enablejsapi=1" +
                "&fs=1" +
                "&iv_load_policy=3" +
                "&cc_load_policy=0" +
                "&disablekb=0" +
                "&start=0"
    }

    // Handle updated callbacks
    val currentOnLoadingStateChanged by rememberUpdatedState(newValue = onLoadingStateChanged)
    val currentOnError by rememberUpdatedState(newValue = onError)

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)

                    // Add these critical settings
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.setSupportMultipleWindows(true)

                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            currentOnLoadingStateChanged(true)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            currentOnLoadingStateChanged(false)

                            view?.evaluateJavascript("""
                                try {
                                    var iframe = document.querySelector('iframe');
                                    if (iframe) {
                                        iframe.style.width = '100%';
                                        iframe.style.height = '100%';
                                        iframe.style.border = 'none';
                                    }
                                    document.body.style.margin = '0';
                                    document.body.style.padding = '0';
                                    document.body.style.overflow = 'hidden';
                                    document.documentElement.style.overflow = 'hidden';
                                } catch(e) {
                                    console.log('JS error: ' + e.message);
                                }
                            """.trimIndent(), null)
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                            super.onReceivedError(view, errorCode, description, failingUrl)
                            currentOnLoadingStateChanged(false)
                            currentOnError("Error $errorCode: ${description ?: "Unknown error"}")
                        }

                        override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                            super.onReceivedError(view, request, error)
                            if (request?.isForMainFrame == true) {
                                currentOnLoadingStateChanged(false)
                                val errorDesc = error?.description?.toString() ?: "Unknown error"
                                currentOnError("Error: $errorDesc")
                            }
                        }
                    }

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        mediaPlaybackRequiresUserGesture = false
                        mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    }
                    webView = this
                }
            },
            update = { view ->
                if (view.url != embedUrl) {
                    view.loadUrl(embedUrl)
                }
            },
            modifier = modifier,
            onRelease = { view ->
                view.destroy()
                webView = null
            }
        )

        DisposableEffect(Unit) {
            onDispose {
                webView?.destroy()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webView?.destroy()
        }
    }
}

@Composable
fun NativeYouTubePlayer(
    videoId: String,
    modifier: Modifier = Modifier,
    onReady: () -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    var playerView by remember { mutableStateOf<YouTubePlayerView?>(null) }

    AndroidView(
        factory = { context ->
            YouTubePlayerView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                enableAutomaticInitialization = false
                playerView = this
            }
        },
        modifier = modifier,
        update = { view ->
            view.initialize(object : AbstractYouTubePlayerListener() {
                override fun onReady(youTubePlayer: YouTubePlayer) {
                    youTubePlayer.loadVideo(videoId, 0f)
                    onReady()
                }

                override fun onError(
                    youTubePlayer: YouTubePlayer,
                    error: PlayerConstants.PlayerError
                ) {
                    val errorMessage = when (error) {
                        PlayerConstants.PlayerError.INVALID_PARAMETER_IN_REQUEST -> "Parámetros inválidos"
                        PlayerConstants.PlayerError.HTML_5_PLAYER -> "Error en reproductor"
                        PlayerConstants.PlayerError.VIDEO_NOT_FOUND -> "Video no encontrado"
                        PlayerConstants.PlayerError.VIDEO_NOT_PLAYABLE_IN_EMBEDDED_PLAYER -> "Video no disponible"
                        PlayerConstants.PlayerError.UNKNOWN -> "Error desconocido"
                    }
                    onError(errorMessage)
                }
            }, true)
        }
    )

    DisposableEffect(Unit) {
        onDispose {
            playerView?.release()
        }
    }
}