package com.mass.marketplace

import android.app.Application
import com.mass.marketplace.core.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin

class MassMarketplaceApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        startKoin {
            androidLogger()
            androidContext(this@MassMarketplaceApplication)
            modules(appModule)
        }
    }
}
