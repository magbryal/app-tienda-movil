package com.mass.marketplace.domain.usecase.order

import com.mass.marketplace.domain.model.Order
import com.mass.marketplace.domain.repository.OrderRepository

class CreateOrderUseCase(
    private val orderRepository: OrderRepository
) {
    suspend operator fun invoke(order: Order): Result<String> {
        return orderRepository.createOrder(order)
    }
}
