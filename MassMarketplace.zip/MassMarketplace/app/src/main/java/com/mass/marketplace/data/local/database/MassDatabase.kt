package com.mass.marketplace.data.local.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.mass.marketplace.data.local.dao.OrderDao
import com.mass.marketplace.data.local.entity.OrderEntity
import com.mass.marketplace.data.local.entity.OrderItemEntity

@Database(
    entities = [OrderEntity::class, OrderItemEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MassDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: MassDatabase? = null

        fun getDatabase(context: Context): MassDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MassDatabase::class.java,
                    "mass_database"
                )
                    .fallbackToDestructiveMigration(false)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
