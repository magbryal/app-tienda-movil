package com.mass.marketplace.domain.usecase.payment

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import android.net.Uri
import androidx.core.graphics.scale
import com.mass.marketplace.domain.repository.PaymentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

interface UploadPaymentProofUseCase {
    suspend operator fun invoke(context: Context, imageUri: Uri): Result<String>
}

class UploadPaymentProofUseCaseImpl(
    private val paymentRepository: PaymentRepository
) : UploadPaymentProofUseCase {

    override suspend fun invoke(context: Context, imageUri: Uri): Result<String> {
        return try {
            println("Iniciando subida de comprobante...")

            // 1. Comprimir y optimizar imagen
            val compressedImageFile = compressAndOptimizeImage(context, imageUri)

            println("Archivo comprimido: ${compressedImageFile.length() / 1024}KB")

            // 2. Subir a ImgBB
            val uploadedUrl = paymentRepository.uploadPaymentProof(compressedImageFile)

            // 3. Limpiar archivo temporal
            compressedImageFile.delete()

            println("Comprobante subido exitosamente: $uploadedUrl")
            Result.success(uploadedUrl)

        } catch (e: Exception) {
            println("Error en subida de comprobante: ${e.message}")
            Result.failure(e)
        }
    }

    private suspend fun compressAndOptimizeImage(context: Context, uri: Uri): File {
        return withContext(Dispatchers.IO) {
            try {
                // Leer imagen original
                val inputStream = context.contentResolver.openInputStream(uri)
                    ?: throw IOException("No se pudo abrir el archivo")

                val originalBitmap = BitmapFactory.decodeStream(inputStream)
                inputStream.close()

                // Obtener orientación EXIF
                val rotatedBitmap = rotateImageIfRequired(context, originalBitmap, uri)

                // Calcular nuevas dimensiones manteniendo aspecto
                val maxWidth = 1024
                val maxHeight = 1024

                val ratio = minOf(
                    maxWidth.toFloat() / rotatedBitmap.width,
                    maxHeight.toFloat() / rotatedBitmap.height
                )

                val newWidth = (rotatedBitmap.width * ratio).toInt()
                val newHeight = (rotatedBitmap.height * ratio).toInt()

                // Redimensionar
                val resizedBitmap = rotatedBitmap.scale(newWidth, newHeight)

                // Crear archivo temporal
                val tempFile = File(
                    context.cacheDir,
                    "compressed_proof_${System.currentTimeMillis()}.jpg"
                )

                // Comprimir y guardar
                val outputStream = FileOutputStream(tempFile)
                val compressionQuality = calculateCompressionQuality(resizedBitmap)

                resizedBitmap.compress(
                    Bitmap.CompressFormat.JPEG,
                    compressionQuality,
                    outputStream
                )
                outputStream.close()

                // Liberar memoria
                if (rotatedBitmap != originalBitmap) {
                    rotatedBitmap.recycle()
                }
                resizedBitmap.recycle()

                println("Imagen procesada: ${tempFile.length() / 1024}KB")
                tempFile

            } catch (e: Exception) {
                throw IOException("Error procesando imagen: ${e.message}")
            }
        }
    }

    private fun rotateImageIfRequired(context: Context, bitmap: Bitmap, uri: Uri): Bitmap {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val exif = ExifInterface(inputStream!!)
            inputStream.close()

            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> rotateImage(bitmap, 90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> rotateImage(bitmap, 180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> rotateImage(bitmap, 270f)
                else -> bitmap
            }
        } catch (e: Exception) {
            bitmap // Si hay error, devolver imagen original
        }
    }

    private fun rotateImage(bitmap: Bitmap, degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun calculateCompressionQuality(bitmap: Bitmap): Int {
        val pixels = bitmap.width * bitmap.height
        return when {
            pixels > 2_000_000 -> 60  // Imágenes muy grandes
            pixels > 1_000_000 -> 70  // Imágenes grandes
            pixels > 500_000 -> 80    // Imágenes medianas
            else -> 85                // Imágenes pequeñas
        }
    }
}
