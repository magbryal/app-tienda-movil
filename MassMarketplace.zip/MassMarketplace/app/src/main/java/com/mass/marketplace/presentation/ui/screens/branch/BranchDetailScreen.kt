package com.mass.marketplace.presentation.ui.screens.branch

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.*
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.core.viewmodel.BranchViewModel
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.presentation.ui.components.buttons.MassButton
import com.mass.marketplace.presentation.ui.components.buttons.MassButtonVariant
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import org.koin.androidx.compose.koinViewModel
import androidx.core.net.toUri

@Composable
fun BranchDetailScreen(
    branchId: Int,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (Branch) -> Unit,
    onNavigateToMap: (Branch) -> Unit,
    viewModel: BranchViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    val uiState by viewModel.uiState.collectAsState()
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(branchId) {
        isVisible = true
        viewModel.getBranchById(branchId)
    }

    LoadingOverlay(
        isVisible = uiState.isLoadingBranchDetail,
        message = "Cargando detalles..."
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.1f),
                        Color.White,
                        MassBlue.copy(alpha = 0.05f)
                    )
                )
            )
    ) {
        uiState.selectedBranch?.let { branch ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .windowInsetsPadding(WindowInsets.systemBars)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Hero Header
                BranchDetailHeader(
                    branch = branch,
                    onNavigateBack = onNavigateBack,
                    onNavigateToEdit = { onNavigateToEdit(branch) },
                    userLocation = uiState.userLocation,
                    isVisible = isVisible
                )

                // Quick Actions
                BranchQuickActions(
                    branch = branch,
                    onNavigateToMap = { onNavigateToMap(branch) },
                    isVisible = isVisible
                )

                // Information Cards
                BranchInformationCards(
                    branch = branch,
                    isVisible = isVisible
                )

                // Location & Map Preview
                BranchLocationCard(
                    branch = branch,
                    userLocation = uiState.userLocation,
                    onNavigateToMap = { onNavigateToMap(branch) },
                    isVisible = isVisible
                )

                // Contact Information
                BranchContactCard(
                    branch = branch,
                    isVisible = isVisible
                )

                // Statistics & Analytics
                BranchAnalyticsCard(
                    branch = branch,
                    isVisible = isVisible
                )

                // Action Buttons
//                BranchActionButtons(
//                    branch = branch,
//                    onEdit = { onNavigateToEdit(branch) },
//                    onDelete = { viewModel.deleteBranch(branch.id) },
//                    isVisible = isVisible
//                )
            }
        }

        // Error State
        if (uiState.errorMessage != null && uiState.selectedBranch == null) {
            BranchDetailErrorState(
                message = uiState.errorMessage!!,
                onRetry = { viewModel.getBranchById(branchId) },
                onNavigateBack = onNavigateBack,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Success/Error Messages
        uiState.successMessage?.let { message ->
            LaunchedEffect(message) {
                kotlinx.coroutines.delay(3000)
                viewModel.clearSuccessMessage()
            }
        }

        uiState.errorMessage?.let { error ->
            LaunchedEffect(error) {
                kotlinx.coroutines.delay(5000)
                viewModel.clearError()
            }
        }
    }
}


@SuppressLint("DefaultLocale")
@Composable
private fun BranchDetailHeader(
    branch: Branch,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: () -> Unit,
    userLocation: Pair<Double, Double>?,
    isVisible: Boolean
) {
    val context = LocalContext.current

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    val distance = userLocation?.let { (userLat, userLng) ->
        branch.distanceTo(userLat, userLng)
    }

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        alpha = 0.15f,
        cornerRadius = 28.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            MassOrange.copy(alpha = 0.1f),
                            MassYellow.copy(alpha = 0.05f),
                            Color.Transparent
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                // Top Navigation Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(48.dp),
                        alpha = 0.2f,
                        cornerRadius = 24.dp,
                        onClick = onNavigateBack
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Volver",
                                tint = MassOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Share Button
                        GlassmorphicCard(
                            modifier = Modifier.size(48.dp),
                            alpha = 0.2f,
                            cornerRadius = 24.dp,
                            onClick = { shareBranch(context, branch) }
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Compartir",
                                    tint = MassBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

//                        // Edit Button
//                        GlassmorphicCard(
//                            modifier = Modifier.size(48.dp),
//                            alpha = 0.2f,
//                            cornerRadius = 24.dp,
//                            onClick = onNavigateToEdit
//                        ) {
//                            Box(
//                                modifier = Modifier.fillMaxSize(),
//                                contentAlignment = Alignment.Center
//                            ) {
//                                Icon(
//                                    imageVector = Icons.Default.Edit,
//                                    contentDescription = "Editar",
//                                    tint = SuccessColor,
//                                    modifier = Modifier.size(24.dp)
//                                )
//                            }
//                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Branch Icon & Status
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(72.dp),
                        alpha = 0.25f,
                        cornerRadius = 36.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = listOf(MassOrange, MassYellow)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Sucursal",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(20.dp))

                    Column {
                        Text(
                            text = branch.name,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MassBlue
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlassmorphicCard(
                                alpha = 0.2f,
                                cornerRadius = 12.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (branch.isActive) Icons.Default.CheckCircle else Icons.Default.Close,
                                        contentDescription = if (branch.isActive) "Activa" else "Inactiva",
                                        tint = if (branch.isActive) SuccessColor else ErrorColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (branch.isActive) "ABIERTA" else "CERRADA",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = if (branch.isActive) SuccessColor else ErrorColor,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            if (distance != null) {
                                Spacer(modifier = Modifier.width(12.dp))

                                GlassmorphicCard(
                                    alpha = 0.2f,
                                    cornerRadius = 12.dp
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Home,
                                            contentDescription = "Distancia",
                                            tint = MassOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${String.format("%.1f", distance)} KM",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = MassOrange,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Address
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Dirección",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = branch.address,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchQuickActions(
    branch: Branch,
    onNavigateToMap: () -> Unit,
    isVisible: Boolean
) {
    val context = LocalContext.current

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Call Action
        BranchQuickActionCard(
            title = "Llamar",
            subtitle = "Contactar ahora",
            icon = Icons.Default.Call,
            gradient = listOf(SuccessColor, Color(0xFF059669)),
            onClick = { makePhoneCall(context, branch.phone) },
            modifier = Modifier.weight(1f)
        )

        // Directions Action
        BranchQuickActionCard(
            title = "Direcciones",
            subtitle = "Cómo llegar",
            icon = Icons.Default.LocationOn,
            gradient = listOf(MassOrange, MassYellow),
            onClick = onNavigateToMap,
            modifier = Modifier.weight(1f)
        )

        // WhatsApp Action
        BranchQuickActionCard(
            title = "WhatsApp",
            subtitle = "Enviar mensaje",
            icon = Icons.Default.Email,
            gradient = listOf(Color(0xFF25D366), Color(0xFF128C7E)),
            onClick = {
                sendWhatsApp(
                    context,
                    branch.phone,
                    "Hola, me interesa información sobre la sucursal ${branch.name}"
                )
            },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun BranchQuickActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    gradient: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scale"
    )

    GlassmorphicCard(
        modifier = modifier
            .height(100.dp)
            .scale(scale),
        alpha = 0.15f,
        cornerRadius = 20.dp,
        onClick = {
            isPressed = true
            onClick()
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = gradient.map { it.copy(alpha = 0.1f) }
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = 0.3f,
                    cornerRadius = 20.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.radialGradient(gradient)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = gradient.first()
                        )
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }

    LaunchedEffect(isPressed) {
        if (isPressed) {
            kotlinx.coroutines.delay(100)
            isPressed = false
        }
    }
}

@Composable
private fun BranchInformationCards(
    branch: Branch,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 400),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "📋 Información General",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Branch ID
            BranchInfoCard(
                title = "ID Sucursal",
                value = "#${branch.id.toString().padStart(4, '0')}",
                icon = Icons.Default.Favorite,
                gradient = listOf(MassBlue, MassBlueLight),
                modifier = Modifier.weight(1f)
            )

            // Creation Date (simulado)
            BranchInfoCard(
                title = "Creada",
                value = "2024",
                icon = Icons.Default.DateRange,
                gradient = listOf(MassOrange, MassYellow),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Manager (simulado)
            BranchInfoCard(
                title = "Gerente",
                value = "Juan Pérez",
                icon = Icons.Default.Person,
                gradient = listOf(SuccessColor, Color(0xFF059669)),
                modifier = Modifier.weight(1f)
            )

            // Employees (simulado)
            BranchInfoCard(
                title = "Empleados",
                value = "12",
                icon = Icons.Default.Person,
                gradient = listOf(Color(0xFF8B5CF6), Color(0xFFA78BFA)),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun BranchInfoCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.height(80.dp),
        alpha = 0.12f,
        cornerRadius = 16.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = gradient.map { it.copy(alpha = 0.1f) }
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = 0.25f,
                    cornerRadius = 20.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.radialGradient(gradient)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = gradient.first()
                        )
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun BranchLocationCard(
    branch: Branch,
    userLocation: Pair<Double, Double>?,
    onNavigateToMap: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 600),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        alpha = 0.12f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🗺️ Ubicación",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                MassButton(
                    text = "Ver en Mapa",
                    onClick = onNavigateToMap,
                    variant = MassButtonVariant.Outline
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Map Preview Placeholder
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                alpha = 0.1f,
                cornerRadius = 20.dp,
                onClick = onNavigateToMap
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    SuccessColor.copy(alpha = 0.1f),
                                    MassBlue.copy(alpha = 0.05f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Mapa",
                            tint = SuccessColor,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Toca para ver en mapa",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = SuccessColor,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Coordinates
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Latitud",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.Gray
                        )
                    )
                    Text(
                        text = String.format("%.6f", branch.latitude),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = MassBlue
                        )
                    )
                }

                Column {
                    Text(
                        text = "Longitud",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.Gray
                        )
                    )
                    Text(
                        text = String.format("%.6f", branch.longitude),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = MassBlue
                        )
                    )
                }

                if (userLocation != null) {
                    val distance = branch.distanceTo(userLocation.first, userLocation.second)
                    Column {
                        Text(
                            text = "Distancia",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.Gray
                            )
                        )
                        Text(
                            text = "${String.format("%.1f", distance)} km",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = MassOrange
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BranchContactCard(
    branch: Branch,
    isVisible: Boolean
) {
    val context = LocalContext.current

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 800),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        alpha = 0.12f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Text(
                text = "📞 Información de Contacto",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Phone
            BranchContactItem(
                icon = Icons.Default.Phone,
                title = "Teléfono",
                value = branch.phone,
                gradient = listOf(SuccessColor, Color(0xFF059669)),
                onClick = { makePhoneCall(context, branch.phone) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Email
            BranchContactItem(
                icon = Icons.Default.Email,
                title = "Email",
                value = "${branch.name.lowercase().replace(" ", ".")}@mass.com",
                gradient = listOf(MassBlue, MassBlueLight),
                onClick = {
                    sendEmail(
                        context,
                        "${branch.name.lowercase().replace(" ", ".")}@mass.com",
                        "Consulta sobre sucursal ${branch.name}",
                        "Hola,\n\nMe gustaría obtener más información sobre la sucursal ${branch.name}.\n\nGracias."
                    )
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Hours
            BranchContactItem(
                icon = Icons.Default.DateRange,
                title = "Horarios",
                value = branch.schedule,
                gradient = listOf(MassOrange, MassYellow),
                onClick = null
            )
        }
    }
}

@Composable
private fun BranchContactItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    gradient: List<Color>,
    onClick: (() -> Unit)?
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassmorphicCard(
                modifier = Modifier.size(44.dp),
                alpha = 0.25f,
                cornerRadius = 22.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.radialGradient(gradient)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color.Gray
                    )
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = gradient.first()
                    )
                )
            }

            if (onClick != null) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Acción",
                    tint = gradient.first(),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsCard(
    branch: Branch,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 1000),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        alpha = 0.12f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Text(
                text = "📊 Estadísticas y Análisis",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Analytics Grid
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Monthly Sales
                    BranchAnalyticsItem(
                        title = "Ventas Mensuales",
                        value = "S/.45,230",
                        isPositive = true,
                        icon = Icons.Default.Star,
                        gradient = listOf(SuccessColor, Color(0xFF059669)),
                        modifier = Modifier.weight(1f)
                    )

                    // Daily Visitors
                    BranchAnalyticsItem(
                        title = "Visitantes Diarios",
                        value = "156",
                        isPositive = true,
                        icon = Icons.Default.Person,
                        gradient = listOf(MassBlue, MassBlueLight),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Customer Satisfaction
                    BranchAnalyticsItem(
                        title = "Satisfacción",
                        value = "${branch.rating}★",
                        isPositive = true,
                        icon = Icons.Default.Star,
                        gradient = listOf(MassOrange, MassYellow),
                        modifier = Modifier.weight(1f)
                    )

                    // Orders Today
                    BranchAnalyticsItem(
                        title = "Pedidos Hoy",
                        value = "23",
                        isPositive = false,
                        icon = Icons.Default.ShoppingCart,
                        gradient = listOf(Color(0xFF8B5CF6), Color(0xFFA78BFA)),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

//            // Performance Chart Placeholder -> para admin
//            GlassmorphicCard(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(120.dp),
//                alpha = 0.1f,
//                cornerRadius = 16.dp
//            ) {
//                Box(
//                    modifier = Modifier
//                        .fillMaxSize()
//                        .background(
//                            brush = Brush.linearGradient(
//                                colors = listOf(
//                                    MassOrange.copy(alpha = 0.1f),
//                                    MassBlue.copy(alpha = 0.05f)
//                                )
//                            )
//                        ),
//                    contentAlignment = Alignment.Center
//                ) {
//                    Column(
//                        horizontalAlignment = Alignment.CenterHorizontally
//                    ) {
//                        Icon(
//                            imageVector = Icons.Default.Menu,
//                            contentDescription = "Gráfico",
//                            tint = MassOrange,
//                            modifier = Modifier.size(32.dp)
//                        )
//                        Spacer(modifier = Modifier.height(8.dp))
//                        Text(
//                            text = "Gráfico de rendimiento",
//                            style = MaterialTheme.typography.bodySmall.copy(
//                                color = Color.Gray
//                            )
//                        )
//                    }
//                }
//            }
        }
    }
}

@Composable
private fun BranchAnalyticsItem(
    title: String,
    value: String,
    isPositive: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.height(100.dp),
        alpha = 0.1f,
        cornerRadius = 16.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = gradient.map { it.copy(alpha = 0.1f) }
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.Gray
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    GlassmorphicCard(
                        modifier = Modifier.size(28.dp),
                        alpha = 0.25f,
                        cornerRadius = 14.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.radialGradient(gradient)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Column {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = gradient.first()
                        )
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isPositive) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isPositive) "Incremento" else "Decremento",
                            tint = if (isPositive) SuccessColor else ErrorColor,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BranchActionButtons(
    branch: Branch,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 1200),
        label = "alpha"
    )

    var showDeleteDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "⚙️ Acciones",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

//        Row(
//            modifier = Modifier.fillMaxWidth(),
//            horizontalArrangement = Arrangement.spacedBy(12.dp)
//        ) {
//            // Metodos de reutilizacion como admin
//            // Edit Button
////            MassButton(
////                text = "Editar Sucursal",
////                onClick = onEdit,
////                variant = MassButtonVariant.Primary,
////                modifier = Modifier.weight(1f)
////            )
////
////            // Delete Button
////            MassButton(
////                text = "Eliminar",
////                onClick = { showDeleteDialog = true },
////                variant = MassButtonVariant.Glass,
////                modifier = Modifier.weight(1f)
////            )
//        }

//        // Additional Action Buttons
//        Row(
//            modifier = Modifier.fillMaxWidth(),
//            horizontalArrangement = Arrangement.spacedBy(12.dp)
//        ) {
//            // Duplicate Button
//            OutlinedButton(
//                onClick = { /* TODO: Implementar duplicar */ },
//                modifier = Modifier.weight(1f),
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = MassBlue
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Add,
//                    contentDescription = "Duplicar",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(8.dp))
//                Text("Duplicar")
//            }
//
//            // Reports Button
//            OutlinedButton(
//                onClick = { /* TODO: Implementar reportes */ },
//                modifier = Modifier.weight(1f),
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = MassOrange
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Star,
//                    contentDescription = "Reportes",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(8.dp))
//                Text("Reportes")
//            }
//        }
    }

    // Delete Confirmation Dialog
    if (showDeleteDialog) {
        BranchDeleteConfirmationDialog(
            branchName = branch.name,
            onConfirm = {
                showDeleteDialog = false
                onDelete()
            },
            onDismiss = { showDeleteDialog = false }
        )
    }
}

@Composable
private fun BranchDeleteConfirmationDialog(
    branchName: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Advertencia",
                    tint = ErrorColor,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Confirmar Eliminación",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = ErrorColor
                    )
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "¿Estás seguro de que deseas eliminar la sucursal:",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "\"$branchName\"",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Esta acción no se puede deshacer.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = ErrorColor,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ErrorColor
                )
            ) {
                Text("Eliminar")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color.Gray
                )
            ) {
                Text("Cancelar")
            }
        }
    )
}

@Composable
private fun BranchDetailErrorState(
    message: String,
    onRetry: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(24.dp),
        alpha = 0.15f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "❌",
                fontSize = 64.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Error al cargar detalles",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = ErrorColor
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.Gray
                ),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateBack,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color.Gray
                    )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Volver")
                }

                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ErrorColor
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reintentar",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reintentar")
                }
            }
        }
    }
}

// Floating Action Button para acciones rápidas
@Composable
fun BranchDetailFloatingActions(
    branch: Branch,
    onCall: () -> Unit,
    onDirections: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Secondary Actions (visible when expanded)
        androidx.compose.animation.AnimatedVisibility(
            visible = isExpanded,
            enter = androidx.compose.animation.slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
            ),
            exit = androidx.compose.animation.slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)
            )
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.End
            ) {
                // Share FAB
                FloatingActionButton(
                    onClick = {
                        onShare()
                        isExpanded = false
                    },
                    containerColor = MassBlue,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Compartir",
                        tint = Color.White
                    )
                }

                // Directions FAB
                FloatingActionButton(
                    onClick = {
                        onDirections()
                        isExpanded = false
                    },
                    containerColor = MassOrange,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Direcciones",
                        tint = Color.White
                    )
                }

                // Call FAB
                FloatingActionButton(
                    onClick = {
                        onCall()
                        isExpanded = false
                    },
                    containerColor = SuccessColor,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Llamar",
                        tint = Color.White
                    )
                }
            }
        }

        // Main FAB
        FloatingActionButton(
            onClick = { isExpanded = !isExpanded },
            containerColor = if (isExpanded) ErrorColor else MassOrange,
            modifier = Modifier.size(56.dp)
        ) {
            androidx.compose.animation.AnimatedContent(
                targetState = isExpanded,
                transitionSpec = {
                    androidx.compose.animation.fadeIn() togetherWith androidx.compose.animation.fadeOut()
                },
                label = "fab_icon"
            ) { expanded ->
                Icon(
                    imageVector = if (expanded) Icons.Default.Close else Icons.Default.MoreVert,
                    contentDescription = if (expanded) "Cerrar" else "Más acciones",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

private fun makePhoneCall(context: Context, phoneNumber: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = "tel:$phoneNumber".toUri()
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Manejo de error silencioso
    }
}

private fun sendEmail(context: Context, email: String, subject: String = "", body: String = "") {
    try {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = "mailto:$email".toUri()
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Manejo de error silencioso
    }
}

private fun sendWhatsApp(context: Context, phoneNumber: String, message: String = "") {
    val cleanPhone = phoneNumber.replace(Regex("[^0-9]"), "")

    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = "https://wa.me/$cleanPhone?text=${Uri.encode(message)}".toUri()
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback a intent genérico de WhatsApp
        try {
            val fallbackIntent = Intent(Intent.ACTION_VIEW).apply {
                data = "https://wa.me/$cleanPhone".toUri()
            }
            context.startActivity(fallbackIntent)
        } catch (ex: Exception) {
            // Manejo de error silencioso
        }
    }
}

private fun shareBranch(context: Context, branch: Branch) {
    try {
        val shareText = """
            📍 ${branch.name}
            
            📧 Dirección: ${branch.address}
            📞 Teléfono: ${branch.phone}
            🗺️ Ubicación: https://maps.google.com/?q=${branch.latitude},${branch.longitude}
            
            ${if (branch.isActive) "✅ Abierta ahora" else "❌ Cerrada"}
            
            ¡Visítanos en Mass Marketplace!
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
            putExtra(Intent.EXTRA_SUBJECT, "Sucursal ${branch.name} - Mass Marketplace")
        }
        context.startActivity(Intent.createChooser(intent, "Compartir sucursal"))
    } catch (e: Exception) {
        // Manejo de error silencioso
    }
}