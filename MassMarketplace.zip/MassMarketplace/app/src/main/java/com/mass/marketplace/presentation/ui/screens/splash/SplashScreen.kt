package com.mass.marketplace.presentation.ui.screens.splash

import android.annotation.SuppressLint
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.R
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.presentation.ui.theme.*
import kotlinx.coroutines.delay
import org.koin.compose.koinInject

@Composable
fun SplashScreen(
    onNavigateToAuth: () -> Unit,
    onNavigateToHome: () -> Unit,
    sessionManager: SessionManager = koinInject()
) {
    var isVisible by remember { mutableStateOf(false) }
    var showProgress by remember { mutableStateOf(false) }

    LaunchedEffect(key1 = true) {
        // Mostrar animación inicial
        isVisible = true
        delay(800)

        // Mostrar progreso
        showProgress = true
        delay(1500)

        val hasValidSession = sessionManager.hasValidSession()

        if (hasValidSession) {
            sessionManager.updateLastLogin()
            onNavigateToHome()
        } else {
            onNavigateToAuth()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.radialGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.3f),
                        MassBlue.copy(alpha = 0.4f),
                        MassYellow.copy(alpha = 0.2f),
                        Color.Black.copy(alpha = 0.8f)
                    ),
                    radius = 1200f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Elementos de fondo animados
        AnimatedBackgroundElements(isVisible = isVisible)

        // Contenido principal
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo animado
            SplashLogo(isVisible = isVisible)

            Spacer(modifier = Modifier.height(40.dp))

            // Título y subtítulo
            SplashTitle(isVisible = isVisible)

            Spacer(modifier = Modifier.height(60.dp))

            // Indicador de progreso
            if (showProgress) {
                SplashProgress()
            }
        }

        // Versión en la parte inferior
        SplashVersion(
            isVisible = isVisible,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun SplashLogo(isVisible: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "logo")

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val scale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.3f,
        animationSpec = tween(1000, easing = FastOutSlowInEasing),
        label = "scale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = Modifier
            .size(150.dp)
            .scale(scale),
        contentAlignment = Alignment.Center
    ) {
        // Borde exterior rotando
        Box(
            modifier = Modifier
                .fillMaxSize()
                .rotate(rotation)
                .background(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            MassOrange,
                            MassYellow,
                            MassBlue,
                            MassOrange
                        )
                    ),
                    shape = RoundedCornerShape(75.dp)
                )
                .alpha(pulseAlpha)
        )

        // Borde medio
        Box(
            modifier = Modifier
                .size(130.dp)
                .rotate(-rotation * 0.5f)
                .background(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.3f),
                            Color.Transparent,
                            Color.White.copy(alpha = 0.3f),
                            Color.Transparent
                        )
                    ),
                    shape = RoundedCornerShape(65.dp)
                )
                .alpha(pulseAlpha * 0.7f)
        )

        // Logo interior fijo
        Box(
            modifier = Modifier
                .size(110.dp)
                .background(
                    Color.White.copy(alpha = 0.95f),
                    RoundedCornerShape(55.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_mass_logo),
                contentDescription = "MASS Logo",
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(45.dp)),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@SuppressLint("UseOfNonLambdaOffsetOverload")
@Composable
private fun SplashTitle(isVisible: Boolean) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 600),
        label = "alpha"
    )

    val slideY by animateFloatAsState(
        targetValue = if (isVisible) 0f else 50f,
        animationSpec = tween(800, delayMillis = 600),
        label = "slideY"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .alpha(alpha)
            .offset(y = slideY.dp)
    ) {
        Text(
            text = "MASS",
            style = MaterialTheme.typography.headlineLarge.copy(
                color = Color.White,
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Marketplace",
            style = MaterialTheme.typography.titleLarge.copy(
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Encuentra los mejores precios",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 14.sp
            )
        )
    }
}

@Composable
private fun SplashProgress() {
    val infiniteTransition = rememberInfiniteTransition(label = "progress")

    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Indicador de progreso personalizado
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(4) { index ->
                val scale by infiniteTransition.animateFloat(
                    initialValue = 0.5f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600, delayMillis = index * 150),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "dot_$index"
                )

                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .scale(scale)
                        .background(
                            MassOrange,
                            RoundedCornerShape(50)
                        )
                        .alpha(alpha)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Verificando sesión...",
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp
            ),
            modifier = Modifier.alpha(alpha)
        )
    }
}

@Composable
private fun SplashVersion(
    isVisible: Boolean,
    modifier: Modifier = Modifier
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600, delayMillis = 1000),
        label = "alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .alpha(alpha)
            .padding(bottom = 40.dp)
    ) {
        Text(
            text = "v1.0.0",
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp
            )
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "© 2025 MASS Marketplace",
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 10.sp
            )
        )
    }
}

@Composable
private fun AnimatedBackgroundElements(isVisible: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "background")

    val rotation1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation1"
    )

    val rotation2 by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(25000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation2"
    )

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 0.4f else 0f,
        animationSpec = tween(1500),
        label = "alpha"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // Elementos flotantes
        repeat(12) { index ->
            val size = (30 + index * 10).dp
            val offsetX = (index * 70).dp
            val offsetY = (index * 90).dp
            val rotation = if (index % 2 == 0) rotation1 else rotation2

            Box(
                modifier = Modifier
                    .offset(x = offsetX, y = offsetY)
                    .size(size)
                    .rotate(rotation)
                    .alpha(alpha * 0.3f)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                if (index % 3 == 0) MassOrange.copy(alpha = 0.4f)
                                else if (index % 3 == 1) MassBlue.copy(alpha = 0.4f)
                                else MassYellow.copy(alpha = 0.4f),
                                Color.Transparent
                            )
                        ),
                        shape = RoundedCornerShape(50)
                    )
                    .blur(15.dp)
            )
        }
    }
}
