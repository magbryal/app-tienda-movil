package com.mass.marketplace.domain.usecase.product

import com.mass.marketplace.domain.repository.ProductRepository

class GetProductsUseCase(
    private val productRepository: ProductRepository
) {
    suspend operator fun invoke() = productRepository.getProducts()
}
