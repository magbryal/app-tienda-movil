package com.mass.marketplace.data.repository

import android.annotation.SuppressLint
import android.util.Base64
import com.mass.marketplace.domain.repository.PaymentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

class PaymentRepositoryImpl : PaymentRepository {
    private val apiKey = "942f0e6ddf7aab0e57a1394101618031"

    @SuppressLint("CustomX509TrustManager")
    private fun createImgBBClient(): OkHttpClient {
        return try {
            val trustManager = object : X509TrustManager {
                @SuppressLint("TrustAllX509TrustManager")
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

                @SuppressLint("TrustAllX509TrustManager")
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                    if (chain.isNotEmpty()) {
                        val cert = chain[0]
                        val subjectDN = cert.subjectDN.name
                        val issuerDN = cert.issuerDN.name

                        println("Certificado recibido:")
                        println("   Subject: $subjectDN")
                        println("   Issuer: $issuerDN")

                        // Validación más permisiva para desarrollo
                        val isValid = subjectDN.contains("imgbb.com", ignoreCase = true) ||
                                subjectDN.contains("localhost", ignoreCase = true) ||
                                subjectDN.contains("127.0.0.1") ||
                                issuerDN.contains("Let's Encrypt", ignoreCase = true) ||
                                issuerDN.contains("DigiCert", ignoreCase = true) ||
                                issuerDN.contains("Cloudflare", ignoreCase = true) ||
                                issuerDN.contains("Google", ignoreCase = true)

                        if (!isValid) {
                            println("Certificado no reconocido pero permitiendo para desarrollo")
                            // En desarrollo, solo loggeamos pero no bloqueamos
                        }

                        println("Certificado aceptado")
                    }
                }

                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }

            val sslContext = SSLContext.getInstance("TLS")
            sslContext.init(null, arrayOf(trustManager), SecureRandom())

            OkHttpClient.Builder()
                .sslSocketFactory(sslContext.socketFactory, trustManager)
                .hostnameVerifier { hostname, _ ->
                    println("Verificando hostname: $hostname")

                    // Más permisivo para desarrollo
                    val isValidHostname = hostname.contains("imgbb.com", ignoreCase = true) ||
                            hostname.equals("localhost", ignoreCase = true) ||
                            hostname.equals("127.0.0.1") ||
                            hostname.startsWith("192.168.") ||
                            hostname.startsWith("10.")

                    println("Hostname ${if (isValidHostname) "aceptado" else "rechazado"}: $hostname")
                    isValidHostname
                }
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build()
        } catch (e: Exception) {
            println("Error creando cliente SSL, usando cliente básico: ${e.message}")
            OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build()
        }
    }

    override suspend fun uploadPaymentProof(imageFile: File): String {
        return withContext(Dispatchers.IO) {
            try {
                println("Iniciando subida a ImgBB...")
                println("URL destino: https://api.imgbb.com/1/upload")

                val client = createImgBBClient()

                val imageBytes = imageFile.readBytes()
                val base64Image = Base64.encodeToString(imageBytes, Base64.DEFAULT)

                val requestBody = FormBody.Builder()
                    .add("key", apiKey)
                    .add("image", base64Image)
                    .add("name", "payment_proof_${System.currentTimeMillis()}")
                    .build()

                val request = Request.Builder()
                    .url("https://api.imgbb.com/1/upload")
                    .post(requestBody)
                    .build()

                println("Enviando petición...")
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                println("Respuesta recibida: ${response.code} ${response.message}")

                if (response.isSuccessful && responseBody != null) {
                    val jsonResponse = JSONObject(responseBody)

                    if (jsonResponse.getBoolean("success")) {
                        val data = jsonResponse.getJSONObject("data")
                        val imageUrl = data.getString("url")

                        println("Imagen subida exitosamente a ImgBB: $imageUrl")
                        return@withContext imageUrl
                    } else {
                        val error = jsonResponse.optJSONObject("error")
                        val errorMessage = error?.getString("message") ?: "Error desconocido"
                        throw Exception("Error de ImgBB: $errorMessage")
                    }
                } else {
                    println("Respuesta no exitosa: ${response.code}")
                    println("Body: $responseBody")
                    throw Exception("Error HTTP: ${response.code} - ${response.message}")
                }
            } catch (e: Exception) {
                println("Error subiendo a ImgBB: ${e.message}")
                e.printStackTrace()
                throw e
            }
        }
    }
}