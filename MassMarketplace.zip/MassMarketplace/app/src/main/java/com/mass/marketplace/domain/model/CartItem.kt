package com.mass.marketplace.domain.model

data class CartItem(
    val id: String = "",
    val productId: Int,
    val productName: String,
    val productImage: String,
    val unitPrice: Double,
    val quantity: Int,
    val subtotal: Double = unitPrice * quantity,
    val store: String = "",
    val maxStock: Int = 999
)