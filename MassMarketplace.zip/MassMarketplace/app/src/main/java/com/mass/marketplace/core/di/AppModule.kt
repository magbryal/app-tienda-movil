package com.mass.marketplace.core.di

import org.koin.dsl.module

val appModule = module {
    includes(
        networkModule,
        repositoryModule,
        useCaseModule,
        viewModelModule,
        sessionManagerModule,
    )
}
