package com.mass.marketplace.domain.repository

import com.mass.marketplace.domain.model.Branch

interface BranchRepository {
    suspend fun getBranches(): Result<List<Branch>>
    suspend fun createBranch(branch: Branch): Result<String>
    suspend fun updateBranch(id: Int, branch: Branch): Result<String>
    suspend fun deleteBranch(id: Int): Result<String>
    suspend fun getBranchById(id: Int): Result<Branch>
    suspend fun getNearbyBranches(
        latitude: Double,
        longitude: Double,
        radiusKm: Double = 10.0
    ): Result<List<Branch>>
}
