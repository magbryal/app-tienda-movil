package com.mass.marketplace.data.model.request

data class BranchRequest(
    val name: String,
    val address: String,
    val phone: String,
    val schedule: String,
    val latitude: Double,
    val longitude: Double,
    val is_active: Boolean = true,
    val email: String? = null,
    val description: String? = null,
    val opening_hours: String? = null,
    val manager_id: Int? = null,
    val capacity: Int? = null,
    val has_parking: Boolean? = null,
    val has_wifi: Boolean? = null,
    val has_accessibility: Boolean? = null,
    val is_24_hours: Boolean? = null,
    val has_drive_through: Boolean? = null,
    val rating: Double? = null
)