package com.mass.marketplace.domain.model

data class Order(
    val id: String = "",
    val userId: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val tax: Double,
    val shipping: Double,
    val total: Double,
    val status: OrderStatus = OrderStatus.PENDING,
    val createdAt: String = "",
    val shippingAddress: String = "",
    val paymentMethod: String = "",
    val paymentProofUrl: String? = null
)

enum class OrderStatus {
    PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED
}