package com.mass.marketplace.presentation.ui.components.buttons

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.presentation.ui.theme.*

@Composable
fun MassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    variant: MassButtonVariant = MassButtonVariant.Primary,
    size: MassButtonSize = MassButtonSize.Large
) {
    var isPressed by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = tween(100),
        label = "scale"
    )

    val colors = when (variant) {
        MassButtonVariant.Primary -> listOf(MassOrange, MassYellow)
        MassButtonVariant.Secondary -> listOf(MassBlue, MassBlueLight)
        MassButtonVariant.Outline -> listOf(Color.Transparent, Color.Transparent)
        MassButtonVariant.Glass -> listOf(
            Color.White.copy(alpha = 0.2f),
            Color.White.copy(alpha = 0.1f)
        )
    }

    val textColor = when (variant) {
        MassButtonVariant.Primary, MassButtonVariant.Secondary -> Color.White
        MassButtonVariant.Outline -> MassOrange
        MassButtonVariant.Glass -> Color.White
    }

    val padding = when (size) {
        MassButtonSize.Small -> PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        MassButtonSize.Medium -> PaddingValues(horizontal = 20.dp, vertical = 12.dp)
        MassButtonSize.Large -> PaddingValues(horizontal = 24.dp, vertical = 16.dp)
    }

    val fontSize = when (size) {
        MassButtonSize.Small -> 14.sp
        MassButtonSize.Medium -> 16.sp
        MassButtonSize.Large -> 18.sp
    }

    Box(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .background(
                brush = if (variant == MassButtonVariant.Outline) {
                    Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                } else {
                    Brush.horizontalGradient(colors)
                }
            )
            .then(
                if (variant == MassButtonVariant.Outline) {
                    Modifier.background(
                        Color.Transparent,
                        RoundedCornerShape(12.dp)
                    )
                } else Modifier
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled
            ) {
                isPressed = true
                onClick()
                isPressed = false
            }
            .padding(padding),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor.copy(alpha = if (enabled) 1f else 0.6f),
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold
        )
    }
}

enum class MassButtonVariant {
    Primary,
    Secondary,
    Outline,
    Glass
}

enum class MassButtonSize {
    Small,
    Medium,
    Large
}