package com.mass.marketplace.presentation.ui.screens.checkout

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.mass.marketplace.core.viewmodel.CheckoutViewModel
import com.mass.marketplace.presentation.ui.components.buttons.MassButton
import com.mass.marketplace.presentation.ui.components.buttons.MassButtonVariant
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.CurrencyUtils
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import org.koin.androidx.compose.koinViewModel
import java.io.File

enum class PaymentMethod(
    val displayName: String,
    val icon: ImageVector,
    val color: List<Color>
) {
    YAPE("Yape", Icons.Default.Phone, listOf(Color(0xFF722F8B), Color(0xFF4A1B5C))),
    PLIN("Plin", Icons.Default.Call, listOf(Color(0xFF00A651), Color(0xFF007A3D))),
    CREDIT_CARD("Tarjeta de Crédito", Icons.Default.Favorite, listOf(MassBlue, MassBlueDark)),
    DEBIT_CARD("Tarjeta de Débito", Icons.Default.Face, listOf(MassOrange, MassOrangeDark)),
    CASH("Efectivo", Icons.Default.ThumbUp, listOf(SuccessColor, Color(0xFF059669)))
}

@Composable
fun CheckoutScreen(
    onNavigateBack: () -> Unit,
    onOrderComplete: () -> Unit,
    onNavigateToHome: () -> Unit,
    viewModel: CheckoutViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(key1 = true) {
        viewModel.checkUserSession()
    }

    var currentStep by remember { mutableIntStateOf(0) }
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.YAPE) }
    var isVisible by remember { mutableStateOf(false) }

    // Form states
    var shippingAddress by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var expiryDate by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }
    var cardHolderName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }

    // ESTADO PARA COMPROBANTE
    var paymentProofUri by remember { mutableStateOf<Uri?>(null) }
    var uploadedProofUrl by remember { mutableStateOf<String?>(null) }

    fun processPayment() {
        when (selectedPaymentMethod) {
            PaymentMethod.YAPE, PaymentMethod.PLIN -> {
                // Para métodos digitales, validar comprobante
                if (paymentProofUri != null) {
                    // Si hay comprobante, subir primero
                    viewModel.uploadPaymentProof(context)
                    // La URL se manejará en el LaunchedEffect de abajo
                } else {
                    println("Error: Falta comprobante para ${selectedPaymentMethod.displayName}")
                }
            }
            else -> {
                // Para otros métodos (tarjetas, efectivo)
                viewModel.createOrder(
                    shippingAddress = shippingAddress,
                    paymentMethod = selectedPaymentMethod.displayName
                )
            }
        }
    }

    LaunchedEffect(uiState.isUploadingProof, uiState.proofUploadError, uiState.uploadedProofUrl) {
        // Solo procesar si terminó de subir, no hay error y hay URL
        if (!uiState.isUploadingProof &&
            uiState.proofUploadError == null &&
            uiState.uploadedProofUrl != null &&
            paymentProofUri != null) {

            println("Creando orden con comprobante: ${uiState.uploadedProofUrl}")

            // Comprobante subido exitosamente, crear orden
            viewModel.createOrder(
                shippingAddress = shippingAddress,
                paymentMethod = selectedPaymentMethod.displayName,
                paymentProofUrl = uiState.uploadedProofUrl
            )
        }
    }

    LaunchedEffect(uiState.orderCreated) {
        if (uiState.orderCreated) {
            onOrderComplete()
            viewModel.resetOrderCreated()
        }
    }

    LaunchedEffect(key1 = true) {
        isVisible = true
    }

    val steps = listOf("Envío", "Pago", "Confirmación")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.1f),
                        Color.White,
                        MassBlue.copy(alpha = 0.05f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Header glassmorphic
            CheckoutHeader(
                currentStep = currentStep,
                steps = steps,
                onNavigateBack = onNavigateBack,
                isVisible = isVisible
            )

            // Content
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = 16.dp,
                    bottom = 100.dp
                ),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                item {
                    when (currentStep) {
                        0 -> ShippingStep(
                            address = shippingAddress,
                            onAddressChange = { shippingAddress = it },
                            isVisible = isVisible
                        )
                        1 -> PaymentStep(
                            selectedMethod = selectedPaymentMethod,
                            onMethodChange = { selectedPaymentMethod = it },
                            cardNumber = cardNumber,
                            onCardNumberChange = { cardNumber = it },
                            expiryDate = expiryDate,
                            onExpiryDateChange = { expiryDate = it },
                            cvv = cvv,
                            onCvvChange = { cvv = it },
                            cardHolderName = cardHolderName,
                            onCardHolderNameChange = { cardHolderName = it },
                            phoneNumber = phoneNumber,
                            onPhoneNumberChange = { phoneNumber = it },
                            isVisible = isVisible,
                            paymentProofUri = paymentProofUri,
                            onPaymentProofSelected = { uri ->
                                paymentProofUri = uri
                                viewModel.setPaymentProof(uri)
                            },
                            isUploadingProof = uiState.isUploadingProof,
                            proofUploadError = uiState.proofUploadError
                        )
                        2 -> ConfirmationStep(
                            paymentMethod = selectedPaymentMethod,
                            shippingAddress = shippingAddress,
                            subtotal = uiState.subtotal,
                            tax = uiState.tax,
                            shipping = uiState.shipping,
                            total = uiState.total,
                            userInfo = uiState.userInfo,
                            isVisible = isVisible
                        )
                    }
                }
            }
        }

        // Bottom buttons flotantes
        CheckoutBottomBar(
            currentStep = currentStep,
            totalSteps = steps.size,
            isProcessingPayment = uiState.isProcessingPayment,
            onNext = {
                if (currentStep < steps.size - 1) {
                    currentStep++
                } else {
                    processPayment()
                }
            },
            onBack = {
                if (currentStep > 0) {
                    currentStep--
                }
            },
            onComplete = ::processPayment,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )

        // Payment processing overlay
        if (uiState.isProcessingPayment) {
            PaymentProcessingOverlay(
                onComplete = {
                    // El overlay se maneja automáticamente por el estado
                }
            )
        }
    }

    // Error handling
    uiState.errorMessage?.let { error ->
        LaunchedEffect(error) {
            println("Error en checkout: $error")
            viewModel.clearError()
        }
    }
}

@Composable
fun PaymentProofSection(
    onImageSelected: (Uri) -> Unit,
    selectedImageUri: Uri? = null,
    isUploading: Boolean = false,
    uploadError: String? = null
) {
    val context = LocalContext.current
    var tempImageUri by remember { mutableStateOf<Uri?>(null) }
    var showPermissionDialog by remember { mutableStateOf(false) }

    // Launcher para galería
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { onImageSelected(it) }
    }

    // Launcher para cámara
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempImageUri != null) {
            onImageSelected(tempImageUri!!)
        }
    }

    // Launcher para permisos de cámara
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val imageFile = File(context.cacheDir, "payment_proof_${System.currentTimeMillis()}.jpg")
            tempImageUri = try {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    imageFile
                )
            } catch (e: Exception) {
                println("Error creando URI: ${e.message}")
                null
            }

            tempImageUri?.let { uri ->
                cameraLauncher.launch(uri)
            }
        } else {
            showPermissionDialog = true
        }
    }

    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.1f,
        cornerRadius = 16.dp
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.FavoriteBorder,
                    contentDescription = "Comprobante",
                    tint = MassOrange,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Comprobante de pago",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedImageUri != null && selectedImageUri != Uri.EMPTY) {
                // Mostrar imagen seleccionada con estado de carga
                PaymentProofPreview(
                    imageUri = selectedImageUri,
                    onRemove = { onImageSelected(Uri.EMPTY) },
                    isUploading = isUploading,
                    uploadError = uploadError
                )
            } else {
                // Botones para seleccionar imagen
                Column {
                    Text(
                        text = "Sube tu comprobante de pago para confirmar la transacción",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.Gray
                        ),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MassButton(
                            text = "📱 Galería",
                            onClick = { launcher.launch("image/*") },
                            variant = MassButtonVariant.Outline,
                            modifier = Modifier.weight(1f),
                            enabled = !isUploading
                        )

                        MassButton(
                            text = "📷 Cámara",
                            onClick = {
                                when (PackageManager.PERMISSION_GRANTED) {
                                    ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.CAMERA
                                    ) -> {
                                        val imageFile = File(context.cacheDir, "payment_proof_${System.currentTimeMillis()}.jpg")
                                        tempImageUri = try {
                                            FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                imageFile
                                            )
                                        } catch (e: Exception) {
                                            println("Error creando URI: ${e.message}")
                                            null
                                        }

                                        tempImageUri?.let { uri ->
                                            cameraLauncher.launch(uri)
                                        }
                                    }
                                    else -> {
                                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = !isUploading
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mostrar error de subida si existe
            if (uploadError != null) {
                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth(),
                    alpha = 0.1f,
                    cornerRadius = 8.dp
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Error",
                            tint = ErrorColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = uploadError,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = ErrorColor
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Información sobre formatos aceptados
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                alpha = 0.1f,
                cornerRadius = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Aceptado",
                        tint = SuccessColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Formatos: JPG, PNG • Tamaño máx: 5MB",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }

    // Dialog de permisos
    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = {
                Text(
                    text = "Permiso de Cámara",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            },
            text = {
                Text(
                    text = "Para tomar fotos del comprobante, necesitamos acceso a tu cámara. Puedes habilitarlo en Configuración > Aplicaciones > Mass Marketplace > Permisos.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                MassButton(
                    text = "Configuración",
                    onClick = {
                        showPermissionDialog = false
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                        context.startActivity(intent)
                    }
                )
            },
            dismissButton = {
                TextButton(
                    onClick = { showPermissionDialog = false }
                ) {
                    Text(
                        text = "Cancelar",
                        color = Color.Gray
                    )
                }
            }
        )
    }
}

@Composable
private fun PaymentProofPreview(
    imageUri: Uri,
    onRemove: () -> Unit,
    isUploading: Boolean = false,
    uploadError: String? = null
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.1f,
        cornerRadius = 12.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    when {
                        isUploading -> {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MassOrange,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Subiendo comprobante...",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = MassOrange,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        uploadError != null -> {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error",
                                tint = ErrorColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Error al subir",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = ErrorColor,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        else -> {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Completado",
                                tint = SuccessColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Comprobante listo",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = SuccessColor,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                if (!isUploading) {
                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(ErrorColor.copy(alpha = 0.1f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Eliminar",
                            tint = ErrorColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Imagen con overlay de estado
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = "Comprobante de pago",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = rememberVectorPainter(Icons.Default.ShoppingCart),
                    error = rememberVectorPainter(Icons.Default.Clear)
                )

                // Overlay con estado
                if (isUploading) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Subiendo...",
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                } else if (uploadError == null) {
                    // Overlay de éxito
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.7f)
                                    )
                                )
                            )
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "✓ Imagen lista para enviar",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckoutHeader(
    currentStep: Int,
    steps: List<String>,
    onNavigateBack: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        alpha = 0.15f,
        cornerRadius = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .statusBarsPadding()
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(48.dp),
                        alpha = 0.2f,
                        cornerRadius = 24.dp,
                        onClick = onNavigateBack
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver",
                                tint = MassOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Text(
                        text = "Finalizar Compra",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassBlue
                        )
                    )
                }

                // Security badge
                GlassmorphicCard(
                    alpha = 0.1f,
                    cornerRadius = 16.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Seguro",
                            tint = SuccessColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Seguro",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SuccessColor,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Progress indicator glassmorphic
            StepProgressIndicator(
                currentStep = currentStep,
                steps = steps
            )
        }
    }
}

@Composable
private fun StepProgressIndicator(
    currentStep: Int,
    steps: List<String>
) {
    Column {
        // Círculos y líneas
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            steps.forEachIndexed { index, _ ->
                // Step circle glassmorphic
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = if (index <= currentStep) 0.3f else 0.1f,
                    cornerRadius = 20.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = if (index <= currentStep) {
                                    Brush.radialGradient(
                                        colors = listOf(MassOrange, MassYellow)
                                    )
                                } else {
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color.Gray.copy(alpha = 0.3f),
                                            Color.Gray.copy(alpha = 0.1f)
                                        )
                                    )
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (index < currentStep) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Completado",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Text(
                                text = (index + 1).toString(),
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = if (index <= currentStep) Color.White else Color.Gray,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                // Línea conectora (excepto el último)
                if (index < steps.size - 1) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(2.dp)
                            .padding(horizontal = 8.dp)
                            .background(
                                brush = if (index < currentStep) {
                                    Brush.horizontalGradient(
                                        colors = listOf(MassOrange, MassYellow)
                                    )
                                } else {
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            Color.Gray.copy(alpha = 0.3f),
                                            Color.Gray.copy(alpha = 0.1f)
                                        )
                                    )
                                }
                            )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Step names
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            steps.forEachIndexed { index, step ->
                Text(
                    text = step,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = if (index <= currentStep) MassBlue else Color.Gray,
                        fontWeight = if (index == currentStep) FontWeight.Bold else FontWeight.Normal
                    ),
                    modifier = Modifier.width(80.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun ShippingStep(
    address: String,
    onAddressChange: (String) -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        Text(
            text = "Dirección de Envío",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Campo de dirección glassmorphic
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            OutlinedTextField(
                value = address,
                onValueChange = onAddressChange,
                label = {
                    Text(
                        "Dirección completa",
                        color = MassBlue.copy(alpha = 0.7f)
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MassOrange,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = MassBlue,
                    unfocusedTextColor = MassBlue
                ),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Dirección",
                        tint = MassOrange
                    )
                },
                placeholder = {
                    Text(
                        "Ej: Av. Javier Prado 123, San Isidro, Lima",
                        color = Color.Gray
                    )
                },
                minLines = 2
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick address options
        Text(
            text = "Direcciones guardadas",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = MassBlue
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        val savedAddresses = listOf(
            "Casa" to "Av. Javier Prado 123, San Isidro, Lima",
            "Trabajo" to "Jr. Lampa 456, Cercado de Lima, Lima"
        )

        savedAddresses.forEach { (label, savedAddress) ->
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onAddressChange(savedAddress) },
                alpha = if (address == savedAddress) 0.2f else 0.1f,
                cornerRadius = 16.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (label == "Casa") Icons.Default.Home else Icons.Default.Home,
                        contentDescription = null,
                        tint = MassOrange,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MassBlue
                            )
                        )
                        Text(
                            text = savedAddress,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun PaymentStep(
    selectedMethod: PaymentMethod,
    onMethodChange: (PaymentMethod) -> Unit,
    cardNumber: String,
    onCardNumberChange: (String) -> Unit,
    expiryDate: String,
    onExpiryDateChange: (String) -> Unit,
    cvv: String,
    onCvvChange: (String) -> Unit,
    cardHolderName: String,
    onCardHolderNameChange: (String) -> Unit,
    phoneNumber: String,
    onPhoneNumberChange: (String) -> Unit,
    isVisible: Boolean,
    // NUEVOS PARÁMETROS PARA COMPROBANTE
    paymentProofUri: Uri? = null,
    onPaymentProofSelected: (Uri) -> Unit = {},
    isUploadingProof: Boolean = false,
    proofUploadError: String? = null
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        Text(
            text = "Método de Pago",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Payment methods glassmorphic
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(PaymentMethod.entries) { method ->
                PaymentMethodCard(
                    method = method,
                    isSelected = selectedMethod == method,
                    onClick = { onMethodChange(method) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Payment form based on selected method
        when (selectedMethod) {
            PaymentMethod.YAPE -> {
                YapeForm(
                    phoneNumber = phoneNumber,
                    onPhoneNumberChange = onPhoneNumberChange
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Sección de comprobante para Yape
                PaymentProofSection(
                    onImageSelected = onPaymentProofSelected,
                    selectedImageUri = paymentProofUri,
                    isUploading = isUploadingProof,
                    uploadError = proofUploadError
                )
            }
            PaymentMethod.PLIN -> {
                PlinForm(
                    phoneNumber = phoneNumber,
                    onPhoneNumberChange = onPhoneNumberChange
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Sección de comprobante para Plin
                PaymentProofSection(
                    onImageSelected = onPaymentProofSelected,
                    selectedImageUri = paymentProofUri,
                    isUploading = isUploadingProof,
                    uploadError = proofUploadError
                )
            }
            PaymentMethod.CREDIT_CARD, PaymentMethod.DEBIT_CARD -> {
                CreditCardForm(
                    cardNumber = cardNumber,
                    onCardNumberChange = onCardNumberChange,
                    expiryDate = expiryDate,
                    onExpiryDateChange = onExpiryDateChange,
                    cvv = cvv,
                    onCvvChange = onCvvChange,
                    cardHolderName = cardHolderName,
                    onCardHolderNameChange = onCardHolderNameChange
                )
            }
            PaymentMethod.CASH -> {
                CashPaymentInfo()
            }
        }
    }
}

@Composable
private fun PaymentMethodCard(
    method: PaymentMethod,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .width(120.dp)
            .height(80.dp),
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = if (isSelected) {
                        Brush.linearGradient(method.color)
                    } else {
                        Brush.linearGradient(
                            listOf(
                                Color.Gray.copy(alpha = 0.1f),
                                Color.Gray.copy(alpha = 0.05f)
                            )
                        )
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = method.icon,
                    contentDescription = method.displayName,
                    tint = if (isSelected) Color.White else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = method.displayName.split(" ").first(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (isSelected) Color.White else Color.Gray,
                        fontWeight = FontWeight.Medium
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun YapeForm(
    phoneNumber: String,
    onPhoneNumberChange: (String) -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.1f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Yape logo/icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF722F8B), Color(0xFF4A1B5C))
                        ),
                        shape = RoundedCornerShape(40.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Yape",
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Pagar con Yape",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Yapea al número: +51 987 654 321",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color(0xFF722F8B),
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Phone number input
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { value ->
                    // Solo números y máximo 9 dígitos
                    if (value.all { it.isDigit() } && value.length <= 9) {
                        onPhoneNumberChange(value)
                    }
                },
                label = { Text("Tu número de celular") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF722F8B),
                    focusedLabelColor = Color(0xFF722F8B)
                ),
                leadingIcon = {
                    Text(
                        text = "+51",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFF722F8B),
                            fontWeight = FontWeight.Medium
                        )
                    )
                },
                placeholder = { Text("987654321") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Instrucciones de pago
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                alpha = 0.1f,
                cornerRadius = 12.dp
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Información",
                            tint = Color(0xFF722F8B),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Instrucciones de pago:",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = Color(0xFF722F8B),
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val instructions = listOf(
                        "1. Abre tu app de Yape",
                        "2. Yapea al +51 987 654 321",
                        "3. Toma captura del comprobante",
                        "4. Sube la imagen aquí abajo"
                    )

                    instructions.forEach { instruction ->
                        Text(
                            text = instruction,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            ),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlinForm(
    phoneNumber: String,
    onPhoneNumberChange: (String) -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.1f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Plin logo/icon
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF00A651), Color(0xFF007A3D))
                        ),
                        shape = RoundedCornerShape(40.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = "Plin",
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Pagar con Plin",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Transfiere al número: +51 987 654 321",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color(0xFF00A651),
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Phone number input
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { value ->
                    if (value.all { it.isDigit() } && value.length <= 9) {
                        onPhoneNumberChange(value)
                    }
                },
                label = { Text("Tu número de celular") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00A651),
                    focusedLabelColor = Color(0xFF00A651)
                ),
                leadingIcon = {
                    Text(
                        text = "+51",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFF00A651),
                            fontWeight = FontWeight.Medium
                        )
                    )
                },
                placeholder = { Text("987654321") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Instrucciones de pago
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                alpha = 0.1f,
                cornerRadius = 12.dp
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Información",
                            tint = Color(0xFF00A651),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Instrucciones de pago:",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = Color(0xFF00A651),
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val instructions = listOf(
                        "1. Abre tu app de Plin",
                        "2. Transfiere al +51 987 654 321",
                        "3. Guarda el comprobante",
                        "4. Sube la imagen aquí abajo"
                    )

                    instructions.forEach { instruction ->
                        Text(
                            text = instruction,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            ),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CreditCardForm(
    cardNumber: String,
    onCardNumberChange: (String) -> Unit,
    expiryDate: String,
    onExpiryDateChange: (String) -> Unit,
    cvv: String,
    onCvvChange: (String) -> Unit,
    cardHolderName: String,
    onCardHolderNameChange: (String) -> Unit
) {
    Column {
        // Card preview glassmorphic
        CreditCardPreview(
            cardNumber = cardNumber,
            expiryDate = expiryDate,
            cardHolderName = cardHolderName
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Form fields
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            alpha = 0.1f,
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                // Card number
                OutlinedTextField(
                    value = cardNumber,
                    onValueChange = { value ->
                        val formatted = value.replace(" ", "").chunked(4).joinToString(" ")
                        if (formatted.replace(" ", "").length <= 16) {
                            onCardNumberChange(formatted)
                        }
                    },
                    label = { Text("Número de tarjeta") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MassOrange
                    ),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Tarjeta",
                            tint = MassOrange
                        )
                    },
                    placeholder = { Text("1234 5678 9012 3456") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Expiry and CVV
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = expiryDate,
                        onValueChange = { value ->
                            val formatted = value.replace("/", "")
                            if (formatted.length <= 4) {
                                val result = if (formatted.length >= 2) {
                                    "${formatted.substring(0, 2)}/${formatted.substring(2)}"
                                } else {
                                    formatted
                                }
                                onExpiryDateChange(result)
                            }
                        },
                        label = { Text("MM/AA") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MassOrange
                        ),
                        placeholder = { Text("12/25") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = cvv,
                        onValueChange = { value ->
                            if (value.length <= 3) {
                                onCvvChange(value)
                            }
                        },
                        label = { Text("CVV") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MassOrange
                        ),
                        placeholder = { Text("123") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Cardholder name
                OutlinedTextField(
                    value = cardHolderName,
                    onValueChange = onCardHolderNameChange,
                    label = { Text("Nombre del titular") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MassOrange
                    ),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Titular",
                            tint = MassOrange
                        )
                    },
                    placeholder = { Text("Juan Pérez") },
                    singleLine = true
                )
            }
        }
    }
}

@Composable
private fun CreditCardPreview(
    cardNumber: String,
    expiryDate: String,
    cardHolderName: String
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        alpha = 0.2f,
        cornerRadius = 20.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(MassOrange, MassYellow, MassBlue),
                        start = androidx.compose.ui.geometry.Offset(0f, 0f),
                        end = androidx.compose.ui.geometry.Offset(1000f, 1000f)
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Card header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MASS CARD",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    GlassmorphicCard(
                        modifier = Modifier.size(40.dp),
                        alpha = 0.3f,
                        cornerRadius = 8.dp
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Chip",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                // Card number
                Text(
                    text = if (cardNumber.isNotEmpty()) cardNumber else "•••• •••• •••• ••••",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                )

                // Card footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "TITULAR",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        )
                        Text(
                            text = if (cardHolderName.isNotEmpty()) cardHolderName.uppercase() else "NOMBRE APELLIDO",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }

                    Column {
                        Text(
                            text = "VÁLIDA HASTA",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        )
                        Text(
                            text = if (expiryDate.isNotEmpty()) expiryDate else "MM/AA",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CashPaymentInfo() {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.1f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription = "Efectivo",
                    tint = SuccessColor,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Pago en Efectivo",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Instrucciones:",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            val instructions = listOf(
                "1. Confirma tu pedido",
                "2. Recibirás un código de referencia",
                "3. Paga en cualquier agente BCP, Interbank o Scotiabank",
                "4. Tu pedido se procesará automáticamente"
            )

            instructions.forEach { instruction ->
                Text(
                    text = instruction,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    ),
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                alpha = 0.1f,
                cornerRadius = 12.dp
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Información",
                        tint = WarningColor,
                        modifier = Modifier.                        size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "El pedido se reservará por 24 horas",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = WarningColor,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ConfirmationStep(
    paymentMethod: PaymentMethod,
    shippingAddress: String,
    subtotal: Double,
    tax: Double,
    shipping: Double,
    total: Double,
    userInfo: com.mass.marketplace.data.local.UserInfo?,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        Text(
            text = "Confirmar",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        userInfo?.let { user ->
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                alpha = 0.1f,
                cornerRadius = 16.dp
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Usuario",
                        tint = MassOrange,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Pedido para:",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = Color.Gray
                            )
                        )
                        Text(
                            text = user.email,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = MassBlue
                            )
                        )
                        if (user.name.isNotEmpty()) {
                            Text(
                                text = user.name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.Gray
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Order summary glassmorphic
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            alpha = 0.15f,
            cornerRadius = 24.dp
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "Resumen del Pedido",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Shipping info
                OrderInfoRow(
                    label = "Envío a:",
                    value = shippingAddress.ifEmpty { "No especificado" },
                    icon = Icons.Default.LocationOn
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Payment method
                OrderInfoRow(
                    label = "Método de pago:",
                    value = paymentMethod.displayName,
                    icon = paymentMethod.icon
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Estimated delivery
                OrderInfoRow(
                    label = "Entrega estimada:",
                    value = "3-5 días hábiles",
                    icon = Icons.Default.DateRange
                )

                Spacer(modifier = Modifier.height(20.dp))

                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth(),
                    alpha = 0.1f,
                    cornerRadius = 16.dp
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Subtotal:",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.Gray
                                )
                            )
                            Text(
                                text = CurrencyUtils.formatPEN(subtotal),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "IGV (18%):",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.Gray
                                )
                            )
                            Text(
                                text = CurrencyUtils.formatPEN(tax),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Envío:",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.Gray
                                )
                            )
                            Text(
                                text = if (shipping == 0.0) "GRATIS" else CurrencyUtils.formatPEN(shipping),
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = if (shipping == 0.0) SuccessColor else MassBlue
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color.Gray.copy(alpha = 0.3f))
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Total:",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MassBlue
                                )
                            )
                            Text(
                                text = CurrencyUtils.formatPEN(total),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MassOrange
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Terms and conditions glassmorphic
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Información",
                    tint = MassBlue,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Al confirmar aceptas nuestros",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                    Text(
                        text = "Términos y Condiciones",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MassOrange,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun OrderInfoRow(
    label: String,
    value: String,
    icon: ImageVector
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MassOrange,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = Color.Gray
                )
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = MassBlue
                )
            )
        }
    }
}

@Composable
private fun CheckoutBottomBar(
    currentStep: Int,
    totalSteps: Int,
    isProcessingPayment: Boolean,
    onNext: () -> Unit,
    onBack: () -> Unit,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.fillMaxWidth(),
        alpha = 0.5f,
        cornerRadius = 20.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Back button
            if (currentStep > 0) {
                MassButton(
                    text = "Atrás",
                    onClick = onBack,
                    variant = MassButtonVariant.Outline,
                    modifier = Modifier.weight(1f),
                    enabled = !isProcessingPayment
                )
            }

            // Next/Complete button
            MassButton(
                text = when {
                    isProcessingPayment -> "Procesando..."
                    currentStep == totalSteps - 1 -> "Confirmar"
                    else -> "Continuar"
                },
                onClick = if (currentStep == totalSteps - 1) onComplete else onNext,
                modifier = Modifier.weight(if (currentStep > 0) 2f else 1f),
                enabled = !isProcessingPayment
            )
        }
    }
}

@Composable
private fun PaymentProcessingOverlay(
    onComplete: () -> Unit
) {
    var progress by remember { mutableStateOf(0f) }
    var currentMessage by remember { mutableStateOf("Procesando pago...") }

    val messages = listOf(
        "Procesando pago..." to 0.3f,
        "Verificando información..." to 0.6f,
        "Confirmando pedido..." to 0.9f,
        "¡Pago exitoso!" to 1f
    )

    LaunchedEffect(key1 = true) {
        messages.forEach { (message, targetProgress) ->
            currentMessage = message
            while (progress < targetProgress) {
                progress += 0.01f
                kotlinx.coroutines.delay(50)
            }
            kotlinx.coroutines.delay(500)
        }
        kotlinx.coroutines.delay(1000)
        onComplete()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.8f)),
        contentAlignment = Alignment.Center
    ) {
        GlassmorphicCard(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .padding(32.dp),
            alpha = 0.9f,
            cornerRadius = 24.dp
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Animated icon
                val rotation by rememberInfiniteTransition(label = "rotation").animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(2000, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "rotation"
                )

                GlassmorphicCard(
                    modifier = Modifier.size(80.dp),
                    alpha = 0.3f,
                    cornerRadius = 40.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = if (progress >= 1f) {
                                    Brush.radialGradient(
                                        colors = listOf(SuccessColor, Color(0xFF059669))
                                    )
                                } else {
                                    Brush.radialGradient(
                                        colors = listOf(MassOrange, MassYellow)
                                    )
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (progress >= 1f) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Éxito",
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Procesando",
                                tint = Color.White,
                                modifier = Modifier
                                    .size(40.dp)
                                    .graphicsLayer { rotationZ = rotation }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = currentMessage,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Progress bar glassmorphic
                GlassmorphicCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp),
                    alpha = 0.2f,
                    cornerRadius = 4.dp
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progress)
                                .background(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(MassOrange, MassYellow)
                                    ),
                                    shape = RoundedCornerShape(4.dp)
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}
