package com.mass.marketplace.data.repository

import com.mass.marketplace.core.network.ApiService
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.data.model.request.BranchRequest
import com.mass.marketplace.data.model.response.toDomain
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.repository.BranchRepository
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class BranchRepositoryImpl(
    private val apiService: ApiService,
    private val sessionManager: SessionManager
) : BranchRepository {

    override suspend fun getBranches(): Result<List<Branch>> {
        return try {
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            println("BranchRepository: Obteniendo sucursales...")
            val response = apiService.getBranches()
            println("Respuesta cruda del API: $response")

            val branches = response.map { it.toDomain() }

            println("Sucursales procesadas: ${branches.size}")
            branches.forEach { branch ->
                println("Sucursal: ${branch.name} (ID: ${branch.id}) - Activa: ${branch.isActive}")
            }

            Result.success(branches)
        } catch (e: Exception) {
            val errorMessage = handleApiError(e)
            println("Error al obtener sucursales: $errorMessage")
            Result.failure(Exception(errorMessage))
        }
    }

    override suspend fun getNearbyBranches(
        latitude: Double,
        longitude: Double,
        radiusKm: Double
    ): Result<List<Branch>> {
        return try {
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            println("BranchRepository: Obteniendo sucursales cercanas...")
            println("   - Ubicación: ($latitude, $longitude)")
            println("   - Radio: ${radiusKm}km")

            val response = apiService.getNearbyBranches(latitude, longitude, radiusKm)
            val branches = response.map { it.toDomain() }

            println("Sucursales cercanas encontradas: ${branches.size}")
            branches.forEach { branch ->
                val distance = branch.distanceTo(latitude, longitude)
                println("   - ${branch.name}: ${"%.2f".format(distance)}km")
            }

            Result.success(branches)
        } catch (e: Exception) {
            val errorMessage = handleApiError(e)
            println("Error al obtener sucursales cercanas: $errorMessage")
            Result.failure(Exception(errorMessage))
        }
    }

    override suspend fun createBranch(branch: Branch): Result<String> {
        return try {
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            println("BranchRepository: Creando sucursal...")
            println("   - Nombre: ${branch.name}")
            println("   - Dirección: ${branch.address}")
            println("   - Teléfono: ${branch.phone}")

            val request = BranchRequest(
                name = branch.name,
                address = branch.address,
                phone = branch.phone,
                schedule = branch.schedule,
                latitude = branch.latitude,
                longitude = branch.longitude,
                is_active = branch.isActive,
                email = branch.email,
                description = branch.description,
                opening_hours = branch.openingHours,
                manager_id = branch.managerId,
                capacity = branch.capacity,
                has_parking = branch.hasParking,
                has_wifi = branch.hasWifi,
                has_accessibility = branch.hasAccessibility,
                is_24_hours = branch.is24Hours,
                has_drive_through = branch.hasDriveThrough,
                rating = branch.rating
            )

            val response = apiService.createBranch(request)
            val message = response["message"] ?: "Sucursal creada exitosamente"

            println("Sucursal creada: $message")
            Result.success(message)
        } catch (e: Exception) {
            val errorMessage = handleApiError(e)
            println("Error al crear sucursal: $errorMessage")
            Result.failure(Exception(errorMessage))
        }
    }

    override suspend fun updateBranch(id: Int, branch: Branch): Result<String> {
        return try {
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            println("BranchRepository: Actualizando sucursal ID: $id")

            val request = BranchRequest(
                name = branch.name,
                address = branch.address,
                phone = branch.phone,
                schedule = branch.schedule,
                latitude = branch.latitude,
                longitude = branch.longitude,
                is_active = branch.isActive,
                email = branch.email,
                description = branch.description,
                opening_hours = branch.openingHours,
                manager_id = branch.managerId,
                capacity = branch.capacity,
                has_parking = branch.hasParking,
                has_wifi = branch.hasWifi,
                has_accessibility = branch.hasAccessibility,
                is_24_hours = branch.is24Hours,
                has_drive_through = branch.hasDriveThrough,
                rating = branch.rating
            )

            val response = apiService.updateBranch(id, request)
            val message = response["message"] ?: "Sucursal actualizada exitosamente"

            println("Sucursal actualizada: $message")
            Result.success(message)
        } catch (e: Exception) {
            val errorMessage = handleApiError(e)
            println("Error al actualizar sucursal: $errorMessage")
            Result.failure(Exception(errorMessage))
        }
    }

    override suspend fun deleteBranch(id: Int): Result<String> {
        return try {
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            println("BranchRepository: Eliminando sucursal ID: $id")

            val response = apiService.deleteBranch(id)
            val message = response["message"] ?: "Sucursal eliminada exitosamente"

            println("Sucursal eliminada: $message")
            Result.success(message)
        } catch (e: Exception) {
            val errorMessage = handleApiError(e)
            println("Error al eliminar sucursal: $errorMessage")
            Result.failure(Exception(errorMessage))
        }
    }

    override suspend fun getBranchById(id: Int): Result<Branch> {
        return try {
            val branchesResult = getBranches()
            branchesResult.fold(
                onSuccess = { branches ->
                    val branch = branches.find { it.id == id }
                    if (branch != null) {
                        Result.success(branch)
                    } else {
                        Result.failure(Exception("Sucursal no encontrada"))
                    }
                },
                onFailure = { error ->
                    Result.failure(error)
                }
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun handleApiError(e: Exception): String {
        return when (e) {
            is HttpException -> {
                when (e.code()) {
                    401 -> {
                        sessionManager.clearSession()
                        "Sesión expirada. Por favor, inicia sesión nuevamente."
                    }
                    403 -> "No tienes permisos para realizar esta acción."
                    404 -> "Sucursal no encontrada."
                    422 -> "Datos inválidos. Verifica la información ingresada."
                    500 -> "Error del servidor. Inténtalo más tarde."
                    else -> "Error HTTP ${e.code()}: ${e.message()}"
                }
            }
            is UnknownHostException -> "No se pudo conectar al servidor. Verifica tu conexión a internet."
            is ConnectException -> "Error de conexión. Asegúrate de que el servidor esté disponible."
            is SocketTimeoutException -> "Tiempo de espera agotado. Inténtalo de nuevo."
            else -> "Error: ${e.message}"
        }
    }
}