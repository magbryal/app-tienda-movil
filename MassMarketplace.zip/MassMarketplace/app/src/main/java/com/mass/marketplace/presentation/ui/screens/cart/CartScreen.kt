package com.mass.marketplace.presentation.ui.screens.cart

import android.annotation.SuppressLint
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mass.marketplace.core.viewmodel.CartViewModel
import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.presentation.ui.components.buttons.MassButton
import com.mass.marketplace.presentation.ui.components.buttons.MassButtonVariant
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import kotlinx.coroutines.delay
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    onNavigateBack: () -> Unit,
    onNavigateToCheckout: () -> Unit,
    onNavigateToProducts: () -> Unit,
    viewModel: CartViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    val uiState by viewModel.uiState.collectAsState()
    var isVisible by remember { mutableStateOf(false) }
    var showItemAddedSnackbar by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(key1 = true) {
        isVisible = true
    }

    // Observar cambios en el carrito para mostrar feedback
    LaunchedEffect(uiState.items.size) {
        if (uiState.items.isNotEmpty() && isVisible) {
            showItemAddedSnackbar = true
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            MassOrange.copy(alpha = 0.05f),
                            Color.White,
                            MassBlue.copy(alpha = 0.03f)
                        )
                    )
                )
        ) {
            // Header
            CartHeader(
                itemCount = uiState.items.sumOf { it.quantity },
                onNavigateBack = onNavigateBack,
                onClearCart = { viewModel.clearCart() },
                isVisible = isVisible
            )

            if (uiState.items.isEmpty()) {
                // Empty cart state
                EmptyCartState(
                    onNavigateToProducts = onNavigateToProducts,
                    isVisible = isVisible
                )
            } else {
                // Cart content
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(
                        items = uiState.items,
                        key = { it.productId }
                    ) { item ->
                        CartItemCard(
                            item = item,
                            onQuantityChange = { newQuantity ->
                                if (newQuantity > 0) {
                                    viewModel.updateQuantity(item.productId, newQuantity)
                                } else {
                                    viewModel.removeFromCart(item.productId)
                                }
                            },
                            onRemove = {
                                viewModel.removeFromCart(item.productId)
                            }
                        )
                    }

                    // Summary card
                    item {
                        CartSummaryCard(
                            subtotal = uiState.subtotal,
                            tax = uiState.tax,
                            shipping = uiState.shipping,
                            total = uiState.total
                        )
                    }

                    // Spacer para el botón flotante
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }

                // Checkout button flotante
                CheckoutButton(
                    total = uiState.total,
                    itemCount = uiState.items.sumOf { it.quantity },
                    onCheckout = onNavigateToCheckout,
                    onContinueShopping = onNavigateToProducts,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        // Snackbar Host
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }

    // Error handling
    uiState.errorMessage?.let { error ->
        LaunchedEffect(error) {
            snackbarHostState.showSnackbar(
                message = error,
                duration = SnackbarDuration.Short
            )
            viewModel.clearError()
        }
    }
}

@Composable
private fun CartHeader(
    itemCount: Int,
    onNavigateBack: () -> Unit,
    onClearCart: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
            .background(Color.White)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MassOrange.copy(alpha = 0.1f))
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Volver",
                    tint = MassOrange
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "Mi Carrito",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
                if (itemCount > 0) {
                    Text(
                        text = "$itemCount ${if (itemCount == 1) "producto" else "productos"}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }

        // Clear cart button
        if (itemCount > 0) {
            TextButton(
                onClick = onClearCart
            ) {
                Text(
                    text = "Limpiar",
                    color = ErrorColor
                )
            }
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun CheckoutButton(
    total: Double,
    itemCount: Int,
    onCheckout: () -> Unit,
    onContinueShopping: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            // Resumen rápido mejorado
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total del pedido",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Text(
                        text = "S/.${String.format("%.2f", total)}",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassOrange
                        )
                    )
                }

                // Badge con cantidad de productos
                GlassmorphicCard(
                    alpha = 0.15f,
                    cornerRadius = 12.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Productos",
                            tint = MassBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$itemCount ${if (itemCount == 1) "producto" else "productos"}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MassBlue,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Información de entrega
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Entrega",
                    tint = SuccessColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Entrega estimada: 2-3 días hábiles",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Botones mejorados
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onContinueShopping,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MassBlue
                    ),
                    border = BorderStroke(2.dp, MassBlue.copy(alpha = 0.3f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Continuar",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Seguir",
                        fontWeight = FontWeight.Medium
                    )
                }

                Button(
                    onClick = onCheckout,
                    modifier = Modifier
                        .weight(1.5f)
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MassOrange,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(
                        defaultElevation = 6.dp,
                        pressedElevation = 2.dp
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Pagar",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Proceder",
                        fontWeight = FontWeight.Normal,
                        fontSize = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Métodos de pago aceptados
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Métodos de pago: ",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    )
                )
                Icon(
                    imageVector = Icons.Default.Face,
                    contentDescription = "Tarjetas",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Banco",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Billetera",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyCartState(
    onNavigateToProducts: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .alpha(alpha)
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            alpha = 0.1f,
            cornerRadius = 24.dp
        ) {
            Column(
                modifier = Modifier.padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🛒",
                    fontSize = 80.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "Tu carrito está vacío",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Explora nuestros productos y encuentra lo que necesitas",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(32.dp))

                MassButton(
                    text = "Explorar Productos",
                    onClick = onNavigateToProducts,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun CartItemCard(
    item: CartItem,
    onQuantityChange: (Int) -> Unit,
    onRemove: () -> Unit
) {
    var showRemoveDialog by remember { mutableStateOf(false) }
    var isUpdating by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(16.dp)
        ) {
            // Primera fila: Imagen y info básica del producto
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Product image
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MassOrange.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (item.productImage.isNotEmpty()) {
                        AsyncImage(
                            model = item.productImage,
                            contentDescription = item.productName,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                            placeholder = rememberVectorPainter(Icons.Default.ShoppingCart),
                            error = rememberVectorPainter(Icons.Default.ShoppingCart)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Producto",
                            tint = MassOrange,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Product info
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = item.productName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MassBlue
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (item.store.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.store,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Precio unitario
                    Text(
                        text = "Precio: S/.${String.format("%.2f", item.unitPrice)}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = MassOrange
                        )
                    )
                }

                // Remove button (top right)
                IconButton(
                    onClick = { showRemoveDialog = true },
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ErrorColor.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Eliminar",
                        tint = ErrorColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Divider
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color.Gray.copy(alpha = 0.2f))
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Segunda fila: Controles de cantidad y totales
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity controls
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Cantidad",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    GlassmorphicCard(
                        alpha = 0.1f,
                        cornerRadius = 12.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(4.dp)
                        ) {
                            // Decrease button
                            IconButton(
                                onClick = {
                                    if (!isUpdating) {
                                        isUpdating = true
                                        if (item.quantity > 1) {
                                            onQuantityChange(item.quantity - 1)
                                        } else {
                                            showRemoveDialog = true
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (item.quantity == 1) ErrorColor.copy(alpha = 0.1f)
                                        else MassOrange.copy(alpha = 0.1f)
                                    ),
                                enabled = !isUpdating
                            ) {
                                if (isUpdating) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MassOrange,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (item.quantity == 1) Icons.Default.Delete else Icons.Default.Delete,
                                        contentDescription = if (item.quantity == 1) "Eliminar" else "Disminuir",
                                        tint = if (item.quantity == 1) ErrorColor else MassOrange,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            // Quantity display
                            Text(
                                text = item.quantity.toString(),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MassBlue
                                ),
                                modifier = Modifier.widthIn(min = 32.dp),
                                textAlign = TextAlign.Center
                            )

                            // Increase button
                            IconButton(
                                onClick = {
                                    if (!isUpdating && item.quantity < item.maxStock) {
                                        isUpdating = true
                                        onQuantityChange(item.quantity + 1)
                                    }
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (item.quantity >= item.maxStock) Color.Gray.copy(alpha = 0.1f)
                                        else MassOrange.copy(alpha = 0.1f)
                                    ),
                                enabled = !isUpdating && item.quantity < item.maxStock
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Aumentar",
                                    tint = if (item.quantity >= item.maxStock) Color.Gray else MassOrange,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Stock info
                    if (item.maxStock < 999) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Stock: ${item.maxStock}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }

                // Totals section
                Column(
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "Subtotal",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "S/.${String.format("%.2f", item.subtotal)}",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassBlue
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Calculation breakdown
                    Text(
                        text = "${item.quantity} × S/.${String.format("%.2f", item.unitPrice)}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }

    // Remove confirmation dialog
    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = {
                showRemoveDialog = false
                isUpdating = false
            },
            title = {
                Text(
                    text = "Eliminar producto",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            },
            text = {
                Text(
                    text = "¿Estás seguro de que quieres eliminar '${item.productName}' del carrito?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                MassButton(
                    text = "Eliminar",
                    onClick = {
                        onRemove()
                        showRemoveDialog = false
                        isUpdating = false
                    },
                    variant = MassButtonVariant.Outline
                )
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showRemoveDialog = false
                        isUpdating = false
                    }
                ) {
                    Text(
                        text = "Cancelar",
                        color = Color.Gray
                    )
                }
            }
        )
    }

    // Reset updating state
    LaunchedEffect(item.quantity) {
        if (isUpdating) {
            delay(500)
            isUpdating = false
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun CartSummaryCard(
    subtotal: Double,
    tax: Double,
    shipping: Double,
    total: Double
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        )
    ) {
        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            // Header con icono
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Resumen",
                    tint = MassBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Resumen del pedido",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Subtotal
            SummaryRowImproved(
                label = "Subtotal",
                value = "S/ ${String.format("%.2f", subtotal)}",
                valueColor = MassBlue
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Tax
            SummaryRowImproved(
                label = "IGV (18%)",
                value = "S/ ${String.format("%.2f", tax)}",
                valueColor = MassBlue
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Shipping
            SummaryRowImproved(
                label = "Envío",
                value = if (shipping == 0.0) "GRATIS" else "S/ ${String.format("%.2f", shipping)}",
                valueColor = if (shipping == 0.0) SuccessColor else MassBlue,
                isSpecial = shipping == 0.0
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Divider con gradiente
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                MassOrange.copy(alpha = 0.5f),
                                MassBlue.copy(alpha = 0.5f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Total destacado
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                alpha = 0.1f,
                cornerRadius = 16.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Total a pagar",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Normal,
                                color = Color.Gray
                            )
                        )
                    }

                    Text(
                        text = "S/ ${String.format("%.2f", total)}",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Normal,
                            color = MassOrange
                        )
                    )
                }
            }

            // Información adicional
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Información",
                    tint = Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Los precios incluyen IGV. El envío se calcula según tu ubicación.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )

                    Text(
                        text = "Incluye todos los impuestos",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryRowImproved(
    label: String,
    value: String,
    valueColor: Color = MassBlue,
    isSpecial: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge.copy(
                color = Color.Gray,
                fontWeight = FontWeight.Medium
            )
        )

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSpecial) {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Envío gratis",
                    tint = SuccessColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }

            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = valueColor
                )
            )
        }
    }
}

@Composable
private fun SummaryRow(
    label: String,
    value: String,
    valueColor: Color = MassBlue
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge.copy(
                color = Color.Gray
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontWeight = FontWeight.SemiBold,
                color = valueColor
            )
        )
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun CheckoutFloatingButton(
    total: Double,
    onCheckout: () -> Unit,
    onContinueShopping: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.fillMaxWidth(),
        alpha = 0.2f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MassButton(
                    text = "Seguir",
                    onClick = onContinueShopping,
                    variant = MassButtonVariant.Outline,
                    modifier = Modifier.weight(1f)
                )

                MassButton(
                    text = "Pagar S/ ${String.format("%.2f", total)}",
                    onClick = onCheckout,
                    modifier = Modifier.weight(1.5f)
                )
            }
        }
    }
}
