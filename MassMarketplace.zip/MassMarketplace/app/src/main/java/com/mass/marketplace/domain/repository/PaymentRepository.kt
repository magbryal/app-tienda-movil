package com.mass.marketplace.domain.repository

import java.io.File

interface PaymentRepository {
    suspend fun uploadPaymentProof(imageFile: File): String
}
