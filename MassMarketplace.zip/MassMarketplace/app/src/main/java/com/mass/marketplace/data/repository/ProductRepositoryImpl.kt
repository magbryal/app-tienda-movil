// data/repository/ProductRepositoryImpl.kt
package com.mass.marketplace.data.repository

import com.mass.marketplace.core.network.ApiService
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.data.model.response.toDomain
import com.mass.marketplace.domain.repository.ProductRepository
import com.mass.marketplace.presentation.ui.screens.home.Product
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class ProductRepositoryImpl(
    private val apiService: ApiService,
    private val sessionManager: SessionManager
) : ProductRepository {

    override suspend fun getProducts(): Result<List<Product>> {
        return try {
            // Verificar si hay sesión válida
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            val response = apiService.getProducts()
            val products = response.map { it.toDomain() }

            println("Productos obtenidos: ${products.size}")

            Result.success(products)
        } catch (e: Exception) {
            val errorMessage = when (e) {
                is HttpException -> {
                    when (e.code()) {
                        401 -> {
                            // Token expirado o inválido
                            sessionManager.clearSession()
                            "Sesión expirada. Por favor, inicia sesión nuevamente."
                        }
                        403 -> "No tienes permisos para acceder a los productos."
                        404 -> "No se encontraron productos disponibles."
                        500 -> "Error del servidor. Inténtalo más tarde."
                        else -> "Error HTTP ${e.code()}: ${e.message()}"
                    }
                }
                is UnknownHostException -> "No se pudo conectar al servidor. Verifica tu conexión a internet."
                is ConnectException -> "Error de conexión. Asegúrate de que el servidor esté disponible."
                is SocketTimeoutException -> "Tiempo de espera agotado. Inténtalo de nuevo."
                else -> "Error al cargar productos: ${e.message}"
            }

            println("Error al obtener productos: $errorMessage")

            Result.failure(Exception(errorMessage))
        }
    }
}
