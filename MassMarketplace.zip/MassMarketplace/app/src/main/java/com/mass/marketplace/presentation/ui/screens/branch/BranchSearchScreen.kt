//package com.mass.marketplace.presentation.ui.screens.branch
//
//import androidx.compose.animation.core.*
//import androidx.compose.animation.AnimatedVisibility
//import androidx.compose.animation.fadeIn
//import androidx.compose.animation.fadeOut
//import androidx.compose.animation.slideInVertically
//import androidx.compose.animation.slideOutVertically
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.*
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.foundation.lazy.LazyRow
//import androidx.compose.foundation.lazy.items
//import androidx.compose.foundation.lazy.rememberLazyListState
//import androidx.compose.foundation.shape.CircleShape
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.foundation.text.KeyboardActions
//import androidx.compose.foundation.text.KeyboardOptions
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material3.*
//import androidx.compose.runtime.*
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.scale
//import androidx.compose.ui.focus.FocusRequester
//import androidx.compose.ui.focus.focusRequester
//import androidx.compose.ui.graphics.Brush
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.vector.ImageVector
//import androidx.compose.ui.platform.LocalFocusManager
//import androidx.compose.ui.platform.LocalSoftwareKeyboardController
//import androidx.compose.ui.text.font.FontWeight
//import androidx.compose.ui.text.input.ImeAction
//import androidx.compose.ui.text.style.TextAlign
//import androidx.compose.ui.text.style.TextOverflow
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.unit.sp
//import com.mass.marketplace.core.viewmodel.BranchViewModel
//import com.mass.marketplace.domain.model.Branch
//import com.mass.marketplace.presentation.ui.components.branch.BranchCard
//import com.mass.marketplace.presentation.ui.components.branch.BranchActiveFiltersBar
//import com.mass.marketplace.presentation.ui.components.branch.BranchFilterState
//import com.mass.marketplace.presentation.ui.components.branch.BranchFiltersBottomSheet
//import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
//import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
//import com.mass.marketplace.presentation.ui.theme.*
//import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
//import kotlinx.coroutines.delay
//import kotlinx.coroutines.launch
//import org.koin.androidx.compose.koinViewModel
//import androidx.compose.material.icons.Icons
//import androidx.compose.material.icons.filled.*
//import androidx.compose.material.icons.automirrored.filled.*
//
//// Estados de búsqueda
//enum class SearchState {
//    INITIAL,
//    SEARCHING,
//    RESULTS,
//    NO_RESULTS,
//    ERROR
//}
//
//// Tipos de sugerencias de búsqueda
//enum class SearchSuggestionType(val displayName: String, val icon: ImageVector) {
//    RECENT("Reciente", Icons.Default.History),
//    POPULAR("Popular", Icons.Default.TrendingUp),
//    LOCATION("Ubicación", Icons.Default.LocationOn),
//    SERVICE("Servicio", Icons.Default.RoomService),
//    AUTOCOMPLETE("Autocompletado", Icons.Default.Search)
//}
//
//// Data class para sugerencias
//data class SearchSuggestion(
//    val text: String,
//    val type: SearchSuggestionType,
//    val subtitle: String? = null,
//    val icon: ImageVector? = null,
//    val count: Int? = null
//)
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun BranchSearchScreen(
//    onNavigateBack: () -> Unit,
//    onBranchClick: (Branch) -> Unit,
//    onBranchEdit: (Branch) -> Unit,
//    viewModel: BranchViewModel = koinViewModel()
//) {
//    SetupEdgeToEdge()
//
//    val uiState by viewModel.uiState.collectAsState()
//    var searchQuery by remember { mutableStateOf("") }
//    var searchState by remember { mutableStateOf(SearchState.INITIAL) }
//    var showFilters by remember { mutableStateOf(false) }
//    var filterState by remember { mutableStateOf(BranchFilterState()) }
//    var searchSuggestions by remember { mutableStateOf<List<SearchSuggestion>>(emptyList()) }
//    var recentSearches by remember { mutableStateOf<List<String>>(emptyList()) }
//    var isVoiceSearching by remember { mutableStateOf(false) }
//
//    val focusRequester = remember { FocusRequester() }
//    val keyboardController = LocalSoftwareKeyboardController.current
//    val focusManager = LocalFocusManager.current
//    val scope = rememberCoroutineScope()
//    val listState = rememberLazyListState()
//
//    // Cargar datos iniciales
//    LaunchedEffect(Unit) {
//        viewModel.getBranches()
//        loadRecentSearches() // TODO: Implementar persistencia
//        loadSearchSuggestions() // TODO: Implementar sugerencias inteligentes
//    }
//
//    // Manejar cambios en la búsqueda
//    LaunchedEffect(searchQuery) {
//        if (searchQuery.isNotEmpty()) {
//            searchState = SearchState.SEARCHING
//            delay(300) // Debounce
//            performSearch(searchQuery, viewModel)
//            updateSearchSuggestions(searchQuery)
//        } else {
//            searchState = SearchState.INITIAL
//        }
//    }
//
//    // Manejar resultados de búsqueda
//    LaunchedEffect(uiState.branches, searchQuery) {
//        if (searchQuery.isNotEmpty()) {
//            searchState = if (uiState.branches.isEmpty()) {
//                SearchState.NO_RESULTS
//            } else {
//                SearchState.RESULTS
//            }
//        }
//    }
//
//    // Auto-focus en el campo de búsqueda
//    LaunchedEffect(Unit) {
//        delay(300)
//        focusRequester.requestFocus()
//    }
//
//    LoadingOverlay(
//        isVisible = uiState.isLoading && searchState == SearchState.SEARCHING,
//        message = "Buscando sucursales..."
//    )
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(
//                brush = Brush.verticalGradient(
//                    colors = listOf(
//                        MassBlue.copy(alpha = 0.05f),
//                        Color.White,
//                        MassOrange.copy(alpha = 0.03f)
//                    )
//                )
//            )
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .windowInsetsPadding(WindowInsets.systemBars)
//        ) {
//            // Search Header
//            BranchSearchHeader(
//                searchQuery = searchQuery,
//                onSearchQueryChange = { searchQuery = it },
//                onNavigateBack = onNavigateBack,
//                onVoiceSearch = { isVoiceSearching = true },
//                onClearSearch = { searchQuery = "" },
//                onFiltersClick = { showFilters = true },
//                filterState = filterState,
//                focusRequester = focusRequester,
//                keyboardController = keyboardController
//            )
//
//            // Active Filters Bar
//            AnimatedVisibility(
//                visible = getActiveFiltersCount(filterState) > 0,
//                enter = slideInVertically() + fadeIn(),
//                exit = slideOutVertically() + fadeOut()
//            ) {
//                BranchActiveFiltersBar(
//                    filterState = filterState,
//                    onRemoveFilter = { filterKey ->
//                        filterState = removeFilter(filterState, filterKey)
//                    },
//                    onClearAll = { filterState = BranchFilterState() }
//                )
//            }
//
//            // Search Content
//            when (searchState) {
//                SearchState.INITIAL -> {
//                    BranchSearchInitialContent(
//                        recentSearches = recentSearches,
//                        popularSearches = getPopularSearches(),
//                        quickActions = getQuickActions(),
//                        onSearchClick = { query ->
//                            searchQuery = query
//                            addToRecentSearches(query)
//                        },
//                        onQuickActionClick = { action ->
//                            handleQuickAction(action, filterState) { newFilter ->
//                                filterState = newFilter
//                            }
//                        }
//                    )
//                }
//
//                SearchState.SEARCHING -> {
//                    BranchSearchSuggestionsContent(
//                        searchQuery = searchQuery,
//                        suggestions = searchSuggestions,
//                        onSuggestionClick = { suggestion ->
//                            searchQuery = suggestion.text
//                            addToRecentSearches(suggestion.text)
//                        }
//                    )
//                }
//
//                SearchState.RESULTS -> {
//                    BranchSearchResultsContent(
//                        branches = uiState.branches,
//                        searchQuery = searchQuery,
//                        onBranchClick = onBranchClick,
//                        onBranchEdit = onBranchEdit,
//                        listState = listState
//                    )
//                }
//
//                SearchState.NO_RESULTS -> {
//                    BranchSearchNoResultsContent(
//                        searchQuery = searchQuery,
//                        onTryAgain = { searchQuery = "" },
//                        onAdjustFilters = { showFilters = true }
//                    )
//                }
//
//                SearchState.ERROR -> {
//                    BranchSearchErrorContent(
//                        onRetry = { viewModel.getBranches() }
//                    )
//                }
//            }
//        }
//
//        // Floating Action Button for Quick Add
//        AnimatedVisibility(
//            visible = searchState == SearchState.RESULTS,
//            enter = fadeIn() + slideInVertically { it },
//            exit = fadeOut() + slideOutVertically { it },
//            modifier = Modifier.align(Alignment.BottomEnd)
//        ) {
//            BranchSearchFloatingActions(
//                onAddBranch = { /* TODO: Navigate to create branch */ },
//                onScrollToTop = {
//                    scope.launch {
//                        listState.animateScrollToItem(0)
//                    }
//                },
//                modifier = Modifier.padding(16.dp)
//            )
//        }
//    }
//
//    // Filters Bottom Sheet
//    if (showFilters) {
//        ModalBottomSheet(
//            onDismissRequest = { showFilters = false },
//            containerColor = Color.Transparent,
//            contentColor = Color.Transparent,
//            dragHandle = null
//        ) {
//            BranchFiltersBottomSheet(
//                filterState = filterState,
//                onFilterStateChange = { newFilter ->
//                    filterState = newFilter
//                },
//                onApplyFilters = {
//                    showFilters = false
//                    // Re-apply search with new filters
//                    if (searchQuery.isNotEmpty()) {
//                        performSearch(searchQuery, viewModel)
//                    }
//                },
//                onResetFilters = {
//                    filterState = BranchFilterState()
//                },
//                onDismiss = { showFilters = false },
//                userLocation = getUserLocation(), // TODO: Get actual user location
//                availableRegions = getAvailableRegions(uiState.branches)
//            )
//        }
//    }
//
//    // Voice Search Dialog
//    if (isVoiceSearching) {
//        BranchVoiceSearchDialog(
//            onResult = { result ->
//                searchQuery = result
//                isVoiceSearching = false
//            },
//            onDismiss = { isVoiceSearching = false }
//        )
//    }
//}
//
//@Composable
//private fun BranchSearchHeader(
//    searchQuery: String,
//    onSearchQueryChange: (String) -> Unit,
//    onNavigateBack: () -> Unit,
//    onVoiceSearch: () -> Unit,
//    onClearSearch: () -> Unit,
//    onFiltersClick: () -> Unit,
//    filterState: BranchFilterState,
//    focusRequester: FocusRequester,
//    keyboardController: androidx.compose.ui.platform.SoftwareKeyboardController?
//) {
//    GlassmorphicCard(
//        modifier = Modifier.fillMaxWidth(),
//        alpha = 0.95f,
//        cornerRadius = 0.dp
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.verticalGradient(
//                        colors = listOf(
//                            Color.White.copy(alpha = 0.95f),
//                            Color.White.copy(alpha = 0.9f)
//                        )
//                    )
//                )
//                .padding(16.dp)
//        ) {
//            // Top Row with Back Button and Title
//            Row(
//                modifier = Modifier.fillMaxWidth(),
//                horizontalArrangement = Arrangement.SpaceBetween,
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                Row(
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    GlassmorphicCard(
//                        modifier = Modifier.size(40.dp),
//                        alpha = 0.2f,
//                        cornerRadius = 20.dp,
//                        onClick = onNavigateBack
//                    ) {
//                        Box(
//                            modifier = Modifier.fillMaxSize(),
//                            contentAlignment = Alignment.Center
//                        ) {
//                            Icon(
//                                imageVector = Icons.Default.ArrowBack,
//                                contentDescription = "Volver",
//                                tint = MassBlue,
//                                modifier = Modifier.size(20.dp)
//                            )
//                        }
//                    }
//
//                    Spacer(modifier = Modifier.width(12.dp))
//
//                    Text(
//                        text = "🔍 Buscar Sucursales",
//                        style = MaterialTheme.typography.titleLarge.copy(
//                            fontWeight = FontWeight.Bold,
//                            color = MassBlue
//                        )
//                    )
//                }
//
//                // Filters Button
//                GlassmorphicCard(
//                    modifier = Modifier.size(40.dp),
//                    alpha = if (getActiveFiltersCount(filterState) > 0) 0.3f else 0.2f,
//                    cornerRadius = 20.dp,
//                    onClick = onFiltersClick
//                ) {
//                    Box(
//                        modifier = Modifier
//                            .fillMaxSize()
//                            .background(
//                                brush = if (getActiveFiltersCount(filterState) > 0) {
//                                    Brush.radialGradient(
//                                        colors = listOf(MassOrange, MassOrange.copy(alpha = 0.7f))
//                                    )
//                                } else {
//                                    Brush.radialGradient(
//                                        colors = listOf(Color.Gray, Color.Gray.copy(alpha = 0.7f))
//                                    )
//                                }
//                            ),
//                        contentAlignment = Alignment.Center
//                    ) {
//                        Icon(
//                            imageVector = Icons.Default.FilterList,
//                            contentDescription = "Filtros",
//                            tint = Color.White,
//                            modifier = Modifier.size(20.dp)
//                        )
//
//                        // Badge for active filters
//                        if (getActiveFiltersCount(filterState) > 0) {
//                            Box(
//                                modifier = Modifier
//                                    .size(16.dp)
//                                    .background(ErrorColor, CircleShape)
//                                    .align(Alignment.TopEnd)
//                                    .offset(x = 4.dp, y = (-4).dp),
//                                contentAlignment = Alignment.Center
//                            ) {
//                                Text(
//                                    text = getActiveFiltersCount(filterState).toString(),
//                                    style = MaterialTheme.typography.labelSmall.copy(
//                                        color = Color.White,
//                                        fontSize = 8.sp,
//                                        fontWeight = FontWeight.Bold
//                                    )
//                                )
//                            }
//                        }
//                    }
//                }
//            }
//
//            Spacer(modifier = Modifier.height(16.dp))
//
//            // Search Bar
//            BranchSearchBar(
//                searchQuery = searchQuery,
//                onSearchQueryChange = onSearchQueryChange,
//                onVoiceSearch = onVoiceSearch,
//                onClearSearch = onClearSearch,
//                focusRequester = focusRequester,
//                keyboardController = keyboardController
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchBar(
//    searchQuery: String,
//    onSearchQueryChange: (String) -> Unit,
//    onVoiceSearch: () -> Unit,
//    onClearSearch: () -> Unit,
//    focusRequester: FocusRequester,
//    keyboardController: androidx.compose.ui.platform.SoftwareKeyboardController?
//) {
//    GlassmorphicCard(
//        alpha = 0.1f,
//        cornerRadius = 16.dp
//    ) {
//        OutlinedTextField(
//            value = searchQuery,
//            onValueChange = onSearchQueryChange,
//            modifier = Modifier
//                .fillMaxWidth()
//                .focusRequester(focusRequester),
//            placeholder = {
//                Text(
//                    text = "Buscar por nombre, dirección, servicios...",
//                    style = MaterialTheme.typography.bodyMedium.copy(
//                        color = Color.Gray.copy(alpha = 0.7f)
//                    )
//                )
//            },
//            leadingIcon = {
//                Icon(
//                    imageVector = Icons.Default.Search,
//                    contentDescription = "Buscar",
//                    tint = MassOrange,
//                    modifier = Modifier.size(20.dp)
//                )
//            },
//            trailingIcon = {
//                Row {
//                    // Clear button
//                    if (searchQuery.isNotEmpty()) {
//                        GlassmorphicCard(
//                            modifier = Modifier.size(32.dp),
//                            alpha = 0.2f,
//                            cornerRadius = 16.dp,
//                            onClick = onClearSearch
//                        ) {
//                            Box(
//                                modifier = Modifier.fillMaxSize(),
//                                contentAlignment = Alignment.Center
//                            ) {
//                                Icon(
//                                    imageVector = Icons.Default.Clear,
//                                    contentDescription = "Limpiar",
//                                    tint = Color.Gray,
//                                    modifier = Modifier.size(16.dp)
//                                )
//                            }
//                        }
//
//                        Spacer(modifier = Modifier.width(4.dp))
//                    }
//
//                    // Voice search button
//                    GlassmorphicCard(
//                        modifier = Modifier.size(32.dp),
//                        alpha = 0.2f,
//                        cornerRadius = 16.dp,
//                        onClick = onVoiceSearch
//                    ) {
//                        Box(
//                            modifier = Modifier
//                                .fillMaxSize()
//                                .background(
//                                    brush = Brush.radialGradient(
//                                        colors = listOf(MassBlue, MassBlue.copy(alpha = 0.7f))
//                                    )
//                                ),
//                            contentAlignment = Alignment.Center
//                        ) {
//                            Icon(
//                                imageVector = Icons.Default.Mic,
//                                contentDescription = "Búsqueda por voz",
//                                tint = Color.White,
//                                modifier = Modifier.size(16.dp)
//                            )
//                        }
//                    }
//                }
//            },
//            colors = OutlinedTextFieldDefaults.colors(
//                focusedBorderColor = MassOrange,
//                unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
//                focusedTextColor = MassBlue,
//                unfocusedTextColor = MassBlue,
//                cursorColor = MassOrange
//            ),
//            shape = RoundedCornerShape(16.dp),
//            keyboardOptions = KeyboardOptions(
//                imeAction = ImeAction.Search
//            ),
//            keyboardActions = KeyboardActions(
//                onSearch = {
//                    keyboardController?.hide()
//                }
//            ),
//            singleLine = true
//        )
//    }
//}
//
//@Composable
//private fun BranchSearchInitialContent(
//    recentSearches: List<String>,
//    popularSearches: List<SearchSuggestion>,
//    quickActions: List<QuickAction>,
//    onSearchClick: (String) -> Unit,
//    onQuickActionClick: (QuickAction) -> Unit
//) {
//    LazyColumn(
//        modifier = Modifier.fillMaxSize(),
//        contentPadding = PaddingValues(16.dp),
//        verticalArrangement = Arrangement.spacedBy(24.dp)
//    ) {
//        // Quick Actions
//        if (quickActions.isNotEmpty()) {
//            item {
//                BranchSearchSection(
//                    title = "⚡ Acciones Rápidas",
//                    subtitle = "Filtros y búsquedas populares"
//                ) {
//                    LazyRow(
//                        horizontalArrangement = Arrangement.spacedBy(12.dp),
//                        contentPadding = PaddingValues(horizontal = 4.dp)
//                    ) {
//                        items(quickActions) { action ->
//                            BranchQuickActionCard(
//                                action = action,
//                                onClick = { onQuickActionClick(action) }
//                            )
//                        }
//                    }
//                }
//            }
//        }
//
//        // Recent Searches
//        if (recentSearches.isNotEmpty()) {
//            item {
//                BranchSearchSection(
//                    title = "🕒 Búsquedas Recientes",
//                    subtitle = "Tus últimas búsquedas"
//                ) {
//                    Column(
//                        verticalArrangement = Arrangement.spacedBy(8.dp)
//                    ) {
//                        recentSearches.take(5).forEach { search ->
//                            BranchSearchHistoryItem(
//                                text = search,
//                                onClick = { onSearchClick(search) }
//                            )
//                        }
//                    }
//                }
//            }
//        }
//
//        // Popular Searches
//        if (popularSearches.isNotEmpty()) {
//            item {
//                BranchSearchSection(
//                    title = "🔥 Búsquedas Populares",
//                    subtitle = "Lo que otros están buscando"
//                ) {
//                    Column(
//                        verticalArrangement = Arrangement.spacedBy(8.dp)
//                    ) {
//                        popularSearches.forEach { suggestion ->
//                            BranchSearchSuggestionItem(
//                                suggestion = suggestion,
//                                onClick = { onSearchClick(suggestion.text) }
//                            )
//                        }
//                    }
//                }
//            }
//        }
//
//        // Search Tips
//        item {
//            BranchSearchTipsCard()
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchSuggestionsContent(
//    searchQuery: String,
//    suggestions: List<SearchSuggestion>,
//    onSuggestionClick: (SearchSuggestion) -> Unit
//) {
//    LazyColumn(
//        modifier = Modifier.fillMaxSize(),
//        contentPadding = PaddingValues(16.dp)
//    ) {
//        if (suggestions.isNotEmpty()) {
//            item {
//                Text(
//                    text = "💡 Sugerencias para \"$searchQuery\"",
//                    style = MaterialTheme.typography.titleMedium.copy(
//                        fontWeight = FontWeight.Bold,
//                        color = MassBlue
//                    ),
//                    modifier = Modifier.padding(bottom = 16.dp)
//                )
//            }
//
//            items(suggestions) { suggestion ->
//                BranchSearchSuggestionItem(
//                    suggestion = suggestion,
//                    onClick = { onSuggestionClick(suggestion) },
//                    modifier = Modifier.padding(bottom = 8.dp)
//                )
//            }
//        } else {
//            item {
//                BranchSearchLoadingSuggestions()
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchResultsContent(
//    branches: List<Branch>,
//    searchQuery: String,
//    onBranchClick: (Branch) -> Unit,
//    onBranchEdit: (Branch) -> Unit,
//    listState: LazyListState
//) {
//    LazyColumn(
//        state = listState,
//        modifier = Modifier.fillMaxSize(),
//        contentPadding = PaddingValues(16.dp),
//        verticalArrangement = Arrangement.spacedBy(12.dp)
//    ) {
//        // Results Header
//        item {
//            BranchSearchResultsHeader(
//                resultsCount = branches.size,
//                searchQuery = searchQuery
//            )
//        }
//
//        // Branch Results
//        items(
//            items = branches,
//            key = { it.id }
//        ) { branch ->
//            BranchCard(
//                branch = branch,
//                onClick = { onBranchClick(branch) },
//                onEdit = { onBranchEdit(branch) },
//                modifier = Modifier.animateItemPlacement(),
//                highlightQuery = searchQuery
//            )
//        }
//
//        // Load More Button (if needed)
//        if (branches.size >= 20) {
//            item {
//                BranchSearchLoadMoreButton(
//                    onLoadMore = { /* TODO: Implement pagination */ }
//                )
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchNoResultsContent(
//    searchQuery: String,
//    onTryAgain: () -> Unit,
//    onAdjustFilters: () -> Unit
//) {
//    EmptyState(
//        icon = Icons.Default.SearchOff,
//        title = "Sin resultados",
//        description = "No encontramos sucursales que coincidan con \"$searchQuery\"",
//        primaryAction = {
//            Button(
//                onClick = onTryAgain,
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = MassOrange
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Refresh,
//                    contentDescription = "Intentar de nuevo",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text("Nueva búsqueda")
//            }
//        },
//        secondaryAction = {
//            OutlinedButton(
//                onClick = onAdjustFilters,
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = MassBlue
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Tune,
//                    contentDescription = "Ajustar filtros",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text("Ajustar filtros")
//            }
//        }
//    )
//}
//
//@Composable
//private fun BranchSearchErrorContent(
//    onRetry: () -> Unit
//) {
//    EmptyState(
//        icon = Icons.Default.Error,
//        title = "Error en la búsqueda",
//        description = "Ocurrió un problema al buscar las sucursales. Por favor, inténtalo de nuevo.",
//        primaryAction = {
//            Button(
//                onClick = onRetry,
//                colors = ButtonDefaults.buttonColors(
//                    containerColor = ErrorColor
//                )
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Refresh,
//                    contentDescription = "Reintentar",
//                    modifier = Modifier.size(16.dp)
//                )
//                Spacer(modifier = Modifier.width(6.dp))
//                Text("Reintentar")
//            }
//        }
//    )
//}
//
//@Composable
//private fun BranchSearchSection(
//    title: String,
//    subtitle: String,
//    content: @Composable () -> Unit
//) {
//    Column {
//        Column(
//            modifier = Modifier.padding(bottom = 12.dp)
//        ) {
//            Text(
//                text = title,
//                style = MaterialTheme.typography.titleMedium.copy(
//                    fontWeight = FontWeight.Bold,
//                    color = MassBlue
//                )
//            )
//            Text(
//                text = subtitle,
//                style = MaterialTheme.typography.bodySmall.copy(
//                    color = Color.Gray
//                )
//            )
//        }
//
//        content()
//    }
//}
//
//@Composable
//private fun BranchQuickActionCard(
//    action: QuickAction,
//    onClick: () -> Unit
//) {
//    GlassmorphicCard(
//        alpha = 0.1f,
//        cornerRadius = 16.dp,
//        onClick = onClick
//    ) {
//        Column(
//            modifier = Modifier
//                .background(
//                    brush = Brush.verticalGradient(
//                        colors = listOf(
//                            action.color.copy(alpha = 0.1f),
//                            Color.Transparent
//                        )
//                    )
//                )
//                .padding(16.dp)
//                .width(120.dp),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//            GlassmorphicCard(
//                modifier = Modifier.size(48.dp),
//                alpha = 0.3f,
//                cornerRadius = 24.dp
//            ) {
//                Box(
//                    modifier = Modifier
//                        .fillMaxSize()
//                        .background(
//                            brush = Brush.radialGradient(
//                                colors = listOf(action.color, action.color.copy(alpha = 0.7f))
//                            )
//                        ),
//                    contentAlignment = Alignment.Center
//                ) {
//                    Icon(
//                        imageVector = action.icon,
//                        contentDescription = action.title,
//                        tint = Color.White,
//                        modifier = Modifier.size(24.dp)
//                    )
//                }
//            }
//
//            Spacer(modifier = Modifier.height(8.dp))
//
//            Text(
//                text = action.title,
//                style = MaterialTheme.typography.labelMedium.copy(
//                    fontWeight = FontWeight.Bold,
//                    color = MassBlue,
//                    textAlign = TextAlign.Center
//                ),
//                maxLines = 2,
//                overflow = TextOverflow.Ellipsis
//            )
//
//            if (action.subtitle != null) {
//                Text(
//                    text = action.subtitle,
//                    style = MaterialTheme.typography.labelSmall.copy(
//                        color = Color.Gray,
//                        textAlign = TextAlign.Center
//                    ),
//                    maxLines = 1,
//                    overflow = TextOverflow.Ellipsis
//                )
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchHistoryItem(
//    text: String,
//    onClick: () -> Unit
//) {
//    GlassmorphicCard(
//        alpha = 0.1f,
//        cornerRadius = 12.dp,
//        onClick = onClick
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(12.dp),
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            Icon(
//                imageVector = Icons.Default.History,
//                contentDescription = "Búsqueda reciente",
//                tint = Color.Gray,
//                modifier = Modifier.size(20.dp)
//            )
//
//            Spacer(modifier = Modifier.width(12.dp))
//
//            Text(
//                text = text,
//                style = MaterialTheme.typography.bodyMedium.copy(
//                    color = MassBlue
//                ),
//                modifier = Modifier.weight(1f)
//            )
//
//            Icon(
//                imageVector = Icons.Default.NorthWest,
//                contentDescription = "Usar búsqueda",
//                tint = Color.Gray,
//                modifier = Modifier.size(16.dp)
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchSuggestionItem(
//    suggestion: SearchSuggestion,
//    onClick: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    GlassmorphicCard(
//        modifier = modifier,
//        alpha = 0.1f,
//        cornerRadius = 12.dp,
//        onClick = onClick
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.horizontalGradient(
//                        colors = listOf(
//                            suggestion.type.color.copy(alpha = 0.05f),
//                            Color.Transparent
//                        )
//                    )
//                )
//                .padding(12.dp),
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            GlassmorphicCard(
//                modifier = Modifier.size(32.dp),
//                alpha = 0.2f,
//                cornerRadius = 16.dp
//            ) {
//                Box(
//                    modifier = Modifier
//                        .fillMaxSize()
//                        .background(
//                            brush = Brush.radialGradient(
//                                colors = listOf(
//                                    suggestion.type.color,
//                                    suggestion.type.color.copy(alpha = 0.7f)
//                                )
//                            )
//                        ),
//                    contentAlignment = Alignment.Center
//                ) {
//                    Icon(
//                        imageVector = suggestion.icon ?: suggestion.type.icon,
//                        contentDescription = suggestion.type.displayName,
//                        tint = Color.White,
//                        modifier = Modifier.size(16.dp)
//                    )
//                }
//            }
//
//            Spacer(modifier = Modifier.width(12.dp))
//
//            Column(
//                modifier = Modifier.weight(1f)
//            ) {
//                Text(
//                    text = suggestion.text,
//                    style = MaterialTheme.typography.bodyMedium.copy(
//                        fontWeight = FontWeight.Medium,
//                        color = MassBlue
//                    )
//                )
//
//                if (suggestion.subtitle != null) {
//                    Text(
//                        text = suggestion.subtitle,
//                        style = MaterialTheme.typography.bodySmall.copy(
//                            color = Color.Gray
//                        )
//                    )
//                }
//            }
//
//            if (suggestion.count != null) {
//                GlassmorphicCard(
//                    alpha = 0.2f,
//                    cornerRadius = 12.dp
//                ) {
//                    Text(
//                        text = "${suggestion.count}",
//                        style = MaterialTheme.typography.labelSmall.copy(
//                            color = suggestion.type.color,
//                            fontWeight = FontWeight.Bold
//                        ),
//                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
//                    )
//                }
//            }
//
//            Spacer(modifier = Modifier.width(8.dp))
//
//            Icon(
//                imageVector = Icons.Default.NorthWest,
//                contentDescription = "Usar sugerencia",
//                tint = Color.Gray,
//                modifier = Modifier.size(16.dp)
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchTipsCard() {
//    GlassmorphicCard(
//        alpha = 0.1f,
//        cornerRadius = 16.dp
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.verticalGradient(
//                        colors = listOf(
//                            MassBlue.copy(alpha = 0.05f),
//                            Color.Transparent
//                        )
//                    )
//                )
//                .padding(16.dp)
//        ) {
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Lightbulb,
//                    contentDescription = "Consejos",
//                    tint = MassOrange,
//                    modifier = Modifier.size(24.dp)
//                )
//
//                Spacer(modifier = Modifier.width(8.dp))
//
//                Text(
//                    text = "💡 Consejos de Búsqueda",
//                    style = MaterialTheme.typography.titleSmall.copy(
//                        fontWeight = FontWeight.Bold,
//                        color = MassBlue
//                    )
//                )
//            }
//
//            Spacer(modifier = Modifier.height(12.dp))
//
//            val tips = listOf(
//                "Usa palabras clave como 'parking', 'wifi', '24 horas'",
//                "Busca por dirección o nombre de la zona",
//                "Combina filtros para resultados más precisos",
//                "Usa búsqueda por voz para mayor comodidad"
//            )
//
//            tips.forEach { tip ->
//                Row(
//                    modifier = Modifier.padding(vertical = 2.dp),
//                    verticalAlignment = Alignment.Top
//                ) {
//                    Text(
//                        text = "•",
//                        style = MaterialTheme.typography.bodySmall.copy(
//                            color = MassOrange,
//                            fontWeight = FontWeight.Bold
//                        )
//                    )
//
//                    Spacer(modifier = Modifier.width(8.dp))
//
//                    Text(
//                        text = tip,
//                        style = MaterialTheme.typography.bodySmall.copy(
//                            color = Color.Gray
//                        )
//                    )
//                }
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchLoadingSuggestions() {
//    Column(
//        modifier = Modifier.fillMaxWidth(),
//        verticalArrangement = Arrangement.spacedBy(8.dp)
//    ) {
//        repeat(3) {
//            GlassmorphicCard(
//                alpha = 0.1f,
//                cornerRadius = 12.dp
//            ) {
//                Row(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(12.dp),
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Box(
//                        modifier = Modifier
//                            .size(32.dp)
//                            .background(Color.Gray.copy(alpha = 0.3f), CircleShape)
//                    )
//
//                    Spacer(modifier = Modifier.width(12.dp))
//
//                    Column(
//                        modifier = Modifier.weight(1f)
//                    ) {
//                        Box(
//                            modifier = Modifier
//                                .fillMaxWidth(0.7f)
//                                .height(16.dp)
//                                .background(Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
//                        )
//
//                        Spacer(modifier = Modifier.height(4.dp))
//
//                        Box(
//                            modifier = Modifier
//                                .fillMaxWidth(0.5f)
//                                .height(12.dp)
//                                .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
//                        )
//                    }
//                }
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchResultsHeader(
//    resultsCount: Int,
//    searchQuery: String
//) {
//    GlassmorphicCard(
//        alpha = 0.1f,
//        cornerRadius = 12.dp
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.horizontalGradient(
//                        colors = listOf(
//                            SuccessColor.copy(alpha = 0.1f),
//                            Color.Transparent
//                        )
//                    )
//                )
//                .padding(16.dp),
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            Icon(
//                imageVector = Icons.Default.CheckCircle,
//                contentDescription = "Resultados encontrados",
//                tint = SuccessColor,
//                modifier = Modifier.size(24.dp)
//            )
//
//            Spacer(modifier = Modifier.width(12.dp))
//
//            Column {
//                Text(
//                    text = "✅ $resultsCount resultados encontrados",
//                    style = MaterialTheme.typography.titleSmall.copy(
//                        fontWeight = FontWeight.Bold,
//                        color = MassBlue
//                    )
//                )
//                Text(
//                    text = "Para la búsqueda: \"$searchQuery\"",
//                    style = MaterialTheme.typography.bodySmall.copy(
//                        color = Color.Gray
//                    )
//                )
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchLoadMoreButton(
//    onLoadMore: () -> Unit
//) {
//    GlassmorphicCard(
//        alpha = 0.1f,
//        cornerRadius = 16.dp,
//        onClick = onLoadMore
//    ) {
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .background(
//                    brush = Brush.horizontalGradient(
//                        colors = listOf(
//                            MassOrange.copy(alpha = 0.1f),
//                            Color.Transparent
//                        )
//                    )
//                )
//                .padding(16.dp),
//            horizontalArrangement = Arrangement.Center,
//            verticalAlignment = Alignment.CenterVertically
//        ) {
//            Icon(
//                imageVector = Icons.Default.ExpandMore,
//                contentDescription = "Cargar más",
//                tint = MassOrange,
//                modifier = Modifier.size(20.dp)
//            )
//
//            Spacer(modifier = Modifier.width(8.dp))
//
//            Text(
//                text = "Cargar más resultados",
//                style = MaterialTheme.typography.bodyMedium.copy(
//                    fontWeight = FontWeight.Medium,
//                    color = MassOrange
//                )
//            )
//        }
//    }
//}
//
//@Composable
//private fun BranchSearchFloatingActions(
//    onAddBranch: () -> Unit,
//    onScrollToTop: () -> Unit,
//    modifier: Modifier = Modifier
//) {
//    Column(
//        modifier = modifier,
//        verticalArrangement = Arrangement.spacedBy(12.dp)
//    ) {
//        // Scroll to top button
//        GlassmorphicCard(
//            modifier = Modifier.size(56.dp),
//            alpha = 0.3f,
//            cornerRadius = 28.dp,
//            onClick = onScrollToTop
//        ) {
//            Box(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .background(
//                        brush = Brush.radialGradient(
//                            colors = listOf(MassBlue, MassBlue.copy(alpha = 0.8f))
//                        )
//                    ),
//                contentAlignment = Alignment.Center
//            ) {
//                Icon(
//                    imageVector = Icons.Default.KeyboardArrowUp,
//                    contentDescription = "Ir arriba",
//                    tint = Color.White,
//                    modifier = Modifier.size(24.dp)
//                )
//            }
//        }
//
//        // Add branch button
//        GlassmorphicCard(
//            modifier = Modifier.size(56.dp),
//            alpha = 0.3f,
//            cornerRadius = 28.dp,
//            onClick = onAddBranch
//        ) {
//            Box(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .background(
//                        brush = Brush.radialGradient(
//                            colors = listOf(MassOrange, MassOrange.copy(alpha = 0.8f))
//                        )
//                    ),
//                contentAlignment = Alignment.Center
//            ) {
//                Icon(
//                    imageVector = Icons.Default.Add,
//                    contentDescription = "Agregar sucursal",
//                    tint = Color.White,
//                    modifier = Modifier.size(24.dp)
//                )
//            }
//        }
//    }
//}
//
//@Composable
//private fun BranchVoiceSearchDialog(
//    onResult: (String) -> Unit,
//    onDismiss: () -> Unit
//) {
//    var isListening by remember { mutableStateOf(true) }
//    var amplitude by remember { mutableStateOf(0f) }
//
//    // Simular animación de micrófono
//    val infiniteTransition = rememberInfiniteTransition(label = "voice_animation")
//    val animatedAmplitude by infiniteTransition.animateFloat(
//        initialValue = 0.8f,
//        targetValue = 1.2f,
//        animationSpec = infiniteRepeatable(
//            animation = tween(800, easing = EaseInOut),
//            repeatMode = RepeatMode.Reverse
//        ),
//        label = "amplitude_animation"
//    )
//
//    LaunchedEffect(Unit) {
//        // Simular reconocimiento de voz
//        delay(3000)
//        onResult("Sucursales con estacionamiento cerca de mí")
//    }
//
//    AlertDialog(
//        onDismissRequest = onDismiss,
//        title = {
//            Text(
//                text = "🎤 Búsqueda por Voz",
//                style = MaterialTheme.typography.titleLarge.copy(
//                    fontWeight = FontWeight.Bold,
//                    color = MassBlue
//                )
//            )
//        },
//        text = {
//            Column(
//                horizontalAlignment = Alignment.CenterHorizontally
//            ) {
//                // Animated microphone
//                GlassmorphicCard(
//                    modifier = Modifier
//                        .size(120.dp)
//                        .scale(if (isListening) animatedAmplitude else 1f),
//                    alpha = 0.3f,
//                    cornerRadius = 60.dp
//                ) {
//                    Box(
//                        modifier = Modifier
//                            .fillMaxSize()
//                            .background(
//                                brush = Brush.radialGradient(
//                                    colors = listOf(
//                                        MassOrange,
//                                        MassOrange.copy(alpha = 0.7f)
//                                    )
//                                )
//                            ),
//                        contentAlignment = Alignment.Center
//                    ) {
//                        Icon(
//                            imageVector = Icons.Default.Mic,
//                            contentDescription = "Micrófono",
//                            tint = Color.White,
//                            modifier = Modifier.size(48.dp)
//                        )
//                    }
//                }
//
//                Spacer(modifier = Modifier.height(24.dp))
//
//                Text(
//                    text = if (isListening) "Escuchando..." else "Procesando...",
//                    style = MaterialTheme.typography.bodyLarge.copy(
//                        fontWeight = FontWeight.Medium,
//                        color = MassBlue
//                    )
//                )
//
//                Spacer(modifier = Modifier.height(8.dp))
//
//                Text(
//                    text = "Di algo como: \"Sucursales con WiFi\" o \"Cerca de mí\"",
//                    style = MaterialTheme.typography.bodySmall.copy(
//                        color = Color.Gray,
//                        textAlign = TextAlign.Center
//                    )
//                )
//
//                Spacer(modifier = Modifier.height(16.dp))
//
//                // Voice level indicator
//                Row(
//                    horizontalArrangement = Arrangement.spacedBy(4.dp)
//                ) {
//                    repeat(5) { index ->
//                        val height = if (isListening) {
//                            (20 + (kotlin.math.sin((System.currentTimeMillis() + index * 200) / 200.0) * 10)).dp
//                        } else {
//                            20.dp
//                        }
//
//                        Box(
//                            modifier = Modifier
//                                .width(4.dp)
//                                .height(height)
//                                .background(
//                                    color = MassOrange.copy(alpha = 0.7f),
//                                    shape = RoundedCornerShape(2.dp)
//                                )
//                        )
//                    }
//                }
//            }
//        },
//        confirmButton = {
//            OutlinedButton(
//                onClick = onDismiss,
//                colors = ButtonDefaults.outlinedButtonColors(
//                    contentColor = Color.Gray
//                )
//            ) {
//                Text("Cancelar")
//            }
//        },
//        containerColor = Color.White,
//        shape = RoundedCornerShape(20.dp)
//    )
//}
//
//// Data classes y funciones auxiliares
//data class QuickAction(
//    val title: String,
//    val subtitle: String?,
//    val icon: ImageVector,
//    val color: Color,
//    val action: () -> Unit
//)
//
//// Extension para SearchSuggestionType
//val SearchSuggestionType.color: Color
//    get() = when (this) {
//        SearchSuggestionType.RECENT -> Color.Gray
//        SearchSuggestionType.POPULAR -> MassOrange
//        SearchSuggestionType.LOCATION -> MassBlue
//        SearchSuggestionType.SERVICE -> SuccessColor
//        SearchSuggestionType.AUTOCOMPLETE -> MassBlue
//    }
//
//val SearchSuggestionType.displayName: String
//    get() = when (this) {
//        SearchSuggestionType.RECENT -> "Reciente"
//        SearchSuggestionType.POPULAR -> "Popular"
//        SearchSuggestionType.LOCATION -> "Ubicación"
//        SearchSuggestionType.SERVICE -> "Servicio"
//        SearchSuggestionType.AUTOCOMPLETE -> "Autocompletado"
//    }
//
//// Funciones auxiliares
//private fun performSearch(query: String, viewModel: BranchViewModel) {
//    // TODO: Implementar búsqueda real
//    viewModel.searchBranches(query)
//}
//
//private fun updateSearchSuggestions(query: String): List<SearchSuggestion> {
//    // TODO: Implementar sugerencias inteligentes
//    return emptyList()
//}
//
//private fun loadRecentSearches(): List<String> {
//    // TODO: Cargar desde persistencia local
//    return listOf(
//        "Sucursales con estacionamiento",
//        "Lima Centro",
//        "24 horas",
//        "WiFi gratis",
//        "Miraflores"
//    )
//}
//
//private fun loadSearchSuggestions(): List<SearchSuggestion> {
//    // TODO: Cargar sugerencias desde API
//    return emptyList()
//}
//
//private fun addToRecentSearches(query: String) {
//    // TODO: Guardar en persistencia local
//}
//
//private fun getPopularSearches(): List<SearchSuggestion> {
//    return listOf(
//        SearchSuggestion(
//            text = "Sucursales con estacionamiento",
//            type = SearchSuggestionType.POPULAR,
//            subtitle = "Servicio popular",
//            count = 25
//        ),
//        SearchSuggestion(
//            text = "Lima Centro",
//            type = SearchSuggestionType.LOCATION,
//            subtitle = "Zona comercial",
//            count = 12
//        ),
//        SearchSuggestion(
//            text = "Abiertas 24 horas",
//            type = SearchSuggestionType.SERVICE,
//            subtitle = "Horario extendido",
//            count = 8
//        )
//    )
//}
//
//private fun getQuickActions(): List<QuickAction> {
//    return listOf(
//        QuickAction(
//            title = "Cerca de mí",
//            subtitle = "5 km",
//            icon = Icons.Default.NearMe,
//            color = MassBlue,
//            action = { }
//        ),
//        QuickAction(
//            title = "Con parking",
//            subtitle = "Disponible",
//            icon = Icons.Default.LocalParking,
//            color = SuccessColor,
//            action = { }
//        ),
//        QuickAction(
//            title = "WiFi gratis",
//            subtitle = "Conectividad",
//            icon = Icons.Default.Wifi,
//            color = MassOrange,
//            action = { }
//        ),
//        QuickAction(
//            title = "24 horas",
//            subtitle = "Siempre abierto",
//            icon = Icons.Default.AccessTime,
//            color = Color(0xFF9C27B0),
//            action = { }
//        )
//    )
//}
//
//private fun handleQuickAction(
//    action: QuickAction,
//    currentFilter: BranchFilterState,
//    onFilterChange: (BranchFilterState) -> Unit
//) {
//    // TODO: Implementar manejo de acciones rápidas
//    action.action()
//}
//
//private fun getUserLocation(): Pair<Double, Double>? {
//    // TODO: Obtener ubicación real del usuario
//    return null
//}
//
//private fun getAvailableRegions(branches: List<Branch>): List<String> {
//    // Extraer regiones únicas de las direcciones
//    return branches.map { branch ->
//        // Simplificado: tomar la última parte de la dirección
//        branch.address.split(",").lastOrNull()?.trim() ?: ""
//    }.filter { it.isNotEmpty() }.distinct().sorted()
//}
//
//private fun getActiveFiltersCount(filterState: BranchFilterState): Int {
//    // TODO: Implementar conteo real de filtros activos
//    return 0
//}
//
//private fun removeFilter(filterState: BranchFilterState, filterKey: String): BranchFilterState {
//    // TODO: Implementar remoción de filtros específicos
//    return filterState
//}