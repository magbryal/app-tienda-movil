package com.mass.marketplace.presentation.ui.screens.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.core.viewmodel.BranchViewModel
import com.mass.marketplace.core.viewmodel.CartViewModel
import com.mass.marketplace.core.viewmodel.HomeViewModel
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.presentation.ui.components.cards.BentoCard
import com.mass.marketplace.presentation.ui.components.cards.CategoryCard
import com.mass.marketplace.presentation.ui.components.cards.ProductCard
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
import com.mass.marketplace.presentation.section.VideoSection
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import org.koin.androidx.compose.koinViewModel

data class Category(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val color: List<Color>,
    val productCount: Int,
    val description: String = "",
    val imageUrl: String = "",
    val isActive: Boolean = true
)

data class Product(
    val id: Int,
    val name: String,
    val price: Double,
    val originalPrice: Double? = null,
    val imageUrl: String,
    val store: String,
    val rating: Float,
    val distance: String,
    val description: String = "",
    val stock: Int = 0,
    val barcode: String = "",
    val categoryId: Int = 0
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToProducts: (String) -> Unit,
    onNavigateToAllProducts: () -> Unit,
    onNavigateToProductsCompose: (String) -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToCart: () -> Unit,
    onNavigateToBranch: () -> Unit,
    viewModel: HomeViewModel = koinViewModel(),
    cartViewModel: CartViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    var isVisible by remember { mutableStateOf(false) }
    val uiState by viewModel.uiState.collectAsState()
    val cartUiState by cartViewModel.uiState.collectAsState()

    LaunchedEffect(key1 = true) {
        isVisible = true
    }

    LoadingOverlay(
        isVisible = uiState.isLoading && uiState.products.isEmpty() && uiState.categories.isEmpty(),
        message = "Cargando contenido..."
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.1f),
                        Color.White,
                        MassBlue.copy(alpha = 0.05f)
                    )
                )
            )
    ) {
        PullToRefreshBox(
            isRefreshing = uiState.isRefreshing,
            onRefresh = { viewModel.refreshProducts() },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Header
                item {
                    HomeHeader(
                        onSearchClick = onNavigateToSearch,
                        onProfileClick = onNavigateToProfile,
                        onCartClick = onNavigateToCart,
                        cartItemCount = cartUiState.items.sumOf { it.quantity },
                        isVisible = isVisible
                    )
                }

                // Welcome Bento
                item {
                    WelcomeBento(isVisible = isVisible)
                }

                item {
                    BranchSection(
                        onNavigateToBranch = onNavigateToBranch,
                        isVisible = isVisible
                    )
                }

                // Categories
                item {
                    CategoriesSection(
                        categories = uiState.categories,
                        onCategoryClick = onNavigateToProducts,
                        isVisible = isVisible,
                        isLoading = uiState.isLoading && uiState.categories.isEmpty(),
                        onRetryClick = { viewModel.loadCategories() }
                    )
                }

                item {
                    VideoSection(
                        videoUrl = "https://youtu.be/twfivvPo4D4",
                        isVisible = isVisible
                    )
                }

                // Featured Products
                item {
                    FeaturedProductsSection(
                        products = uiState.featuredProducts,
                        isVisible = isVisible,
                        isLoading = uiState.isLoading && uiState.products.isEmpty(),
                        onNavigateToProducts = {
                            println("Ejecutando onNavigateToAllProducts")
                            onNavigateToAllProducts()
                        },
                        onAddToCart = { cartItem ->
                            cartViewModel.addToCart(cartItem)
                        }
                    )
                }

                // Quick Actions
                item {
                    QuickActionsSection(isVisible = isVisible)
                }
            }
        }

        // Error Message
        if (uiState.errorMessage != null) {
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .windowInsetsPadding(WindowInsets.navigationBars),
                colors = CardDefaults.cardColors(
                    containerColor = ErrorColor.copy(alpha = 0.9f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Error",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = uiState.errorMessage!!,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = {
                            viewModel.clearError()
                            viewModel.loadProducts()
                        }
                    ) {
                        Text(
                            text = "Reintentar",
                            color = Color.White
                        )
                    }
                }
            }
        }

        if (cartUiState.items.isNotEmpty()) {
            LaunchedEffect(cartUiState.items.size) {
                // Mostrar feedback cuando se agrega un producto
            }
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        if (uiState.errorMessage != null) {
            kotlinx.coroutines.delay(5000)
            viewModel.clearError()
        }
    }
}

@Composable
fun BranchSection(
    onNavigateToBranch: () -> Unit,
    isVisible: Boolean,
    viewModel: BranchViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    // Cargar datos cuando se monta el componente
    LaunchedEffect(Unit) {
        if (uiState.branches.isEmpty()) {
            viewModel.loadBranches()
        }
    }

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 400),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        // Header con título y botón "Ver todas"
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionTitle(
                title = "Sucursales",
                subtitle = "Encuentra la más cercana a ti",
                isVisible = isVisible
            )

            TextButton(
                onClick = onNavigateToBranch
            ) {
                Text(
                    text = "Ver todas",
                    color = MassOrange,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.SemiBold
                    )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Ver todas",
                    tint = MassOrange,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Contenido de sucursales
        when {
            uiState.isLoading && uiState.branches.isEmpty() -> {
                // Loading skeleton
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(3) {
                        BranchCardSkeleton()
                    }
                }
            }

            uiState.branches.isNotEmpty() -> {
                // Mostrar sucursales
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(uiState.branches.take(5)) { branch ->
                        BranchHomeCard(
                            branch = branch,
                            onClick = { /* Navegar a detalle de sucursal */ }
                        )
                    }

                    // Botón "Ver más" al final
                    item {
                        SeeMoreBranchesCard(
                            onClick = onNavigateToBranch
                        )
                    }
                }
            }

            else -> {
                // Estado vacío
                EmptyBranchesState(
                    onRetry = { viewModel.loadBranches() },
                    onViewAll = onNavigateToBranch
                )
            }
        }
    }
}

@Composable
private fun BranchHomeCard(
    branch: Branch,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .width(200.dp)
            .height(140.dp),
        alpha = 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header con icono y estado
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Sucursal",
                    tint = MassOrange,
                    modifier = Modifier.size(24.dp)
                )

                // Estado activo/inactivo
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            color = if (branch.isActive) SuccessColor else ErrorColor,
                            shape = CircleShape
                        )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Nombre de la sucursal
            Text(
                text = branch.name,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Dirección
            Text(
                text = branch.address,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.weight(1f))

            // Footer con teléfono
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = "Teléfono",
                    tint = MassBlue,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = branch.phone,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MassBlue
                    )
                )
            }
        }
    }
}

@Composable
private fun BranchCardSkeleton() {
    Card(
        modifier = Modifier
            .width(200.dp)
            .height(140.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Gray.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header skeleton
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(
                            Color.Gray.copy(alpha = 0.3f),
                            RoundedCornerShape(4.dp)
                        )
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            Color.Gray.copy(alpha = 0.3f),
                            CircleShape
                        )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Título skeleton
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(16.dp)
                    .background(
                        Color.Gray.copy(alpha = 0.3f),
                        RoundedCornerShape(8.dp)
                    )
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Dirección skeleton
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(12.dp)
                    .background(
                        Color.Gray.copy(alpha = 0.3f),
                        RoundedCornerShape(6.dp)
                    )
            )

            Spacer(modifier = Modifier.weight(1f))

            // Footer skeleton
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.5f)
                    .height(12.dp)
                    .background(
                        Color.Gray.copy(alpha = 0.3f),
                        RoundedCornerShape(6.dp)
                    )
            )
        }
    }
}

@Composable
private fun SeeMoreBranchesCard(
    onClick: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .width(120.dp)
            .height(140.dp),
        alpha = 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(
                            MassOrange.copy(alpha = 0.2f),
                            RoundedCornerShape(24.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Ver más",
                        tint = MassOrange,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Ver todas",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            }
        }
    }
}

@Composable
private fun EmptyBranchesState(
    onRetry: () -> Unit,
    onViewAll: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "🏢",
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "No hay sucursales disponibles",
                style = MaterialTheme.typography.titleSmall.copy(
                    color = Color.Gray
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = onRetry) {
                    Text(
                        text = "Reintentar",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MassOrange
                        )
                    )
                }
                TextButton(onClick = onViewAll) {
                    Text(
                        text = "Ver todas",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MassBlue
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(
    onSearchClick: () -> Unit,
    onProfileClick: () -> Unit,
    onCartClick: () -> Unit,
    cartItemCount: Int = 0,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "¡Hola! 👋",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )
            Text(
                text = "¿Qué buscas hoy?",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = Color.Gray
                )
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            IconButton(
                onClick = onSearchClick,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MassOrange.copy(alpha = 0.1f))
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Buscar",
                    tint = MassOrange
                )
            }

            IconButton(
                onClick = onCartClick,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MassYellow.copy(alpha = 0.1f))
            ) {
                Box {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Carrito",
                        tint = MassYellow
                    )

                    // Badge del carrito
                    if (cartItemCount > 0) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .background(ErrorColor, CircleShape)
                                .align(Alignment.TopEnd),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (cartItemCount > 9) "9+" else cartItemCount.toString(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            IconButton(
                onClick = onProfileClick,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MassBlue.copy(alpha = 0.1f))
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Perfil",
                    tint = MassBlue
                )
            }
        }
    }
}

@Composable
private fun WelcomeBento(isVisible: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.8f,
        animationSpec = tween(800, delayMillis = 200),
        label = "scale"
    )

    BentoCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .scale(scale),
        gradient = MassGradient
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "¡Descubre ofertas increíbles!",
                style = MaterialTheme.typography.headlineSmall.copy(
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Hasta 70% de descuento en productos seleccionados",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.White.copy(alpha = 0.9f)
                )
            )
        }
    }
}

@Composable
private fun CategoriesSection(
    categories: List<Category>,
    onCategoryClick: (String) -> Unit, // Esto va a RecyclerView
    isVisible: Boolean,
    isLoading: Boolean,
    onRetryClick: () -> Unit
) {
    Column {
        SectionTitle(
            title = "Categorías",
            subtitle = when {
                isLoading -> "Cargando categorías..."
                categories.isEmpty() -> "No hay categorías disponibles"
                else -> "Explora por categoría (Vista Tradicional)"
            },
            isVisible = isVisible
        )

        Spacer(modifier = Modifier.height(16.dp))

        when {
            isLoading -> {
                // Skeleton loading para categorías
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(4) {
                        CategoryCardSkeleton()
                    }
                }
            }
            categories.isNotEmpty() -> {
                // Mostrar categorías - van a RecyclerView
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(categories) { category ->
                        CategoryCard(
                            category = category,
                            onClick = {
                                println("Categoría clickeada: ${category.id} → RecyclerView")
                                onCategoryClick(category.id)
                            }
                        )
                    }
                }
            }
            else -> {
                // Estado vacío para categorías
                EmptyCategoriesState(onRetryClick = onRetryClick)
            }
        }
    }
}

@Composable
private fun CategoryCardSkeleton() {
    Card(
        modifier = Modifier
            .width(120.dp)
            .height(100.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Gray.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        Color.Gray.copy(alpha = 0.3f),
                        RoundedCornerShape(8.dp)
                    )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .width(60.dp)
                    .height(12.dp)
                    .background(
                        Color.Gray.copy(alpha = 0.3f),
                        RoundedCornerShape(6.dp)
                    )
            )
        }
    }
}

@Composable
private fun EmptyCategoriesState(onRetryClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "🏷️",
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "No hay categorías disponibles",
                style = MaterialTheme.typography.titleSmall.copy(
                    color = Color.Gray
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            TextButton(onClick = onRetryClick) {
                Text(
                    text = "Reintentar",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MassOrange
                    )
                )
            }
        }
    }
}

@Composable
private fun FeaturedProductsSection(
    products: List<Product>,
    isVisible: Boolean,
    isLoading: Boolean,
    onNavigateToProducts: () -> Unit,
    onAddToCart: ((CartItem) -> Unit)? = null
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionTitle(
                title = "Destacados",
                subtitle = "Los más buscados cerca de ti",
                isVisible = isVisible
            )

            TextButton(
                onClick = {
                    println("Ver todos clickeado → Compose")
                    onNavigateToProducts()
                }
            ) {
                Text(
                    text = "Ver más",
                    color = MassOrange,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.SemiBold
                    )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Ver más",
                    tint = MassOrange,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when {
            isLoading -> {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(4) {
                        ProductCardSkeleton()
                    }
                }
            }
            products.isNotEmpty() -> {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(products.take(6)) { product ->
                        ProductCard(
                            product = product,
                            onClick = {
                                println("Producto clickeado: ${product.name}")
                                /* Navigate to product detail */
                            },
                            onAddToCart = onAddToCart
                        )
                    }

                    item {
                        SeeMoreCard(
                            onClick = {
                                println("Ver más desde SeeMoreCard → Compose")
                                onNavigateToProducts()
                            }
                        )
                    }
                }
            }
            else -> {
                EmptyProductsState()
            }
        }
    }
}

@Composable
private fun SeeMoreCard(
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(200.dp)
            .height(280.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            MassOrange.copy(alpha = 0.1f),
                            MassBlue.copy(alpha = 0.1f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(40.dp))
                        .background(MassOrange.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Ver más",
                        tint = MassOrange,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Ver todos",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                Text(
                    text = "los productos",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }
    }
}

@Composable
private fun ProductCardSkeleton() {
    Card(
        modifier = Modifier
            .width(200.dp)
            .height(280.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Gray.copy(alpha = 0.1f))
    ) {
        Column {
            // Imagen skeleton
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(Color.Gray.copy(alpha = 0.3f))
            )

            // Contenido skeleton
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                repeat(4) { index ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(
                                when (index) {
                                    0 -> 0.9f // Título
                                    1 -> 0.6f // Tienda
                                    2 -> 0.4f // Rating
                                    else -> 0.7f // Precio
                                }
                            )
                            .height(12.dp)
                            .background(
                                Color.Gray.copy(alpha = 0.3f),
                                RoundedCornerShape(6.dp)
                            )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
private fun EmptyProductsState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "📦",
                fontSize = 48.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "No hay productos disponibles",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = Color.Gray
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Desliza hacia abajo para actualizar",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray.copy(alpha = 0.7f)
                )
            )
        }
    }
}

@Composable
private fun QuickActionsSection(isVisible: Boolean) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 600),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        SectionTitle(
            title = "Acciones rápidas",
            subtitle = "Atajos útiles",
            isVisible = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickActionCard(
                title = "Favoritos",
                icon = Icons.Default.Favorite,
                color = listOf(Color(0xFFFF6B6B), Color(0xFFFF8E8E)),
                modifier = Modifier.weight(1f)
            )

            QuickActionCard(
                title = "Historial",
                icon = Icons.Default.AccountCircle,
                color = listOf(Color(0xFF4ECDC4), Color(0xFF44A08D)),
                modifier = Modifier.weight(1f)
            )

            QuickActionCard(
                title = "Ofertas",
                icon = Icons.Default.Add,
                color = MassGradient,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SectionTitle(
    title: String,
    subtitle: String,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600, delayMillis = 300),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = Color.Gray
            )
        )
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    icon: ImageVector,
    color: List<Color>,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.height(80.dp),
        alpha = 0.1f
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color.first(),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = MassBlue,
                    fontWeight = FontWeight.Medium
                )
            )
        }
    }
}