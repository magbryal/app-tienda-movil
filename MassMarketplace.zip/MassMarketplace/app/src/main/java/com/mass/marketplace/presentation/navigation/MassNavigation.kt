package com.mass.marketplace.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mass.marketplace.presentation.ui.screens.auth.AuthScreen
import com.mass.marketplace.presentation.ui.screens.cart.CartScreen
import com.mass.marketplace.presentation.ui.screens.branch.BranchListScreen
import com.mass.marketplace.presentation.ui.screens.branch.BranchMapScreen
import com.mass.marketplace.presentation.ui.screens.branch.BranchDetailScreen
import com.mass.marketplace.presentation.ui.screens.checkout.CheckoutScreen
import com.mass.marketplace.presentation.ui.screens.home.HomeScreen
import com.mass.marketplace.presentation.ui.screens.onboarding.OnboardingScreen
import com.mass.marketplace.presentation.ui.screens.order.OrderSuccessScreen
import com.mass.marketplace.presentation.ui.screens.orders.OrderHistoryScreen
import com.mass.marketplace.presentation.ui.screens.products.ProductsScreen
import com.mass.marketplace.presentation.ui.screens.profile.ProfileScreen
import com.mass.marketplace.presentation.ui.screens.search.SearchScreen
import com.mass.marketplace.presentation.ui.screens.splash.SplashScreen

@Composable
fun MassNavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = MassScreens.Splash.route
    ) {
        composable(route = MassScreens.Splash.route) {
            SplashScreen(
                onNavigateToAuth = {
                    navController.navigate(MassScreens.Auth.route) {
                        popUpTo(MassScreens.Splash.route) { inclusive = true }
                    }
                },
                onNavigateToHome = {
                    navController.navigate(MassScreens.Home.route) {
                        popUpTo(MassScreens.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(route = MassScreens.Onboarding.route) {
            OnboardingScreen(
                onNavigateToHome = {
                    navController.navigate(MassScreens.Home.route) {
                        popUpTo(MassScreens.Onboarding.route) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        composable(route = MassScreens.Home.route) {
            HomeScreen(
                onNavigateToProducts = { category ->
                    navController.navigate("${MassScreens.ProductsCompose.route}/$category")
                },
                onNavigateToAllProducts = {
                    navController.navigate("${MassScreens.ProductsCompose.route}/all")
                },
                onNavigateToProductsCompose = { category ->
                    navController.navigate("${MassScreens.ProductsCompose.route}/$category")
                },
                onNavigateToSearch = {
                    navController.navigate(MassScreens.Search.route)
                },
                onNavigateToProfile = {
                    navController.navigate(MassScreens.Profile.route)
                },
                onNavigateToCart = {
                    navController.navigate(MassScreens.Cart.route)
                },
                onNavigateToBranch = {
                    navController.navigate(MassScreens.BranchList.route)
                }
            )
        }

        composable(route = "${MassScreens.ProductsCompose.route}/{category}") { backStackEntry ->
            val category = backStackEntry.arguments?.getString("category") ?: "all"
            ProductsScreen(
                category = category,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(route = MassScreens.Cart.route) {
            CartScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToCheckout = {
                    navController.navigate(MassScreens.Checkout.route)
                },
                onNavigateToProducts = {
                    navController.navigate("${MassScreens.ProductsCompose.route}/all")
                }
            )
        }

        composable(route = MassScreens.Checkout.route) {
            CheckoutScreen(
                onNavigateBack = { navController.popBackStack() },
                onOrderComplete = {
                    navController.navigate(MassScreens.OrderSuccess.route) {
                        popUpTo(MassScreens.Home.route)
                    }
                },
                onNavigateToHome = {
                    navController.navigate(MassScreens.Home.route) {
                        popUpTo(MassScreens.Checkout.route) { inclusive = true }
                    }
                }
            )
        }

        composable(route = MassScreens.OrderSuccess.route) {
            OrderSuccessScreen(
                onNavigateToHome = {
                    navController.navigate(MassScreens.Home.route) {
                        popUpTo(MassScreens.OrderSuccess.route) { inclusive = true }
                    }
                },
                onNavigateToOrders = {
                    navController.navigate(MassScreens.Orders.route) {
                        popUpTo(MassScreens.Home.route)
                    }
                }
            )
        }

        composable(route = MassScreens.Orders.route) {
            OrderHistoryScreen(
                onNavigateBack = { navController.popBackStack() },
                onOrderClick = { order ->
                    println("Orden seleccionada: ${order.id}")
                    // navController.navigate("${MassScreens.OrderDetail.route}/${order.id}")
                }
            )
        }

        composable(route = MassScreens.BranchList.route) {
            BranchListScreen(
                onNavigateBack = { navController.popBackStack() },
                onNavigateToDetail = { branch ->
                    navController.navigate("${MassScreens.BranchDetail.route}/${branch.id}")
                },
                onNavigateToMap = {
                    navController.navigate(MassScreens.BranchMap.route)
                },
                onNavigateToCreate = {
                }
            )
        }

        composable(route = MassScreens.BranchMap.route) {
            BranchMapScreen(
                onNavigateBack = { navController.popBackStack() },
                onBranchSelected = { branch ->
                    println("Sucursal seleccionada en mapa: ${branch.name}")
                },
                onNavigateToDetail = { branch ->
                    navController.navigate("${MassScreens.BranchDetail.route}/${branch.id}")
                }
            )
        }

        composable(route = "${MassScreens.BranchDetail.route}/{branchId}") { backStackEntry ->
            val branchId = backStackEntry.arguments?.getString("branchId")?.toIntOrNull() ?: 0
            BranchDetailScreen(
                branchId = branchId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToEdit = { branch ->
                    println("Navegar a editar sucursal: ${branch.name}")
                },
                onNavigateToMap = { branch ->
                    navController.navigate(MassScreens.BranchMap.route)
                }
            )
        }

        composable(route = MassScreens.Search.route) {
            SearchScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(route = MassScreens.Profile.route) {
            ProfileScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToAuth = {
                    navController.navigate(MassScreens.Auth.route) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onNavigateToOrders = {
                    navController.navigate(MassScreens.Orders.route)
                }
            )
        }

        composable(route = MassScreens.Auth.route) {
            AuthScreen(
                onNavigateToHome = {
                    navController.navigate(MassScreens.Home.route) {
                        popUpTo(MassScreens.Auth.route) {
                            inclusive = true
                        }
                    }
                }
            )
        }
    }
}

sealed class MassScreens(val route: String) {
    data object Splash : MassScreens("splash")
    data object Auth : MassScreens("auth")
    data object Onboarding : MassScreens("onboarding")
    data object Home : MassScreens("home")
    data object Products : MassScreens("products")
    data object ProductsCompose : MassScreens("products_compose")
    data object Search : MassScreens("search")
    data object Profile : MassScreens("profile")
    data object Cart : MassScreens("cart")
    data object Checkout : MassScreens("checkout")
    data object OrderSuccess : MassScreens("order_success")
    data object Orders : MassScreens("orders")
    data object BranchList: MassScreens("branch_list")
    data object BranchMap: MassScreens("branch_map")
    data object BranchDetail: MassScreens("branch_detail")
}
