package com.mass.marketplace.core.di

import com.mass.marketplace.data.local.database.MassDatabase
import com.mass.marketplace.data.repository.AuthRepositoryImpl
import com.mass.marketplace.data.repository.BranchRepositoryImpl
import com.mass.marketplace.data.repository.CartRepositoryImpl
import com.mass.marketplace.data.repository.CategoryRepositoryImpl
import com.mass.marketplace.data.repository.OrderRepositoryImpl
import com.mass.marketplace.data.repository.PaymentRepositoryImpl
import com.mass.marketplace.data.repository.ProductRepositoryImpl
import com.mass.marketplace.domain.repository.AuthRepository
import com.mass.marketplace.domain.repository.BranchRepository
import com.mass.marketplace.domain.repository.CartRepository
import com.mass.marketplace.domain.repository.CategoryRepository
import com.mass.marketplace.domain.repository.OrderRepository
import com.mass.marketplace.domain.repository.PaymentRepository
import com.mass.marketplace.domain.repository.ProductRepository
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val repositoryModule = module {
    // ROOM
    single { MassDatabase.getDatabase(androidContext()) }
    single { get<MassDatabase>().orderDao() }

    single<AuthRepository> { AuthRepositoryImpl(get()) }
    single<ProductRepository> { ProductRepositoryImpl(get(), get()) }
    single<CategoryRepository> { CategoryRepositoryImpl(get(), get()) }
    single<CartRepository> { CartRepositoryImpl() }
    single<OrderRepository> { OrderRepositoryImpl(get(), get()) }
    single<BranchRepository> { BranchRepositoryImpl(get(), get()) }
    single<PaymentRepository> { PaymentRepositoryImpl() }
}
