package com.mass.marketplace.presentation.ui.components.branch

import android.annotation.SuppressLint
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.buttons.MassButton
import com.mass.marketplace.presentation.ui.components.buttons.MassButtonVariant
import com.mass.marketplace.presentation.ui.theme.*

// Enums para tipos de filtros
enum class BranchSortType(val displayName: String, val icon: ImageVector) {
    NAME_ASC("Nombre A-Z", Icons.Default.KeyboardArrowDown),
    NAME_DESC("Nombre Z-A", Icons.Default.KeyboardArrowUp),
    DISTANCE("Distancia", Icons.Default.LocationOn),
    NEWEST("Más Recientes", Icons.Default.Star),
    CAPACITY("Capacidad", Icons.Default.Person),
    RATING("Calificación", Icons.Default.Star)
}

enum class BranchDistanceFilter(val displayName: String, val maxDistance: Double) {
    ALL("Todas", Double.MAX_VALUE),
    NEARBY_1KM("1 km", 1.0),
    NEARBY_5KM("5 km", 5.0),
    NEARBY_10KM("10 km", 10.0),
    NEARBY_25KM("25 km", 25.0)
}

enum class BranchServiceFilter(val displayName: String, val icon: ImageVector) {
    PARKING("Estacionamiento", Icons.AutoMirrored.Filled.ExitToApp),
    WIFI("WiFi Gratuito", Icons.Default.Favorite),
    ACCESSIBILITY("Accesibilidad", Icons.Default.ThumbUp),
    TWENTY_FOUR_HOURS("24 Horas", Icons.Default.DateRange),
    DRIVE_THROUGH("Drive Through", Icons.Default.Done)
}

// Estado de filtros
data class BranchFilterState(
    val sortType: BranchSortType = BranchSortType.NAME_ASC,
    val distanceFilter: BranchDistanceFilter = BranchDistanceFilter.ALL,
    val serviceFilters: Set<BranchServiceFilter> = emptySet(),
    val isActiveOnly: Boolean = true,
    val hasCapacityFilter: Boolean = false,
    val minCapacity: Int = 0,
    val maxCapacity: Int = 1000,
    val searchQuery: String = "",
    val selectedRegions: Set<String> = emptySet(),
    val openNow: Boolean = false
)

@Composable
fun BranchFiltersBottomSheet(
    filterState: BranchFilterState,
    onFilterStateChange: (BranchFilterState) -> Unit,
    onApplyFilters: () -> Unit,
    onResetFilters: () -> Unit,
    onDismiss: () -> Unit,
    userLocation: Pair<Double, Double>? = null,
    availableRegions: List<String> = emptyList(),
    modifier: Modifier = Modifier
) {
    var localFilterState by remember { mutableStateOf(filterState) }
    val scrollState = rememberScrollState()

    LaunchedEffect(filterState) {
        localFilterState = filterState
    }

    GlassmorphicCard(
        modifier = modifier.fillMaxWidth(),
        alpha = 0.98f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.95f),
                            Color.White.copy(alpha = 0.98f)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            // Header
            BranchFiltersHeader(
                activeFiltersCount = getActiveFiltersCount(localFilterState),
                onDismiss = onDismiss,
                onReset = {
                    localFilterState = BranchFilterState()
                    onResetFilters()
                }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Filters Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Quick Filters
                BranchQuickFilters(
                    filterState = localFilterState,
                    onFilterStateChange = { localFilterState = it },
                    userLocation = userLocation
                )

                // Sort Section
                BranchSortSection(
                    selectedSort = localFilterState.sortType,
                    onSortChange = {
                        localFilterState = localFilterState.copy(sortType = it)
                    },
                    userLocation = userLocation
                )

                // Distance Filter
                if (userLocation != null) {
                    BranchDistanceSection(
                        selectedDistance = localFilterState.distanceFilter,
                        onDistanceChange = {
                            localFilterState = localFilterState.copy(distanceFilter = it)
                        }
                    )
                }

                // Services Filter
                BranchServicesSection(
                    selectedServices = localFilterState.serviceFilters,
                    onServicesChange = {
                        localFilterState = localFilterState.copy(serviceFilters = it)
                    }
                )

                // Capacity Filter
                BranchCapacitySection(
                    hasCapacityFilter = localFilterState.hasCapacityFilter,
                    minCapacity = localFilterState.minCapacity,
                    maxCapacity = localFilterState.maxCapacity,
                    onCapacityFilterChange = { enabled, min, max ->
                        localFilterState = localFilterState.copy(
                            hasCapacityFilter = enabled,
                            minCapacity = min,
                            maxCapacity = max
                        )
                    }
                )

                // Regions Filter
                if (availableRegions.isNotEmpty()) {
                    BranchRegionsSection(
                        availableRegions = availableRegions,
                        selectedRegions = localFilterState.selectedRegions,
                        onRegionsChange = {
                            localFilterState = localFilterState.copy(selectedRegions = it)
                        }
                    )
                }

                // Status Filters
                BranchStatusSection(
                    isActiveOnly = localFilterState.isActiveOnly,
                    openNow = localFilterState.openNow,
                    onActiveOnlyChange = {
                        localFilterState = localFilterState.copy(isActiveOnly = it)
                    },
                    onOpenNowChange = {
                        localFilterState = localFilterState.copy(openNow = it)
                    }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Bottom Actions
            BranchFiltersBottomActions(
                onApply = {
                    onFilterStateChange(localFilterState)
                    onApplyFilters()
                },
                onCancel = onDismiss,
                hasChanges = localFilterState != filterState
            )
        }
    }
}

@Composable
private fun BranchFiltersHeader(
    activeFiltersCount: Int,
    onDismiss: () -> Unit,
    onReset: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassmorphicCard(
                modifier = Modifier.size(48.dp),
                alpha = 0.2f,
                cornerRadius = 24.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(MassBlue, MassBlue.copy(alpha = 0.7f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Filtros",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(
                    text = "🔍 Filtros Avanzados",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                if (activeFiltersCount > 0) {
                    Text(
                        text = "$activeFiltersCount filtros activos",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MassOrange,
                            fontWeight = FontWeight.Medium
                        )
                    )
                } else {
                    Text(
                        text = "Personaliza tu búsqueda",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }

        Row {
            if (activeFiltersCount > 0) {
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = 0.2f,
                    cornerRadius = 20.dp,
                    onClick = onReset
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Resetear",
                            tint = ErrorColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))
            }

            GlassmorphicCard(
                modifier = Modifier.size(40.dp),
                alpha = 0.2f,
                cornerRadius = 20.dp,
                onClick = onDismiss
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cerrar",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchQuickFilters(
    filterState: BranchFilterState,
    onFilterStateChange: (BranchFilterState) -> Unit,
    userLocation: Pair<Double, Double>?
) {
    Column {
        BranchFilterSectionTitle(
            icon = Icons.Default.Menu,
            title = "Filtros Rápidos",
            subtitle = "Accesos directos más utilizados"
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            // Cerca de mí (solo si hay ubicación)
            if (userLocation != null) {
                item {
                    BranchQuickFilterChip(
                        label = "Cerca de mí",
                        icon = Icons.Default.LocationOn,
                        isSelected = filterState.distanceFilter == BranchDistanceFilter.NEARBY_5KM,
                        onClick = {
                            val newDistance =
                                if (filterState.distanceFilter == BranchDistanceFilter.NEARBY_5KM) {
                                    BranchDistanceFilter.ALL
                                } else {
                                    BranchDistanceFilter.NEARBY_5KM
                                }
                            onFilterStateChange(filterState.copy(distanceFilter = newDistance))
                        }
                    )
                }
            }

            // Abiertas ahora
            item {
                BranchQuickFilterChip(
                    label = "Abiertas ahora",
                    icon = Icons.Default.DateRange,
                    isSelected = filterState.openNow,
                    onClick = {
                        onFilterStateChange(filterState.copy(openNow = !filterState.openNow))
                    }
                )
            }

            // Con estacionamiento
            item {
                BranchQuickFilterChip(
                    label = "Con parking",
                    icon = Icons.Default.Done,
                    isSelected = filterState.serviceFilters.contains(BranchServiceFilter.PARKING),
                    onClick = {
                        val newServices =
                            if (filterState.serviceFilters.contains(BranchServiceFilter.PARKING)) {
                                filterState.serviceFilters - BranchServiceFilter.PARKING
                            } else {
                                filterState.serviceFilters + BranchServiceFilter.PARKING
                            }
                        onFilterStateChange(filterState.copy(serviceFilters = newServices))
                    }
                )
            }

            // Con WiFi
            item {
                BranchQuickFilterChip(
                    label = "WiFi gratis",
                    icon = Icons.Default.Favorite,
                    isSelected = filterState.serviceFilters.contains(BranchServiceFilter.WIFI),
                    onClick = {
                        val newServices =
                            if (filterState.serviceFilters.contains(BranchServiceFilter.WIFI)) {
                                filterState.serviceFilters - BranchServiceFilter.WIFI
                            } else {
                                filterState.serviceFilters + BranchServiceFilter.WIFI
                            }
                        onFilterStateChange(filterState.copy(serviceFilters = newServices))
                    }
                )
            }

            // Accesibles
            item {
                BranchQuickFilterChip(
                    label = "Accesible",
                    icon = Icons.Default.ThumbUp,
                    isSelected = filterState.serviceFilters.contains(BranchServiceFilter.ACCESSIBILITY),
                    onClick = {
                        val newServices =
                            if (filterState.serviceFilters.contains(BranchServiceFilter.ACCESSIBILITY)) {
                                filterState.serviceFilters - BranchServiceFilter.ACCESSIBILITY
                            } else {
                                filterState.serviceFilters + BranchServiceFilter.ACCESSIBILITY
                            }
                        onFilterStateChange(filterState.copy(serviceFilters = newServices))
                    }
                )
            }
        }
    }
}

@Composable
private fun BranchQuickFilterChip(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedScale by animateFloatAsState(
        targetValue = if (isSelected) 1.05f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "chip_scale"
    )

    GlassmorphicCard(
        modifier = modifier.scale(animatedScale),
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 20.dp,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.2f),
                                MassYellow.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) MassOrange else Color.Gray,
                modifier = Modifier.size(16.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = if (isSelected) MassOrange else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
        }
    }
}

@Composable
private fun BranchSortSection(
    selectedSort: BranchSortType,
    onSortChange: (BranchSortType) -> Unit,
    userLocation: Pair<Double, Double>?
) {
    Column {
        BranchFilterSectionTitle(
            icon = Icons.Default.KeyboardArrowDown,
            title = "Ordenar por",
            subtitle = "Elige cómo ordenar los resultados"
        )

        Spacer(modifier = Modifier.height(12.dp))

        val availableSorts = if (userLocation != null) {
            BranchSortType.values().toList()
        } else {
            BranchSortType.values().filter { it != BranchSortType.DISTANCE }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(availableSorts) { sortType ->
                BranchSortChip(
                    sortType = sortType,
                    isSelected = selectedSort == sortType,
                    onClick = { onSortChange(sortType) }
                )
            }
        }
    }
}

@Composable
private fun BranchSortChip(
    sortType: BranchSortType,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                MassBlue.copy(alpha = 0.2f),
                                MassBlue.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = sortType.icon,
                contentDescription = sortType.displayName,
                tint = if (isSelected) MassBlue else Color.Gray,
                modifier = Modifier.size(16.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = sortType.displayName,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (isSelected) MassBlue else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
        }
    }
}

@Composable
private fun BranchDistanceSection(
    selectedDistance: BranchDistanceFilter,
    onDistanceChange: (BranchDistanceFilter) -> Unit
) {
    Column {
        BranchFilterSectionTitle(
            icon = Icons.Default.LocationOn,
            title = "Distancia máxima",
            subtitle = "Filtra por proximidad a tu ubicación"
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(BranchDistanceFilter.entries.toTypedArray()) { distance ->
                BranchDistanceChip(
                    distanceFilter = distance,
                    isSelected = selectedDistance == distance,
                    onClick = { onDistanceChange(distance) }
                )
            }
        }
    }
}

@Composable
private fun BranchDistanceChip(
    distanceFilter: BranchDistanceFilter,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = if (isSelected) {
                        Brush.radialGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.3f),
                                MassOrange.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.radialGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = distanceFilter.displayName,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = if (isSelected) MassOrange else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
        }
    }
}

@Composable
private fun BranchServicesSection(
    selectedServices: Set<BranchServiceFilter>,
    onServicesChange: (Set<BranchServiceFilter>) -> Unit
) {
    Column {
        BranchFilterSectionTitle(
            icon = Icons.Default.Star,
            title = "Servicios disponibles",
            subtitle = "Filtra por servicios específicos"
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(BranchServiceFilter.values()) { service ->
                BranchServiceChip(
                    serviceFilter = service,
                    isSelected = selectedServices.contains(service),
                    onClick = {
                        val newServices = if (selectedServices.contains(service)) {
                            selectedServices - service
                        } else {
                            selectedServices + service
                        }
                        onServicesChange(newServices)
                    }
                )
            }
        }
    }
}

@Composable
private fun BranchServiceChip(
    serviceFilter: BranchServiceFilter,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                SuccessColor.copy(alpha = 0.2f),
                                SuccessColor.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = serviceFilter.icon,
                contentDescription = serviceFilter.displayName,
                tint = if (isSelected) SuccessColor else Color.Gray,
                modifier = Modifier.size(16.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = serviceFilter.displayName,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (isSelected) SuccessColor else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
        }
    }
}

@SuppressLint("AutoboxingStateCreation")
@Composable
private fun BranchCapacitySection(
    hasCapacityFilter: Boolean,
    minCapacity: Int,
    maxCapacity: Int,
    onCapacityFilterChange: (Boolean, Int, Int) -> Unit
) {
    var localMinCapacity by remember { mutableIntStateOf(minCapacity) }
    var localMaxCapacity by remember { mutableIntStateOf(maxCapacity) }

    LaunchedEffect(minCapacity, maxCapacity) {
        localMinCapacity = minCapacity
        localMaxCapacity = maxCapacity
    }

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BranchFilterSectionTitle(
                icon = Icons.Default.Person,
                title = "Capacidad",
                subtitle = "Filtra por número de personas"
            )

            Switch(
                checked = hasCapacityFilter,
                onCheckedChange = { enabled ->
                    onCapacityFilterChange(enabled, localMinCapacity, localMaxCapacity)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MassOrange,
                    checkedTrackColor = MassOrange.copy(alpha = 0.3f)
                )
            )
        }

        if (hasCapacityFilter) {
            Spacer(modifier = Modifier.height(16.dp))

            GlassmorphicCard(
                alpha = 0.1f,
                cornerRadius = 16.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Min Capacity
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mínimo",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = Color.Gray
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = localMinCapacity.toString(),
                                onValueChange = { value ->
                                    value.toIntOrNull()?.let { intValue ->
                                        if (intValue >= 0) {
                                            localMinCapacity = intValue
                                            onCapacityFilterChange(true, intValue, localMaxCapacity)
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MassOrange,
                                    cursorColor = MassOrange
                                ),
                                singleLine = true
                            )
                        }

                        // Max Capacity
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Máximo",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = Color.Gray
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedTextField(
                                value = localMaxCapacity.toString(),
                                onValueChange = { value ->
                                    value.toIntOrNull()?.let { intValue ->
                                        if (intValue >= localMinCapacity) {
                                            localMaxCapacity = intValue
                                            onCapacityFilterChange(true, localMinCapacity, intValue)
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MassOrange,
                                    cursorColor = MassOrange
                                ),
                                singleLine = true
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Range indicator
                    Text(
                        text = "Rango: $localMinCapacity - $localMaxCapacity personas",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MassOrange,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchRegionsSection(
    availableRegions: List<String>,
    selectedRegions: Set<String>,
    onRegionsChange: (Set<String>) -> Unit
) {
    Column {
        BranchFilterSectionTitle(
            icon = Icons.Default.LocationOn,
            title = "Regiones",
            subtitle = "Filtra por ubicación geográfica"
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(availableRegions) { region ->
                BranchRegionChip(
                    region = region,
                    isSelected = selectedRegions.contains(region),
                    onClick = {
                        val newRegions = if (selectedRegions.contains(region)) {
                            selectedRegions - region
                        } else {
                            selectedRegions + region
                        }
                        onRegionsChange(newRegions)
                    }
                )
            }
        }
    }
}

@Composable
private fun BranchRegionChip(
    region: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                MassBlue.copy(alpha = 0.2f),
                                Color(0xFF3B82F6).copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = region,
                tint = if (isSelected) MassBlue else Color.Gray,
                modifier = Modifier.size(14.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = region,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = if (isSelected) MassBlue else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
        }
    }
}

@Composable
private fun BranchStatusSection(
    isActiveOnly: Boolean,
    openNow: Boolean,
    onActiveOnlyChange: (Boolean) -> Unit,
    onOpenNowChange: (Boolean) -> Unit
) {
    Column {
        BranchFilterSectionTitle(
            icon = Icons.Default.Check,
            title = "Estado y disponibilidad",
            subtitle = "Filtra por estado operativo"
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Active Only Filter
            BranchStatusToggle(
                label = "Solo sucursales activas",
                description = "Mostrar únicamente sucursales en funcionamiento",
                icon = Icons.Default.CheckCircle,
                isChecked = isActiveOnly,
                onCheckedChange = onActiveOnlyChange,
                checkedColor = SuccessColor
            )

            // Open Now Filter
            BranchStatusToggle(
                label = "Abiertas ahora",
                description = "Filtrar por horario de atención actual",
                icon = Icons.Default.DateRange,
                isChecked = openNow,
                onCheckedChange = onOpenNowChange,
                checkedColor = MassOrange
            )
        }
    }
}

@Composable
private fun BranchStatusToggle(
    label: String,
    description: String,
    icon: ImageVector,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    checkedColor: Color
) {
    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 16.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = if (isChecked) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                checkedColor.copy(alpha = 0.1f),
                                Color.Transparent
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = 0.2f,
                    cornerRadius = 20.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.radialGradient(
                                    colors = if (isChecked) {
                                        listOf(checkedColor, checkedColor.copy(alpha = 0.7f))
                                    } else {
                                        listOf(Color.Gray, Color.LightGray)
                                    }
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium,
                            color = MassBlue
                        )
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }

            Switch(
                checked = isChecked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = checkedColor,
                    checkedTrackColor = checkedColor.copy(alpha = 0.3f),
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
                )
            )
        }
    }
}

@Composable
private fun BranchFilterSectionTitle(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlassmorphicCard(
            modifier = Modifier.size(40.dp),
            alpha = 0.2f,
            cornerRadius = 20.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(MassBlue, MassBlue.copy(alpha = 0.7f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray
                )
            )
        }
    }
}

@Composable
private fun BranchFiltersBottomActions(
    onApply: () -> Unit,
    onCancel: () -> Unit,
    hasChanges: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Cancel Button
        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color.Gray
            )
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Cancelar",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Cancelar")
        }

        // Apply Button
        MassButton(
            text = "Aplicar Filtros",
            onClick = onApply,
            variant = MassButtonVariant.Primary,
            modifier = Modifier.weight(2f),
            enabled = hasChanges
        )
    }
}

// Componente para mostrar filtros activos en la pantalla principal
@Composable
fun BranchActiveFiltersBar(
    filterState: BranchFilterState,
    onRemoveFilter: (String) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeFilters = getActiveFiltersDisplay(filterState)

    if (activeFilters.isNotEmpty()) {
        LazyRow(
            modifier = modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Clear all button
            item {
                GlassmorphicCard(
                    alpha = 0.2f,
                    cornerRadius = 16.dp,
                    onClick = onClearAll
                ) {
                    Row(
                        modifier = Modifier
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        ErrorColor.copy(alpha = 0.2f),
                                        ErrorColor.copy(alpha = 0.1f)
                                    )
                                )
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Limpiar todo",
                            tint = ErrorColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Limpiar",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = ErrorColor,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            // Active filters
            items(activeFilters) { filter ->
                BranchActiveFilterChip(
                    filter = filter,
                    onRemove = { onRemoveFilter(filter.key) }
                )
            }
        }
    }
}

@Composable
private fun BranchActiveFilterChip(
    filter: ActiveFilter,
    onRemove: () -> Unit
) {
    GlassmorphicCard(
        alpha = 0.2f,
        cornerRadius = 16.dp
    ) {
        Row(
            modifier = Modifier
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            MassOrange.copy(alpha = 0.2f),
                            MassOrange.copy(alpha = 0.1f)
                        )
                    )
                )
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = filter.displayText,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MassOrange,
                    fontWeight = FontWeight.Medium
                )
            )

            Spacer(modifier = Modifier.width(4.dp))

            GlassmorphicCard(
                modifier = Modifier
                    .size(16.dp)
                    .clickable { onRemove() },
                alpha = 0.3f,
                cornerRadius = 8.dp
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remover filtro",
                        tint = Color.White,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
        }
    }
}

// Data class para filtros activos
data class ActiveFilter(
    val key: String,
    val displayText: String
)

// Función para obtener el conteo de filtros activos
private fun getActiveFiltersCount(filterState: BranchFilterState): Int {
    var count = 0

    if (filterState.sortType != BranchSortType.NAME_ASC) count++
    if (filterState.distanceFilter != BranchDistanceFilter.ALL) count++
    if (filterState.serviceFilters.isNotEmpty()) count += filterState.serviceFilters.size
    if (!filterState.isActiveOnly) count++
    if (filterState.hasCapacityFilter) count++
    if (filterState.selectedRegions.isNotEmpty()) count += filterState.selectedRegions.size
    if (filterState.openNow) count++

    return count
}

// Función para obtener la lista de filtros activos para mostrar
private fun getActiveFiltersDisplay(filterState: BranchFilterState): List<ActiveFilter> {
    val filters = mutableListOf<ActiveFilter>()

    // Sort filter
    if (filterState.sortType != BranchSortType.NAME_ASC) {
        filters.add(ActiveFilter("sort", "Orden: ${filterState.sortType.displayName}"))
    }

    // Distance filter
    if (filterState.distanceFilter != BranchDistanceFilter.ALL) {
        filters.add(
            ActiveFilter(
                "distance",
                "Distancia: ${filterState.distanceFilter.displayName}"
            )
        )
    }

    // Service filters
    filterState.serviceFilters.forEach { service ->
        filters.add(ActiveFilter("service_${service.name}", service.displayName))
    }

    // Capacity filter
    if (filterState.hasCapacityFilter) {
        filters.add(
            ActiveFilter(
                "capacity",
                "Capacidad: ${filterState.minCapacity}-${filterState.maxCapacity}"
            )
        )
    }

    // Region filters
    filterState.selectedRegions.forEach { region ->
        filters.add(ActiveFilter("region_$region", region))
    }

    // Status filters
    if (filterState.openNow) {
        filters.add(ActiveFilter("open_now", "Abiertas ahora"))
    }

    if (!filterState.isActiveOnly) {
        filters.add(ActiveFilter("include_inactive", "Incluir inactivas"))
    }

    return filters
}

// Función para aplicar filtros a una lista de sucursales
fun applyBranchFilters(
    branches: List<Branch>,
    filterState: BranchFilterState,
    userLocation: Pair<Double, Double>? = null
): List<Branch> {
    var filteredBranches = branches

    // Filter by active status
    if (filterState.isActiveOnly) {
        filteredBranches = filteredBranches.filter { it.isActive }
    }

    // Filter by distance
    if (filterState.distanceFilter != BranchDistanceFilter.ALL && userLocation != null) {
        val (userLat, userLng) = userLocation
        filteredBranches = filteredBranches.filter { branch ->
            val distance = branch.distanceTo(userLat, userLng)
            distance <= filterState.distanceFilter.maxDistance
        }
    }

    // Filter by services
    if (filterState.serviceFilters.isNotEmpty()) {
        filteredBranches = filteredBranches.filter { branch ->
            filterState.serviceFilters.all { service ->
                when (service) {
                    BranchServiceFilter.PARKING -> branch.hasParking == true
                    BranchServiceFilter.WIFI -> branch.hasWifi == true
                    BranchServiceFilter.ACCESSIBILITY -> branch.hasAccessibility == true
                    BranchServiceFilter.TWENTY_FOUR_HOURS -> branch.is24Hours == true
                    BranchServiceFilter.DRIVE_THROUGH -> branch.hasDriveThrough == true
                }
            }
        }
    }

    // Filter by capacity
    if (filterState.hasCapacityFilter) {
        filteredBranches = filteredBranches.filter { branch ->
            val capacity = branch.capacity ?: 0
            capacity >= filterState.minCapacity && capacity <= filterState.maxCapacity
        }
    }

    // Filter by regions
    if (filterState.selectedRegions.isNotEmpty()) {
        filteredBranches = filteredBranches.filter { branch ->
            filterState.selectedRegions.any { region ->
                branch.address.contains(region, ignoreCase = true)
            }
        }
    }

    // Filter by open now (requires implementation of opening hours logic)
    if (filterState.openNow) {
        filteredBranches = filteredBranches.filter { branch ->
            // TODO: Implement logic to check if branch is currently open
            // This would require parsing opening hours and comparing with current time
            true // Placeholder
        }
    }

    // Apply sorting
    filteredBranches = when (filterState.sortType) {
        BranchSortType.NAME_ASC -> filteredBranches.sortedBy { it.name }
        BranchSortType.NAME_DESC -> filteredBranches.sortedByDescending { it.name }
        BranchSortType.DISTANCE -> {
            if (userLocation != null) {
                val (userLat, userLng) = userLocation
                filteredBranches.sortedBy { it.distanceTo(userLat, userLng) }
            } else {
                filteredBranches
            }
        }

        BranchSortType.NEWEST -> filteredBranches.sortedByDescending { it.createdAt }
        BranchSortType.CAPACITY -> filteredBranches.sortedByDescending { it.capacity ?: 0 }
        BranchSortType.RATING -> filteredBranches.sortedByDescending { it.rating ?: 0.0 }
    }

    return filteredBranches
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchFiltersBottomSheet(
    onDismiss: () -> Unit,
    onSortByDistance: () -> Unit,
    onSortByName: () -> Unit
) {
    // Implementación simplificada
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Filtros",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Button(
                onClick = {
                    onSortByDistance()
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ordenar por distancia")
            }

            Button(
                onClick = {
                    onSortByName()
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ordenar por nombre")
            }

            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Cerrar")
            }
        }
    }
}