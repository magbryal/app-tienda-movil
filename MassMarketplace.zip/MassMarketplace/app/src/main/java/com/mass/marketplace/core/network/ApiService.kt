package com.mass.marketplace.core.network

import com.mass.marketplace.data.model.request.BranchRequest
import com.mass.marketplace.data.model.request.LoginRequest
import com.mass.marketplace.data.model.request.OrderItemRequest
import com.mass.marketplace.data.model.request.OrderRequest
import com.mass.marketplace.data.model.request.RegisterRequest
import com.mass.marketplace.data.model.response.AuthResponse
import com.mass.marketplace.data.model.response.BranchResponse
import com.mass.marketplace.data.model.response.CategoryResponse
import com.mass.marketplace.data.model.response.OrderItemResponse
import com.mass.marketplace.data.model.response.OrderResponse
import com.mass.marketplace.data.model.response.ProductResponse
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @POST("grupo4/v1/auth/register")
    suspend fun register(@Body request: RegisterRequest): AuthResponse

    @POST("grupo4/v1/auth/login")
    suspend fun login(@Body request: LoginRequest): AuthResponse

    @GET("grupo4/v1/product")
    suspend fun getProducts(): List<ProductResponse>

    @GET("grupo4/v1/category")
    suspend fun getCategories(): List<CategoryResponse>

    @GET("grupo4/v1/orderItem")
    suspend fun getOrderItems(): List<OrderItemResponse>

    @POST("grupo4/v1/orderItem")
    suspend fun createOrderItem(@Body request: OrderItemRequest): Map<String, String>

    @GET("grupo4/v1/order")
    suspend fun getOrders(): List<OrderResponse>

    @POST("grupo4/v1/order")
    suspend fun createOrder(@Body request: OrderRequest): Map<String, String>

    @GET("grupo4/v1/branch")
    suspend fun getBranches(): List<BranchResponse>

    @POST("grupo4/v1/branch")
    suspend fun createBranch(@Body request: BranchRequest): Map<String, String>

    @PUT("grupo4/v1/branch/{id}")
    suspend fun updateBranch(
        @Path("id") id: Int,
        @Body request: BranchRequest
    ): Map<String, String>

    @DELETE("grupo4/v1/branch/{id}")
    suspend fun deleteBranch(@Path("id") id: Int): Map<String, String>

    @GET("grupo4/v1/branch/nearby")
    suspend fun getNearbyBranches(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("radius") radius: Double = 10.0
    ): List<BranchResponse>
}