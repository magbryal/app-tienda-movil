package com.mass.marketplace.data.model.request

data class RegisterRequest(
    val name: String,
    val last_name: String,
    val email: String,
    val password: String,
    val phone: String,
    val address: String
)
