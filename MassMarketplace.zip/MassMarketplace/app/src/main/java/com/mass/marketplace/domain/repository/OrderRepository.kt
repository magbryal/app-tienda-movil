package com.mass.marketplace.domain.repository

import com.mass.marketplace.domain.model.Order
import kotlinx.coroutines.flow.Flow

interface OrderRepository {
    suspend fun createOrder(order: Order): Result<String>
    suspend fun getOrders(): Result<List<Order>>

    // ROOM
    fun getLocalOrders(): Flow<List<Order>>
    suspend fun getOrderById(orderId: String): Order?
    suspend fun deleteOrder(orderId: String)
}
