package com.mass.marketplace.core.network

import com.mass.marketplace.data.local.SessionManager
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(
    private val sessionManager: SessionManager
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()

        // Rutas que NO necesitan autenticación
        val publicPaths = listOf(
            "/grupo4/v1/auth/login",
            "/grupo4/v1/auth/register"
        )

        // Si es una ruta pública, continuar sin token
        val isPublicPath = publicPaths.any { path ->
            originalRequest.url.encodedPath.contains(path)
        }

        val isTempSession = runBlocking {
            sessionManager.getAccessToken()?.startsWith("temp_") == true
        }

        if (isPublicPath || isTempSession) {
            return chain.proceed(originalRequest)
        }

        // Para rutas protegidas, agregar token
        val token = runBlocking {
            sessionManager.getAccessToken()
        }

        val authenticatedRequest = if (!token.isNullOrEmpty()) {
            originalRequest.newBuilder()
                .header("Authorization", "Bearer $token")
                .build()
        } else {
            originalRequest
        }

        return chain.proceed(authenticatedRequest)
    }
}
