package com.mass.marketplace.data.repository

import com.mass.marketplace.core.network.ApiService
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.data.model.response.toDomain
import com.mass.marketplace.domain.repository.CategoryRepository
import com.mass.marketplace.presentation.ui.screens.home.Category
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class CategoryRepositoryImpl(
    private val apiService: ApiService,
    private val sessionManager: SessionManager
) : CategoryRepository {

    override suspend fun getCategories(): Result<List<Category>> {
        return try {
            // Verificar sesión válida
            if (!sessionManager.hasValidSession()) {
                return Result.failure(Exception("Sesión expirada. Por favor, inicia sesión nuevamente."))
            }

            val response = apiService.getCategories()

            println("Respuesta cruda del API: $response")

            val categories = response.map { it.toDomain() }

            println("Categorías procesadas: ${categories.size}")
            categories.forEach { category ->
                println("Categoría: ${category.name} (ID: ${category.id})")
            }

            Result.success(categories)
        } catch (e: Exception) {
            val errorMessage = when (e) {
                is HttpException -> {
                    when (e.code()) {
                        401 -> {
                            sessionManager.clearSession()
                            "Sesión expirada. Por favor, inicia sesión nuevamente."
                        }
                        403 -> "No tienes permisos para acceder a las categorías."
                        404 -> "No se encontraron categorías disponibles."
                        500 -> "Error del servidor. Inténtalo más tarde."
                        else -> "Error HTTP ${e.code()}: ${e.message()}"
                    }
                }
                is UnknownHostException -> "No se pudo conectar al servidor. Verifica tu conexión a internet."
                is ConnectException -> "Error de conexión. Asegúrate de que el servidor esté disponible."
                is SocketTimeoutException -> "Tiempo de espera agotado. Inténtalo de nuevo."
                else -> "Error al cargar categorías: ${e.message}"
            }

            println("Error al obtener categorías: $errorMessage")
            println("Stack trace: ${e.printStackTrace()}")
            Result.failure(Exception(errorMessage))
        }
    }
}
