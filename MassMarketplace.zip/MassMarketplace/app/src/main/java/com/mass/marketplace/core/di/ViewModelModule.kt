package com.mass.marketplace.core.di

import com.mass.marketplace.core.viewmodel.AuthViewModel
import com.mass.marketplace.core.viewmodel.BranchViewModel
import com.mass.marketplace.core.viewmodel.CartViewModel
import com.mass.marketplace.core.viewmodel.CheckoutViewModel
import com.mass.marketplace.core.viewmodel.HomeViewModel
import com.mass.marketplace.core.viewmodel.OrderHistoryViewModel
import com.mass.marketplace.core.viewmodel.ProductsViewModel
import com.mass.marketplace.core.viewmodel.ProfileViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val viewModelModule = module {
    viewModel { AuthViewModel(get(), get(), get()) }
    viewModel { HomeViewModel(get(), get()) }
    viewModel { CartViewModel(get(), get(), get(), get(), get()) }
    viewModel { ProductsViewModel(get()) }
    viewModel { CheckoutViewModel(get(), get(), get(), get(), get()) }
    viewModel { ProfileViewModel(get(), get()) }
    viewModel { BranchViewModel(get(), get(), get(), get(), get(), get()) }
    viewModel { OrderHistoryViewModel(get()) }
}
