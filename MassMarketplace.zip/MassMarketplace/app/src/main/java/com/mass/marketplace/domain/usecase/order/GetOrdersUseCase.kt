package com.mass.marketplace.domain.usecase.order

import com.mass.marketplace.domain.model.Order
import com.mass.marketplace.domain.repository.OrderRepository
import kotlinx.coroutines.flow.Flow

class GetOrdersUseCase(
    private val orderRepository: OrderRepository
) {
    operator fun invoke(): Flow<List<Order>> {
        return orderRepository.getLocalOrders()
    }

    suspend fun refreshFromApi(): Result<List<Order>> {
        return orderRepository.getOrders()
    }
}
