package com.mass.marketplace.domain.usecase.branch

import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.repository.BranchRepository

class UpdateBranchUseCase(
    private val branchRepository: BranchRepository
) {
    suspend operator fun invoke(id: Int, branch: Branch): Result<String> {
        // Validaciones de negocio
        if (branch.name.isBlank()) {
            return Result.failure(Exception("El nombre de la sucursal no puede estar vacío."))
        }

        if (branch.address.isBlank()) {
            return Result.failure(Exception("La dirección de la sucursal no puede estar vacía."))
        }

        if (branch.phone.isBlank()) {
            return Result.failure(Exception("El teléfono de la sucursal no puede estar vacío."))
        }

        return branchRepository.updateBranch(id, branch)
    }
}