package com.mass.marketplace.data.repository

import com.mass.marketplace.core.network.ApiService
import com.mass.marketplace.data.model.request.LoginRequest
import com.mass.marketplace.data.model.request.RegisterRequest
import com.mass.marketplace.data.model.response.AuthResponse
import com.mass.marketplace.domain.repository.AuthRepository
import retrofit2.HttpException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class AuthRepositoryImpl(
    private val apiService: ApiService
) : AuthRepository {

    override suspend fun register(
        name: String,
        lastName: String,
        email: String,
        password: String,
        phone: String,
        address: String
    ): Result<AuthResponse> {
        return try {
            val response = apiService.register(
                RegisterRequest(
                    name = name,
                    last_name = lastName,
                    email = email,
                    password = password,
                    phone = phone,
                    address = address
                )
            )
            Result.success(response)
        } catch (e: Exception) {

            val errorMessage = when (e) {
                is HttpException -> {
                    println("Error HTTP ${e.code()}: ${e.message()}")
                    when (e.code()) {
                        401 -> "Credenciales incorrectas"
                        422 -> "Datos de registro inválidos"
                        500 -> "Error del servidor. Inténtalo más tarde"
                        else -> "Error HTTP ${e.code()}: ${e.message()}"
                    }
                }
                is UnknownHostException -> "No se pudo conectar al servidor. Verifica tu conexión."
                is ConnectException -> "Error de conexión. Asegúrate de que el servidor esté disponible."
                is SocketTimeoutException -> "Tiempo de espera agotado. Inténtalo de nuevo."
                else -> "Error al registrar usuario: ${e.message}"
            }
            Result.failure(Exception(errorMessage))
        }
    }

    override suspend fun login(
        email: String,
        password: String
    ): Result<AuthResponse> {
        return try {
            val response = apiService.login(
                LoginRequest(email = email, password = password)
            )
            Result.success(response)
        } catch (e: Exception) {
            val errorMessage = when (e) {
                is HttpException -> {
                    when (e.code()) {
                        401 -> "Credenciales incorrectas"
                        422 -> "Email o contraseña inválidos"
                        500 -> "Error del servidor. Inténtalo más tarde"
                        else -> "Error HTTP ${e.code()}: ${e.message()}"
                    }
                }
                is UnknownHostException -> "No se pudo conectar al servidor. Verifica tu conexión."
                is ConnectException -> "Error de conexión. Asegúrate de que el servidor esté disponible."
                is SocketTimeoutException -> "Tiempo de espera agotado. Inténtalo de nuevo."
                else -> "Error al iniciar sesión: ${e.message}"
            }
            Result.failure(Exception(errorMessage))
        }
    }
}
