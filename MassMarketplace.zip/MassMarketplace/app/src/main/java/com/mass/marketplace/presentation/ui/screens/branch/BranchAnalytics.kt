package com.mass.marketplace.presentation.ui.screens.branch

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.core.viewmodel.BranchViewModel
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

// Enums para tipos de métricas y períodos
enum class AnalyticsTimeRange(val displayName: String, val days: Int) {
    TODAY("Hoy", 1),
    WEEK("7 días", 7),
    MONTH("30 días", 30),
    QUARTER("3 meses", 90),
    YEAR("1 año", 365)
}

enum class MetricType(val displayName: String, val icon: ImageVector, val color: Color) {
    TOTAL_BRANCHES("Total Sucursales", Icons.Default.ShoppingCart, MassBlue),
    ACTIVE_BRANCHES("Activas", Icons.Default.CheckCircle, SuccessColor),
    REVENUE("Ingresos", Icons.Default.FavoriteBorder, MassOrange),
    CUSTOMERS("Clientes", Icons.Default.Person, Color(0xFF9C27B0)),
    GROWTH("Crecimiento", Icons.Default.KeyboardArrowUp, Color(0xFF4CAF50)),
    EFFICIENCY("Eficiencia", Icons.Default.ThumbUp, Color(0xFF2196F3))
}

enum class ChartType {
    LINE, BAR, PIE, AREA, DONUT
}

// Data classes para analytics
data class AnalyticsData(
    val totalBranches: Int = 0,
    val activeBranches: Int = 0,
    val inactiveBranches: Int = 0,
    val totalRevenue: Double = 0.0,
    val totalCustomers: Int = 0,
    val growthRate: Double = 0.0,
    val efficiencyScore: Double = 0.0,
    val topPerformingBranches: List<BranchPerformance> = emptyList(),
    val revenueByMonth: List<RevenueData> = emptyList(),
    val customersByRegion: List<RegionData> = emptyList(),
    val serviceUsage: List<ServiceData> = emptyList(),
    val performanceTrends: List<TrendData> = emptyList()
)

data class BranchPerformance(
    val branch: Branch,
    val revenue: Double,
    val customers: Int,
    val efficiency: Double,
    val growth: Double,
    val rank: Int
)

data class RevenueData(
    val month: String,
    val revenue: Double,
    val target: Double,
    val growth: Double
)

data class RegionData(
    val region: String,
    val branches: Int,
    val customers: Int,
    val revenue: Double,
    val percentage: Float
)

data class ServiceData(
    val service: String,
    val usage: Int,
    val percentage: Float,
    val trend: Double
)

data class TrendData(
    val date: String,
    val value: Double,
    val category: String
)

data class KPIMetric(
    val title: String,
    val value: String,
    val change: Double,
    val icon: ImageVector,
    val color: Color,
    val target: String? = null,
    val progress: Float? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchAnalyticsScreen(
    onNavigateBack: () -> Unit,
    onBranchClick: (Branch) -> Unit,
    viewModel: BranchViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    val uiState by viewModel.uiState.collectAsState()
    var selectedTimeRange by remember { mutableStateOf(AnalyticsTimeRange.MONTH) }
    var analyticsData by remember { mutableStateOf(AnalyticsData()) }
    var isRefreshing by remember { mutableStateOf(false) }
    var showDetailedView by remember { mutableStateOf(false) }
    var selectedMetric by remember { mutableStateOf<MetricType?>(null) }

    val scope = rememberCoroutineScope()
    val scrollState = rememberLazyListState()

    // Cargar datos de analytics
    LaunchedEffect(selectedTimeRange) {
        isRefreshing = true
        delay(1000) // Simular carga
        analyticsData = generateMockAnalyticsData(selectedTimeRange)
        isRefreshing = false
    }

    LoadingOverlay(
        isVisible = uiState.isLoading || isRefreshing,
        message = "Cargando analytics..."
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassBlue.copy(alpha = 0.05f),
                        Color.White,
                        MassOrange.copy(alpha = 0.03f)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.systemBars)
        ) {
            // Analytics Header
            BranchAnalyticsHeader(
                onNavigateBack = onNavigateBack,
                selectedTimeRange = selectedTimeRange,
                onTimeRangeChange = { selectedTimeRange = it },
                onRefresh = {
                    scope.launch {
                        isRefreshing = true
                        delay(1000)
                        analyticsData = generateMockAnalyticsData(selectedTimeRange)
                        isRefreshing = false
                    }
                },
                isRefreshing = isRefreshing
            )

            // Analytics Content
            LazyColumn(
                state = scrollState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // KPI Cards Section
                item {
                    BranchAnalyticsKPISection(
                        analyticsData = analyticsData,
                        onMetricClick = { metric ->
                            selectedMetric = metric
                            showDetailedView = true
                        }
                    )
                }

                // Quick Stats Overview
                item {
                    BranchAnalyticsQuickStats(analyticsData = analyticsData)
                }

                // Revenue Chart
                item {
                    BranchAnalyticsRevenueChart(
                        revenueData = analyticsData.revenueByMonth,
                        timeRange = selectedTimeRange
                    )
                }

                // Performance Distribution
                item {
                    BranchAnalyticsPerformanceChart(
                        regionData = analyticsData.customersByRegion
                    )
                }

                // Top Performing Branches
                item {
                    BranchAnalyticsTopBranches(
                        topBranches = analyticsData.topPerformingBranches,
                        onBranchClick = onBranchClick
                    )
                }

                // Service Usage Analytics
                item {
                    BranchAnalyticsServiceUsage(
                        serviceData = analyticsData.serviceUsage
                    )
                }

                // Trends and Insights
                item {
                    BranchAnalyticsTrends(
                        trendsData = analyticsData.performanceTrends,
                        timeRange = selectedTimeRange
                    )
                }

                // Recommendations Section
                item {
                    BranchAnalyticsRecommendations(analyticsData = analyticsData)
                }
            }
        }

        // Floating Action Buttons
        BranchAnalyticsFloatingActions(
            onExportData = { /* TODO: Export functionality */ },
            onScrollToTop = {
                scope.launch {
                    scrollState.animateScrollToItem(0)
                }
            },
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }

    // Detailed Metric View
    if (showDetailedView && selectedMetric != null) {
        ModalBottomSheet(
            onDismissRequest = {
                showDetailedView = false
                selectedMetric = null
            },
            containerColor = Color.Transparent,
            contentColor = Color.Transparent,
            dragHandle = null
        ) {
            BranchAnalyticsDetailedView(
                metric = selectedMetric!!,
                analyticsData = analyticsData,
                timeRange = selectedTimeRange,
                onDismiss = {
                    showDetailedView = false
                    selectedMetric = null
                }
            )
        }
    }
}

@Composable
private fun BranchAnalyticsHeader(
    onNavigateBack: () -> Unit,
    selectedTimeRange: AnalyticsTimeRange,
    onTimeRangeChange: (AnalyticsTimeRange) -> Unit,
    onRefresh: () -> Unit,
    isRefreshing: Boolean
) {
    GlassmorphicCard(
        modifier = Modifier.fillMaxWidth(),
        alpha = 0.95f,
        cornerRadius = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.95f),
                            Color.White.copy(alpha = 0.9f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            // Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(40.dp),
                        alpha = 0.2f,
                        cornerRadius = 20.dp,
                        onClick = onNavigateBack
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver",
                                tint = MassBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "📊 Analytics Dashboard",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MassBlue
                            )
                        )
                        Text(
                            text = "Insights y métricas de sucursales",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }

                // Refresh Button
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = 0.2f,
                    cornerRadius = 20.dp,
                    onClick = onRefresh
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(MassOrange, MassOrange.copy(alpha = 0.7f))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Actualizar",
                            tint = Color.White,
                            modifier = Modifier
                                .size(20.dp)
                                .then(
                                    if (isRefreshing) {
                                        Modifier.infiniteRotation()
                                    } else {
                                        Modifier
                                    }
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Time Range Selector
            BranchAnalyticsTimeRangeSelector(
                selectedRange = selectedTimeRange,
                onRangeChange = onTimeRangeChange
            )
        }
    }
}

@Composable
private fun BranchAnalyticsTimeRangeSelector(
    selectedRange: AnalyticsTimeRange,
    onRangeChange: (AnalyticsTimeRange) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
        items(AnalyticsTimeRange.values()) { range ->
            BranchAnalyticsTimeRangeChip(
                range = range,
                isSelected = selectedRange == range,
                onClick = { onRangeChange(range) }
            )
        }
    }
}

@Composable
private fun BranchAnalyticsTimeRangeChip(
    range: AnalyticsTimeRange,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val animatedScale by animateFloatAsState(
        targetValue = if (isSelected) 1.05f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "time_range_scale"
    )

    GlassmorphicCard(
        modifier = Modifier.scale(animatedScale),
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                MassBlue.copy(alpha = 0.3f),
                                MassBlue.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = range.displayName,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = if (isSelected) MassBlue else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            )
        }
    }
}

@Composable
private fun BranchAnalyticsKPISection(
    analyticsData: AnalyticsData,
    onMetricClick: (MetricType) -> Unit
) {
    Column {
        Text(
            text = "📈 Métricas Clave (KPIs)",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height(320.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val kpis = generateKPIMetrics(analyticsData)
            items(kpis) { kpi ->
                BranchAnalyticsKPICard(
                    kpi = kpi,
                    onClick = {
                        val metricType = MetricType.values().find { it.displayName == kpi.title }
                        metricType?.let { onMetricClick(it) }
                    }
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsKPICard(
    kpi: KPIMetric,
    onClick: () -> Unit
) {
    val animatedValue by animateFloatAsState(
        targetValue = kpi.progress ?: 0f,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "kpi_progress"
    )

    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            kpi.color.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                GlassmorphicCard(
                    modifier = Modifier.size(40.dp),
                    alpha = 0.3f,
                    cornerRadius = 20.dp
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(kpi.color, kpi.color.copy(alpha = 0.7f))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = kpi.icon,
                            contentDescription = kpi.title,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Change indicator
                if (kpi.change != 0.0) {
                    GlassmorphicCard(
                        alpha = 0.2f,
                        cornerRadius = 12.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .background(
                                    brush = Brush.horizontalGradient(
                                        colors = if (kpi.change > 0) {
                                            listOf(SuccessColor.copy(alpha = 0.2f), Color.Transparent)
                                        } else {
                                            listOf(ErrorColor.copy(alpha = 0.2f), Color.Transparent)
                                        }
                                    )
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (kpi.change > 0) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = "Tendencia",
                                tint = if (kpi.change > 0) SuccessColor else ErrorColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${if (kpi.change > 0) "+" else ""}${kpi.change.roundToInt()}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (kpi.change > 0) SuccessColor else ErrorColor,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = kpi.value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Text(
                text = kpi.title,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Progress bar if available
            if (kpi.progress != null && kpi.target != null) {
                Spacer(modifier = Modifier.height(8.dp))

                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Meta: ${kpi.target}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.Gray
                            )
                        )
                        Text(
                            text = "${(animatedValue * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = kpi.color,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(animatedValue)
                                .fillMaxHeight()
                                .background(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(kpi.color, kpi.color.copy(alpha = 0.7f))
                                    ),
                                    shape = RoundedCornerShape(2.dp)
                                )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsQuickStats(
    analyticsData: AnalyticsData
) {
    Column {
        Text(
            text = "⚡ Vista Rápida",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Active vs Inactive
            BranchAnalyticsQuickStatCard(
                title = "Estado Sucursales",
                value1 = "${analyticsData.activeBranches}",
                label1 = "Activas",
                color1 = SuccessColor,
                value2 = "${analyticsData.inactiveBranches}",
                label2 = "Inactivas",
                color2 = ErrorColor,
                modifier = Modifier.weight(1f)
            )

            // Growth Rate
            BranchAnalyticsQuickStatCard(
                title = "Crecimiento",
                value1 = "${analyticsData.growthRate.roundToInt()}%",
                label1 = "Este mes",
                color1 = if (analyticsData.growthRate > 0) SuccessColor else ErrorColor,
                value2 = "${analyticsData.efficiencyScore.roundToInt()}%",
                label2 = "Eficiencia",
                color2 = MassOrange,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun BranchAnalyticsQuickStatCard(
    title: String,
    value1: String,
    label1: String,
    color1: Color,
    value2: String,
    label2: String,
    color2: Color,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier,
        alpha = 0.1f,
        cornerRadius = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    color = Color.Gray,
                    fontWeight = FontWeight.Medium
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = value1,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = color1
                        )
                    )
                    Text(
                        text = label1,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(40.dp)
                        .background(Color.Gray.copy(alpha = 0.3f))
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = value2,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = color2
                        )
                    )
                    Text(
                        text = label2,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsRevenueChart(
    revenueData: List<RevenueData>,
    timeRange: AnalyticsTimeRange
) {
    Column {
        Text(
            text = "💰 Ingresos por Período",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.05f),
                                Color.Transparent
                            )
                        )
                    )
                    .padding(16.dp)
            ) {
                // Chart Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "S/ ${revenueData.sumOf { it.revenue }.roundToInt()}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MassOrange
                            )
                        )
                        Text(
                            text = "Total ${timeRange.displayName.lowercase()}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }

                    GlassmorphicCard(
                        alpha = 0.2f,
                        cornerRadius = 12.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .background(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(
                                            SuccessColor.copy(alpha = 0.2f),
                                            Color.Transparent
                                        )
                                    )
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowUp,
                                contentDescription = "Crecimiento",
                                tint = SuccessColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "+${revenueData.lastOrNull()?.growth?.roundToInt() ?: 0}%",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SuccessColor,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Simplified Chart Representation
                BranchAnalyticsSimpleLineChart(
                    data = revenueData.map { it.revenue },
                    labels = revenueData.map { it.month },
                    color = MassOrange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsSimpleLineChart(
    data: List<Double>,
    labels: List<String>,
    color: Color,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) return

    val maxValue = data.maxOrNull() ?: 0.0
    val minValue = data.minOrNull() ?: 0.0
    val range = maxValue - minValue

    // Usar BoxWithConstraints para obtener las dimensiones
    BoxWithConstraints(modifier = modifier) {
        val chartHeight = maxHeight
        val chartWidth = maxWidth

        // Background grid
        repeat(4) { index ->
            val y = (index + 1) * 0.2f
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .align(Alignment.TopStart)
                    .offset(y = (chartHeight * y))
                    .background(Color.Gray.copy(alpha = 0.2f))
            )
        }

        // Data points and line
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            data.forEachIndexed { index, value ->
                val normalizedHeight = if (range > 0) {
                    ((value - minValue) / range).toFloat()
                } else {
                    0.5f
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Data point
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(color, CircleShape)
                            .offset(y = -(chartHeight * normalizedHeight) + (chartHeight * 0.8f))
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // Label
                    Text(
                        text = labels.getOrNull(index) ?: "",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray,
                            fontSize = 10.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}


@Composable
private fun BranchAnalyticsPerformanceChart(
    regionData: List<RegionData>
) {
    Column {
        Text(
            text = "🌍 Distribución por Regiones",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                regionData.forEach { region ->
                    BranchAnalyticsRegionItem(
                        region = region,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsRegionItem(
    region: RegionData,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = region.percentage,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "region_progress"
    )

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(
                            color = getRegionColor(region.region),
                            shape = CircleShape
                        )
                )

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = region.region,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = MassBlue
                    )
                )
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${region.branches} sucursales",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray
                    )
                )
                Text(
                    text = "${(animatedProgress * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = getRegionColor(region.region)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Progress bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedProgress)
                    .fillMaxHeight()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                getRegionColor(region.region),
                                getRegionColor(region.region).copy(alpha = 0.7f)
                            )
                        ),
                        shape = RoundedCornerShape(3.dp)
                    )
            )
        }
    }
}

@Composable
private fun BranchAnalyticsTopBranches(
    topBranches: List<BranchPerformance>,
    onBranchClick: (Branch) -> Unit
) {
    Column {
        Text(
            text = "🏆 Top Sucursales Rendimiento",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            topBranches.take(5).forEach { performance ->
                BranchAnalyticsTopBranchItem(
                    performance = performance,
                    onClick = { onBranchClick(performance.branch) }
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsTopBranchItem(
    performance: BranchPerformance,
    onClick: () -> Unit
) {
    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            getRankColor(performance.rank).copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rank Badge
            GlassmorphicCard(
                modifier = Modifier.size(40.dp),
                alpha = 0.3f,
                cornerRadius = 20.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    getRankColor(performance.rank),
                                    getRankColor(performance.rank).copy(alpha = 0.7f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "#${performance.rank}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Branch Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = performance.branch.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = performance.branch.address,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BranchAnalyticsMetricChip(
                        label = "Ingresos",
                        value = "S/ ${performance.revenue.roundToInt()}",
                        color = MassOrange
                    )

                    BranchAnalyticsMetricChip(
                        label = "Clientes",
                        value = "${performance.customers}",
                        color = MassBlue
                    )
                }
            }

            // Performance Score
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "${performance.efficiency.roundToInt()}%",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = getRankColor(performance.rank)
                    )
                )

                Text(
                    text = "Eficiencia",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (performance.growth > 0) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Tendencia",
                        tint = if (performance.growth > 0) SuccessColor else ErrorColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${if (performance.growth > 0) "+" else ""}${performance.growth.roundToInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (performance.growth > 0) SuccessColor else ErrorColor,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsMetricChip(
    label: String,
    value: String,
    color: Color
) {
    GlassmorphicCard(
        alpha = 0.2f,
        cornerRadius = 8.dp
    ) {
        Column(
            modifier = Modifier
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            color.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
                .padding(horizontal = 6.dp, vertical = 3.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color.Gray,
                    fontSize = 8.sp
                )
            )
        }
    }
}

@Composable
private fun BranchAnalyticsServiceUsage(
    serviceData: List<ServiceData>
) {
    Column {
        Text(
            text = "🛠️ Uso de Servicios",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                serviceData.forEach { service ->
                    BranchAnalyticsServiceItem(service = service)
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsServiceItem(
    service: ServiceData
) {
    val animatedProgress by animateFloatAsState(
        targetValue = service.percentage,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "service_progress"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = service.service,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = MassBlue
                    )
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${service.usage} usos",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Icon(
                        imageVector = if (service.trend > 0) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Tendencia",
                        tint = if (service.trend > 0) SuccessColor else ErrorColor,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .fillMaxHeight()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(MassOrange, MassOrange.copy(alpha = 0.7f))
                            ),
                            shape = RoundedCornerShape(2.dp)
                        )
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsTrends(
    trendsData: List<TrendData>,
    timeRange: AnalyticsTimeRange
) {
    Column {
        Text(
            text = "📈 Tendencias y Patrones",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(getTrendCategories()) { category ->
                BranchAnalyticsTrendCard(
                    category = category,
                    data = trendsData.filter { it.category == category }
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsTrendCard(
    category: String,
    data: List<TrendData>
) {
    val averageValue = data.map { it.value }.average()
    val trend = if (data.size >= 2) {
        data.last().value - data.first().value
    } else {
        0.0
    }

    GlassmorphicCard(
        modifier = Modifier.width(160.dp),
        alpha = 0.1f,
        cornerRadius = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            getCategoryColor(category).copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = category,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    ),
                    modifier = Modifier.weight(1f)
                )

                Icon(
                    imageVector = if (trend > 0) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = "Tendencia",
                    tint = if (trend > 0) SuccessColor else ErrorColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "${averageValue.roundToInt()}",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = getCategoryColor(category)
                )
            )

            Text(
                text = "Promedio",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color.Gray
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Mini trend line
            BranchAnalyticsMiniTrendLine(
                data = data.map { it.value },
                color = getCategoryColor(category),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
            )
        }
    }
}

@Composable
private fun BranchAnalyticsMiniTrendLine(
    data: List<Double>,
    color: Color,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) return

    val maxValue = data.maxOrNull() ?: 0.0
    val minValue = data.minOrNull() ?: 0.0
    val range = maxValue - minValue

    Box(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            data.forEach { value ->
                val normalizedHeight = if (range > 0) {
                    ((value - minValue) / range).toFloat()
                } else {
                    0.5f
                }

                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .fillMaxHeight(normalizedHeight.coerceIn(0.1f, 1f))
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(color, color.copy(alpha = 0.5f))
                            ),
                            shape = RoundedCornerShape(1.dp)
                        )
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsRecommendations(
    analyticsData: AnalyticsData
) {
    val recommendations = generateRecommendations(analyticsData)

    Column {
        Text(
            text = "💡 Recomendaciones Inteligentes",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            recommendations.forEach { recommendation ->
                BranchAnalyticsRecommendationCard(recommendation = recommendation)
            }
        }
    }
}

@Composable
private fun BranchAnalyticsRecommendationCard(
    recommendation: AnalyticsRecommendation
) {
    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 16.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            recommendation.priority.color.copy(alpha = 0.1f),
                            Color.Transparent
                        )
                    )
                )
                .padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            GlassmorphicCard(
                modifier = Modifier.size(40.dp),
                alpha = 0.3f,
                cornerRadius = 20.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    recommendation.priority.color,
                                    recommendation.priority.color.copy(alpha = 0.7f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = recommendation.icon,
                        contentDescription = recommendation.title,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = recommendation.title,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassBlue
                        )
                    )

                    GlassmorphicCard(
                        alpha = 0.2f,
                        cornerRadius = 8.dp
                    ) {
                        Text(
                            text = recommendation.priority.displayName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = recommendation.priority.color,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = recommendation.description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    )
                )

                if (recommendation.impact != null) {
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowUp,
                            contentDescription = "Impacto",
                            tint = SuccessColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Impacto estimado: ${recommendation.impact}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SuccessColor,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsFloatingActions(
    onExportData: () -> Unit,
    onScrollToTop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Scroll to top
        GlassmorphicCard(
            modifier = Modifier.size(56.dp),
            alpha = 0.3f,
            cornerRadius = 28.dp,
            onClick = onScrollToTop
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(MassBlue, MassBlue.copy(alpha = 0.8f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowUp,
                    contentDescription = "Ir arriba",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Export data
        GlassmorphicCard(
            modifier = Modifier.size(56.dp),
            alpha = 0.3f,
            cornerRadius = 28.dp,
            onClick = onExportData
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(MassOrange, MassOrange.copy(alpha = 0.8f))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Exportar datos",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedView(
    metric: MetricType,
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange,
    onDismiss: () -> Unit
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(600.dp),
        alpha = 0.95f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.95f),
                            Color.White.copy(alpha = 0.9f)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(40.dp),
                        alpha = 0.3f,
                        cornerRadius = 20.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = listOf(metric.color, metric.color.copy(alpha = 0.7f))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = metric.icon,
                                contentDescription = metric.displayName,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = metric.displayName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassBlue
                        )
                    )
                }

                GlassmorphicCard(
                    modifier = Modifier.size(32.dp),
                    alpha = 0.2f,
                    cornerRadius = 16.dp,
                    onClick = onDismiss
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Cerrar",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Detailed content based on metric type
            when (metric) {
                MetricType.TOTAL_BRANCHES -> {
                    BranchAnalyticsDetailedBranches(analyticsData, timeRange)
                }
                MetricType.REVENUE -> {
                    BranchAnalyticsDetailedRevenue(analyticsData, timeRange)
                }
                MetricType.CUSTOMERS -> {
                    BranchAnalyticsDetailedCustomers(analyticsData, timeRange)
                }
                MetricType.GROWTH -> {
                    BranchAnalyticsDetailedGrowth(analyticsData, timeRange)
                }
                MetricType.ACTIVE_BRANCHES -> {
                    BranchAnalyticsDetailedActive(analyticsData, timeRange)
                }
                MetricType.EFFICIENCY -> {
                    BranchAnalyticsDetailedEfficiency(analyticsData, timeRange)
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedBranches(
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Summary Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BranchAnalyticsDetailedStat(
                title = "Total",
                value = "${analyticsData.totalBranches}",
                color = MassBlue
            )
            BranchAnalyticsDetailedStat(
                title = "Activas",
                value = "${analyticsData.activeBranches}",
                color = SuccessColor
            )
            BranchAnalyticsDetailedStat(
                title = "Inactivas",
                value = "${analyticsData.inactiveBranches}",
                color = ErrorColor
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Distribution Chart
        Text(
            text = "Distribución por Estado",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        BranchAnalyticsDetailedPieChart(
            data = listOf(
                PieChartData("Activas", analyticsData.activeBranches.toFloat(), SuccessColor),
                PieChartData("Inactivas", analyticsData.inactiveBranches.toFloat(), ErrorColor)
            )
        )
    }
}

@Composable
private fun BranchAnalyticsDetailedRevenue(
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Revenue Summary
        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "S/ ${analyticsData.totalRevenue.roundToInt()}",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassOrange
                    )
                )
                Text(
                    text = "Ingresos totales - ${timeRange.displayName}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Revenue Trend
        Text(
            text = "Tendencia de Ingresos",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        BranchAnalyticsSimpleLineChart(
            data = analyticsData.revenueByMonth.map { it.revenue },
            labels = analyticsData.revenueByMonth.map { it.month },
            color = MassOrange,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Top Revenue Branches
        Text(
            text = "Top 3 Sucursales por Ingresos",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            analyticsData.topPerformingBranches.take(3).forEach { performance ->
                BranchAnalyticsDetailedBranchItem(
                    name = performance.branch.name,
                    value = "S/ ${performance.revenue.roundToInt()}",
                    rank = performance.rank,
                    color = MassOrange
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedCustomers(
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Customer Summary
        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${analyticsData.totalCustomers}",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF9C27B0)
                    )
                )
                Text(
                    text = "Clientes totales - ${timeRange.displayName}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Customers by Region
        Text(
            text = "Distribución por Región",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            analyticsData.customersByRegion.forEach { region ->
                BranchAnalyticsDetailedRegionItem(
                    region = region.region,
                    customers = region.customers,
                    percentage = region.percentage,
                    color = getRegionColor(region.region)
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedGrowth(
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Growth Summary
        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (analyticsData.growthRate > 0) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Crecimiento",
                        tint = if (analyticsData.growthRate > 0) SuccessColor else ErrorColor,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${if (analyticsData.growthRate > 0) "+" else ""}${analyticsData.growthRate.roundToInt()}%",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (analyticsData.growthRate > 0) SuccessColor else ErrorColor
                        )
                    )
                }
                Text(
                    text = "Crecimiento - ${timeRange.displayName}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Growth Factors
        Text(
            text = "Factores de Crecimiento",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        val growthFactors = listOf(
            GrowthFactor("Nuevas sucursales", 35.0, SuccessColor),
            GrowthFactor("Aumento de clientes", 28.0, MassBlue),
            GrowthFactor("Mejora en servicios", 22.0, MassOrange),
            GrowthFactor("Expansión geográfica", 15.0, Color(0xFF9C27B0))
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            growthFactors.forEach { factor ->
                BranchAnalyticsDetailedGrowthFactor(factor = factor)
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedActive(
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Active Branches Summary
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BranchAnalyticsDetailedStat(
                title = "Activas",
                value = "${analyticsData.activeBranches}",
                color = SuccessColor
            )
            BranchAnalyticsDetailedStat(
                title = "% del Total",
                value = "${((analyticsData.activeBranches.toFloat() / analyticsData.totalBranches) * 100).roundToInt()}%",
                color = MassBlue
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Activity Status
        Text(
            text = "Estado de Actividad",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        val activityLevels = listOf(
            ActivityLevel("Alta actividad", 12, SuccessColor),
            ActivityLevel("Actividad media", 8, MassOrange),
            ActivityLevel("Baja actividad", 5, Color(0xFFFF9800)),
            ActivityLevel("Inactivas", analyticsData.inactiveBranches, ErrorColor)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            activityLevels.forEach { level ->
                BranchAnalyticsDetailedActivityLevel(level = level)
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedEfficiency(
    analyticsData: AnalyticsData,
    timeRange: AnalyticsTimeRange
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Efficiency Summary
        GlassmorphicCard(
            alpha = 0.1f,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${analyticsData.efficiencyScore.roundToInt()}%",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2196F3)
                    )
                )
                Text(
                    text = "Eficiencia promedio - ${timeRange.displayName}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Efficiency Metrics
        Text(
            text = "Métricas de Eficiencia",
            style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        val efficiencyMetrics = listOf(
            EfficiencyMetric("Tiempo de respuesta", 85.0, Color(0xFF4CAF50)),
            EfficiencyMetric("Satisfacción cliente", 92.0, SuccessColor),
            EfficiencyMetric("Utilización recursos", 78.0, MassOrange),
            EfficiencyMetric("Productividad", 88.0, MassBlue)
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            efficiencyMetrics.forEach { metric ->
                BranchAnalyticsDetailedEfficiencyMetric(metric = metric)
            }
        }
    }
}

// Helper Composables
@Composable
private fun BranchAnalyticsDetailedStat(
    title: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color
            )
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color.Gray
            )
        )
    }
}

@Composable
private fun BranchAnalyticsDetailedPieChart(
    data: List<PieChartData>
) {
    // Simplified pie chart representation
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Chart placeholder
        Box(
            modifier = Modifier
                .size(120.dp)
                .background(Color.Gray.copy(alpha = 0.1f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "📊",
                style = MaterialTheme.typography.headlineLarge
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Legend
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            data.forEach { item ->
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(item.color, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${item.label}: ${item.value.roundToInt()}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MassBlue
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedBranchItem(
    name: String,
    value: String,
    rank: Int,
    color: Color
) {
    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "#$rank",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = color,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.width(30.dp)
            )

            Text(
                text = name,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MassBlue
                ),
                modifier = Modifier.weight(1f)
            )

            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = color,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedRegionItem(
    region: String,
    customers: Int,
    percentage: Float,
    color: Color
) {
    val animatedProgress by animateFloatAsState(
        targetValue = percentage,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "region_detail_progress"
    )

    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 12.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = region,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = MassBlue
                    )
                )
                Text(
                    text = "$customers clientes",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .fillMaxHeight()
                        .background(color, RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedGrowthFactor(
    factor: GrowthFactor
) {
    val animatedProgress by animateFloatAsState(
        targetValue = factor.percentage.toFloat() / 100f,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "growth_factor_progress"
    )

    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 12.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = factor.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = MassBlue
                    )
                )
                Text(
                    text = "${factor.percentage.roundToInt()}%",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = factor.color,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .fillMaxHeight()
                        .background(factor.color, RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedActivityLevel(
    level: ActivityLevel
) {
    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(level.color, CircleShape)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = level.name,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MassBlue
                ),
                modifier = Modifier.weight(1f)
            )

            Text(
                text = "${level.count} sucursales",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.Gray
                )
            )
        }
    }
}

@Composable
private fun BranchAnalyticsDetailedEfficiencyMetric(
    metric: EfficiencyMetric
) {
    val animatedProgress by animateFloatAsState(
        targetValue = metric.score.toFloat() / 100f,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "efficiency_metric_progress"
    )

    GlassmorphicCard(
        alpha = 0.1f,
        cornerRadius = 12.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = metric.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = MassBlue
                    )
                )
                Text(
                    text = "${metric.score.roundToInt()}%",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = metric.color,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .background(Color.Gray.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .fillMaxHeight()
                        .background(metric.color, RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

// Data classes for detailed views
data class PieChartData(
    val label: String,
    val value: Float,
    val color: Color
)

data class GrowthFactor(
    val name: String,
    val percentage: Double,
    val color: Color
)

data class ActivityLevel(
    val name: String,
    val count: Int,
    val color: Color
)

data class EfficiencyMetric(
    val name: String,
    val score: Double,
    val color: Color
)

// Recommendation system
enum class RecommendationPriority(val displayName: String, val color: Color) {
    HIGH("Alta", ErrorColor),
    MEDIUM("Media", MassOrange),
    LOW("Baja", MassBlue)
}

data class AnalyticsRecommendation(
    val title: String,
    val description: String,
    val priority: RecommendationPriority,
    val icon: ImageVector,
    val impact: String? = null
)

// Extension functions and helper methods
private fun Modifier.infiniteRotation(): Modifier = composed {
    val infiniteTransition = rememberInfiniteTransition(label = "rotation")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_animation"
    )
    this.rotate(rotation)
}

private fun generateMockAnalyticsData(timeRange: AnalyticsTimeRange): AnalyticsData {
    return AnalyticsData(
        totalBranches = 45,
        activeBranches = 38,
        inactiveBranches = 7,
        totalRevenue = 285000.0,
        totalCustomers = 12500,
        growthRate = 15.3,
        efficiencyScore = 87.5,
        topPerformingBranches = generateMockTopBranches(),
        revenueByMonth = generateMockRevenueData(),
        customersByRegion = generateMockRegionData(),
        serviceUsage = generateMockServiceData(),
        performanceTrends = generateMockTrendData()
    )
}

private fun generateMockTopBranches(): List<BranchPerformance> {
    return listOf(
        BranchPerformance(
            branch = Branch(
                id = 1,
                name = "Sucursal Centro",
                address = "Av. Arequipa 123, Lima",
                phone = "01-234-5678",
                latitude = -12.0464,
                longitude = -77.0428,
                email = "centro@mass.com",
                isActive = true
            ),
            revenue = 45000.0,
            customers = 850,
            efficiency = 95.0,
            growth = 18.5,
            rank = 1
        ),
        BranchPerformance(
            branch = Branch(
                id = 2,
                name = "Sucursal Miraflores",
                address = "Av. Larco 456, Miraflores",
                phone = "01-234-5679",
                latitude = -12.1196,
                longitude = -77.0365,
                email = "miraflores@mass.com",
                isActive = true
            ),
            revenue = 38000.0,
            customers = 720,
            efficiency = 92.0,
            growth = 15.2,
            rank = 2
        ),
        BranchPerformance(
            branch = Branch(
                id = 3,
                name = "Sucursal San Isidro",
                address = "Av. República 789, San Isidro",
                phone = "01-234-5680",
                latitude = -12.0969,
                longitude = -77.0362,
                email = "sanisidro@mass.com",
                isActive = true
            ),
            revenue = 32000.0,
            customers = 650,
            efficiency = 88.0,
            growth = 12.8,
            rank = 3
        )
    )
}


private fun generateMockRevenueData(): List<RevenueData> {
    return listOf(
        RevenueData("Ene", 25000.0, 30000.0, 5.2),
        RevenueData("Feb", 28000.0, 30000.0, 12.0),
        RevenueData("Mar", 32000.0, 30000.0, 14.3),
        RevenueData("Abr", 29000.0, 30000.0, -9.4),
        RevenueData("May", 35000.0, 30000.0, 20.7),
        RevenueData("Jun", 38000.0, 30000.0, 8.6)
    )
}

private fun generateMockRegionData(): List<RegionData> {
    return listOf(
        RegionData("Lima Centro", 15, 4500, 125000.0, 0.36f),
        RegionData("Miraflores", 8, 2800, 98000.0, 0.22f),
        RegionData("San Isidro", 6, 2200, 75000.0, 0.18f),
        RegionData("Surco", 5, 1800, 52000.0, 0.14f),
        RegionData("Otros", 11, 1200, 35000.0, 0.10f)
    )
}

private fun generateMockServiceData(): List<ServiceData> {
    return listOf(
        ServiceData("WiFi Gratis", 850, 0.85f, 12.5),
        ServiceData("Estacionamiento", 720, 0.72f, 8.3),
        ServiceData("Atención 24h", 480, 0.48f, -2.1),
        ServiceData("Delivery", 650, 0.65f, 25.8),
        ServiceData("Cajero ATM", 920, 0.92f, 5.2)
    )
}

private fun generateMockTrendData(): List<TrendData> {
    return listOf(
        TrendData("2024-01", 85.0, "Satisfacción"),
        TrendData("2024-02", 87.0, "Satisfacción"),
        TrendData("2024-03", 89.0, "Satisfacción"),
        TrendData("2024-01", 75.0, "Eficiencia"),
        TrendData("2024-02", 78.0, "Eficiencia"),
        TrendData("2024-03", 82.0, "Eficiencia")
    )
}

private fun generateKPIMetrics(analyticsData: AnalyticsData): List<KPIMetric> {
    return listOf(
        KPIMetric(
            title = "Total Sucursales",
            value = "${analyticsData.totalBranches}",
            change = 8.5,
            icon = Icons.Default.ShoppingCart,
            color = MassBlue,
            target = "50",
            progress = analyticsData.totalBranches / 50f
        ),
        KPIMetric(
            title = "Activas",
            value = "${analyticsData.activeBranches}",
            change = 12.3,
            icon = Icons.Default.CheckCircle,
            color = SuccessColor,
            target = "${analyticsData.totalBranches}",
            progress = analyticsData.activeBranches.toFloat() / analyticsData.totalBranches
        ),
        KPIMetric(
            title = "Ingresos",
            value = "S/ ${(analyticsData.totalRevenue / 1000).roundToInt()}K",
            change = 15.7,
            icon = Icons.Default.Favorite,
            color = MassOrange,
            target = "300K",
            progress = (analyticsData.totalRevenue / 300000).toFloat()
        ),
        KPIMetric(
            title = "Clientes",
            value = "${(analyticsData.totalCustomers / 1000.0).roundToInt()}K",
            change = 22.1,
            icon = Icons.Default.Person,
            color = Color(0xFF9C27B0),
            target = "15K",
            progress = analyticsData.totalCustomers / 15000f
        ),
        KPIMetric(
            title = "Crecimiento",
            value = "+${analyticsData.growthRate.roundToInt()}%",
            change = analyticsData.growthRate,
            icon = Icons.Default.KeyboardArrowUp,
            color = if (analyticsData.growthRate > 0) SuccessColor else ErrorColor
        ),
        KPIMetric(
            title = "Eficiencia",
            value = "${analyticsData.efficiencyScore.roundToInt()}%",
            change = 5.2,
            icon = Icons.Default.ThumbUp,
            color = Color(0xFF2196F3),
            target = "95%",
            progress = (analyticsData.efficiencyScore / 100).toFloat()
        )
    )
}

private fun generateRecommendations(analyticsData: AnalyticsData): List<AnalyticsRecommendation> {
    return listOf(
        AnalyticsRecommendation(
            title = "Optimizar Sucursales Inactivas",
            description = "Se detectaron ${analyticsData.inactiveBranches} sucursales inactivas. Considera reactivarlas o reubicarlas en zonas de mayor demanda.",
            priority = RecommendationPriority.HIGH,
            icon = Icons.Default.Warning,
            impact = "+15% en ingresos potenciales"
        ),
        AnalyticsRecommendation(
            title = "Expandir Servicios Populares",
            description = "WiFi y estacionamiento tienen alta demanda. Implementar en más sucursales podría aumentar la satisfacción del cliente.",
            priority = RecommendationPriority.MEDIUM,
            icon = Icons.Default.Star,
            impact = "+8% en satisfacción del cliente"
        ),
        AnalyticsRecommendation(
            title = "Mejorar Eficiencia Operativa",
            description = "Algunas sucursales muestran eficiencia por debajo del 80%. Implementar procesos de mejora continua.",
            priority = RecommendationPriority.MEDIUM,
            icon = Icons.Default.ThumbUp,
            impact = "+12% en productividad"
        ),
        AnalyticsRecommendation(
            title = "Analizar Tendencias Regionales",
            description = "Lima Centro muestra el mejor rendimiento. Estudiar las mejores prácticas para replicar en otras regiones.",
            priority = RecommendationPriority.LOW,
            icon = Icons.Default.Info,
            impact = "+10% en rendimiento general"
        )
    )
}

private fun getRegionColor(region: String): Color {
    return when (region) {
        "Lima Centro" -> MassBlue
        "Miraflores" -> MassOrange
        "San Isidro" -> SuccessColor
        "Surco" -> Color(0xFF9C27B0)
        else -> Color.Gray
    }
}

private fun getRankColor(rank: Int): Color {
    return when (rank) {
        1 -> Color(0xFFFFD700) // Gold
        2 -> Color(0xFFC0C0C0) // Silver
        3 -> Color(0xFFCD7F32) // Bronze
        else -> MassBlue
    }
}

private fun getCategoryColor(category: String): Color {
    return when (category) {
        "Satisfacción" -> SuccessColor
        "Eficiencia" -> MassBlue
        "Ingresos" -> MassOrange
        "Clientes" -> Color(0xFF9C27B0)
        else -> Color.Gray
    }
}

private fun getTrendCategories(): List<String> {
    return listOf("Satisfacción", "Eficiencia", "Ingresos", "Clientes")
}

// Mock data generators for different time ranges
private fun generateTimeRangeSpecificData(timeRange: AnalyticsTimeRange): AnalyticsData {
    val baseData = generateMockAnalyticsData(timeRange)

    return when (timeRange) {
        AnalyticsTimeRange.TODAY -> baseData.copy(
            totalRevenue = baseData.totalRevenue * 0.03, // Daily revenue
            revenueByMonth = generateDailyRevenueData()
        )
        AnalyticsTimeRange.WEEK -> baseData.copy(
            totalRevenue = baseData.totalRevenue * 0.25, // Weekly revenue
            revenueByMonth = generateWeeklyRevenueData()
        )
        AnalyticsTimeRange.MONTH -> baseData
        AnalyticsTimeRange.QUARTER -> baseData.copy(
            totalRevenue = baseData.totalRevenue * 3, // Quarterly revenue
            revenueByMonth = generateQuarterlyRevenueData()
        )
        AnalyticsTimeRange.YEAR -> baseData.copy(
            totalRevenue = baseData.totalRevenue * 12, // Yearly revenue
            revenueByMonth = generateYearlyRevenueData()
        )
    }
}

private fun generateDailyRevenueData(): List<RevenueData> {
    return listOf(
        RevenueData("6:00", 1200.0, 1500.0, 5.2),
        RevenueData("9:00", 2800.0, 3000.0, 12.0),
        RevenueData("12:00", 4200.0, 4000.0, 14.3),
        RevenueData("15:00", 3800.0, 3500.0, 8.6),
        RevenueData("18:00", 3200.0, 3000.0, 6.7),
        RevenueData("21:00", 1800.0, 2000.0, -10.0)
    )
}

private fun generateWeeklyRevenueData(): List<RevenueData> {
    return listOf(
        RevenueData("Lun", 8500.0, 9000.0, 5.2),
        RevenueData("Mar", 9200.0, 9000.0, 8.3),
        RevenueData("Mié", 8800.0, 9000.0, -2.2),
        RevenueData("Jue", 9500.0, 9000.0, 7.9),
        RevenueData("Vie", 12000.0, 10000.0, 20.0),
        RevenueData("Sáb", 14500.0, 12000.0, 20.8),
        RevenueData("Dom", 11200.0, 11000.0, 1.8)
    )
}

private fun generateQuarterlyRevenueData(): List<RevenueData> {
    return listOf(
        RevenueData("Ene-Mar", 95000.0, 90000.0, 5.6),
        RevenueData("Abr-Jun", 105000.0, 100000.0, 10.5),
        RevenueData("Jul-Sep", 115000.0, 110000.0, 9.5)
    )
}

private fun generateYearlyRevenueData(): List<RevenueData> {
    return listOf(
        RevenueData("2020", 2800000.0, 2500000.0, 12.0),
        RevenueData("2021", 3200000.0, 3000000.0, 14.3),
        RevenueData("2022", 3600000.0, 3500000.0, 12.5),
        RevenueData("2023", 3900000.0, 3800000.0, 8.3),
        RevenueData("2024", 4200000.0, 4000000.0, 7.7)
    )
}

// Analytics export functionality
private fun exportAnalyticsData(analyticsData: AnalyticsData, format: ExportFormat) {
    when (format) {
        ExportFormat.PDF -> exportToPDF(analyticsData)
        ExportFormat.EXCEL -> exportToExcel(analyticsData)
        ExportFormat.CSV -> exportToCSV(analyticsData)
        ExportFormat.JSON -> exportToJSON(analyticsData)
    }
}

enum class ExportFormat {
    PDF, EXCEL, CSV, JSON
}

private fun exportToPDF(analyticsData: AnalyticsData) {
    // TODO: Implement PDF export
    println("Exporting to PDF...")
}

private fun exportToExcel(analyticsData: AnalyticsData) {
    // TODO: Implement Excel export
    println("Exporting to Excel...")
}

private fun exportToCSV(analyticsData: AnalyticsData) {
    // TODO: Implement CSV export
    println("Exporting to CSV...")
}

private fun exportToJSON(analyticsData: AnalyticsData) {
    // TODO: Implement JSON export
    println("Exporting to JSON...")
}

// Performance optimization utilities
private fun calculatePerformanceScore(branch: Branch, metrics: BranchMetrics): Double {
    val revenueScore = (metrics.revenue / metrics.targetRevenue) * 100
    val customerScore = (metrics.customers / metrics.targetCustomers) * 100
    val efficiencyScore = metrics.efficiency

    return (revenueScore + customerScore + efficiencyScore) / 3
}

data class BranchMetrics(
    val revenue: Double,
    val targetRevenue: Double,
    val customers: Int,
    val targetCustomers: Int,
    val efficiency: Double
)

// Real-time analytics updates
@Composable
private fun BranchAnalyticsRealTimeUpdates(
    onDataUpdate: (AnalyticsData) -> Unit
) {
    LaunchedEffect(Unit) {
        while (true) {
            delay(30000) // Update every 30 seconds
            // Simulate real-time data fetch
            val updatedData = generateMockAnalyticsData(AnalyticsTimeRange.TODAY)
            onDataUpdate(updatedData)
        }
    }
}

// Analytics caching system
object AnalyticsCache {
    private val cache = mutableMapOf<String, Pair<AnalyticsData, Long>>()
    private val cacheTimeout = 5 * 60 * 1000L // 5 minutes

    fun get(key: String): AnalyticsData? {
        val cached = cache[key]
        return if (cached != null && System.currentTimeMillis() - cached.second < cacheTimeout) {
            cached.first
        } else {
            cache.remove(key)
            null
        }
    }

    fun put(key: String, data: AnalyticsData) {
        cache[key] = Pair(data, System.currentTimeMillis())
    }

    fun clear() {
        cache.clear()
    }
}

// Analytics preferences
data class AnalyticsPreferences(
    val defaultTimeRange: AnalyticsTimeRange = AnalyticsTimeRange.MONTH,
    val autoRefresh: Boolean = true,
    val refreshInterval: Long = 30000L, // 30 seconds
    val showRecommendations: Boolean = true,
    val enableRealTimeUpdates: Boolean = true,
    val preferredChartType: ChartType = ChartType.LINE,
    val showDetailedMetrics: Boolean = true
)

// Analytics state management
@Composable
private fun rememberAnalyticsState(
    initialTimeRange: AnalyticsTimeRange = AnalyticsTimeRange.MONTH
): AnalyticsState {
    return remember {
        AnalyticsState(
            selectedTimeRange = initialTimeRange,
            isLoading = false,
            error = null,
            lastUpdated = System.currentTimeMillis()
        )
    }
}

data class AnalyticsState(
    val selectedTimeRange: AnalyticsTimeRange,
    val isLoading: Boolean,
    val error: String?,
    val lastUpdated: Long
)

// Analytics event tracking
sealed class AnalyticsEvent {
    object RefreshData : AnalyticsEvent()
    data class ChangeTimeRange(val timeRange: AnalyticsTimeRange) : AnalyticsEvent()
    data class SelectMetric(val metric: MetricType) : AnalyticsEvent()
    data class ExportData(val format: ExportFormat) : AnalyticsEvent()
    object ShowRecommendations : AnalyticsEvent()
    data class FilterByRegion(val region: String) : AnalyticsEvent()
}

// Analytics error handling
sealed class AnalyticsError {
    object NetworkError : AnalyticsError()
    object DataNotFound : AnalyticsError()
    object InvalidTimeRange : AnalyticsError()
    data class UnknownError(val message: String) : AnalyticsError()
}

// Analytics utility functions
fun formatCurrency(amount: Double): String {
    return "S/ ${String.format("%,.0f", amount)}"
}

fun formatPercentage(value: Double): String {
    return "${String.format("%.1f", value)}%"
}

fun formatNumber(number: Int): String {
    return when {
        number >= 1000000 -> "${String.format("%.1f", number / 1000000.0)}M"
        number >= 1000 -> "${String.format("%.1f", number / 1000.0)}K"
        else -> number.toString()
    }
}

fun calculateGrowthRate(current: Double, previous: Double): Double {
    return if (previous != 0.0) {
        ((current - previous) / previous) * 100
    } else {
        0.0
    }
}

fun getTimeRangeLabel(timeRange: AnalyticsTimeRange): String {
    val calendar = Calendar.getInstance()
    return when (timeRange) {
        AnalyticsTimeRange.TODAY -> {
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(calendar.time)
        }
        AnalyticsTimeRange.WEEK -> {
            calendar.add(Calendar.DAY_OF_YEAR, -7)
            val startDate = SimpleDateFormat("dd/MM", Locale.getDefault()).format(calendar.time)
            calendar.add(Calendar.DAY_OF_YEAR, 7)
            val endDate = SimpleDateFormat("dd/MM", Locale.getDefault()).format(calendar.time)
            "$startDate - $endDate"
        }
        AnalyticsTimeRange.MONTH -> {
            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.time)
        }
        AnalyticsTimeRange.QUARTER -> {
            val quarter = (calendar.get(Calendar.MONTH) / 3) + 1
            "Q$quarter ${calendar.get(Calendar.YEAR)}"
        }
        AnalyticsTimeRange.YEAR -> {
            calendar.get(Calendar.YEAR).toString()
        }
    }
}

// Analytics validation
fun validateAnalyticsData(data: AnalyticsData): List<String> {
    val errors = mutableListOf<String>()

    if (data.totalBranches < 0) {
        errors.add("Total de sucursales no puede ser negativo")
    }

    if (data.activeBranches > data.totalBranches) {
        errors.add("Sucursales activas no puede ser mayor al total")
    }

    if (data.totalRevenue < 0) {
        errors.add("Ingresos no pueden ser negativos")
    }

    if (data.totalCustomers < 0) {
        errors.add("Total de clientes no puede ser negativo")
    }

    if (data.efficiencyScore < 0 || data.efficiencyScore > 100) {
        errors.add("Puntuación de eficiencia debe estar entre 0 y 100")
    }

    return errors
}

// Analytics comparison utilities
fun compareAnalyticsData(current: AnalyticsData, previous: AnalyticsData): AnalyticsComparison {
    return AnalyticsComparison(
        branchesGrowth = calculateGrowthRate(current.totalBranches.toDouble(), previous.totalBranches.toDouble()),
        revenueGrowth = calculateGrowthRate(current.totalRevenue, previous.totalRevenue),
        customersGrowth = calculateGrowthRate(current.totalCustomers.toDouble(), previous.totalCustomers.toDouble()),
        efficiencyChange = current.efficiencyScore - previous.efficiencyScore
    )
}

data class AnalyticsComparison(
    val branchesGrowth: Double,
    val revenueGrowth: Double,
    val customersGrowth: Double,
    val efficiencyChange: Double
)

// Analytics insights generator
fun generateInsights(data: AnalyticsData): List<AnalyticsInsight> {
    val insights = mutableListOf<AnalyticsInsight>()

    // Revenue insights
    if (data.totalRevenue > 250000) {
        insights.add(
            AnalyticsInsight(
                title = "Excelente Rendimiento Financiero",
                description = "Los ingresos superan las expectativas del período",
                type = InsightType.POSITIVE,
                icon = Icons.Default.KeyboardArrowUp
            )
        )
    }

    // Efficiency insights
    if (data.efficiencyScore > 90) {
        insights.add(
            AnalyticsInsight(
                title = "Alta Eficiencia Operativa",
                description = "Las sucursales mantienen excelentes niveles de eficiencia",
                type = InsightType.POSITIVE,
                icon = Icons.Default.ThumbUp
            )
        )
    }

    // Growth insights
    if (data.growthRate > 10) {
        insights.add(
            AnalyticsInsight(
                title = "Crecimiento Acelerado",
                description = "El crecimiento supera el 10% en el período analizado",
                type = InsightType.POSITIVE,
                icon = Icons.Default.Star
            )
        )
    }

    // Warning insights
    if (data.inactiveBranches > data.totalBranches * 0.2) {
        insights.add(
            AnalyticsInsight(
                title = "Atención: Sucursales Inactivas",
                description = "Más del 20% de sucursales están inactivas",
                type = InsightType.WARNING,
                icon = Icons.Default.Warning
            )
        )
    }

    return insights
}

data class AnalyticsInsight(
    val title: String,
    val description: String,
    val type: InsightType,
    val icon: ImageVector
)

enum class InsightType {
    POSITIVE, WARNING, NEGATIVE, NEUTRAL
}

// Performance benchmarking
fun benchmarkPerformance(data: AnalyticsData): BenchmarkResult {
    val industryAverage = BenchmarkData(
        averageRevenue = 200000.0,
        averageEfficiency = 75.0,
        averageGrowth = 8.0,
        averageCustomers = 10000
    )

    return BenchmarkResult(
        revenueVsIndustry = (data.totalRevenue / industryAverage.averageRevenue - 1) * 100,
        efficiencyVsIndustry = data.efficiencyScore - industryAverage.averageEfficiency,
        growthVsIndustry = data.growthRate - industryAverage.averageGrowth,
        customersVsIndustry = (data.totalCustomers / industryAverage.averageCustomers.toDouble() - 1) * 100
    )
}

data class BenchmarkData(
    val averageRevenue: Double,
    val averageEfficiency: Double,
    val averageGrowth: Double,
    val averageCustomers: Int
)

data class BenchmarkResult(
    val revenueVsIndustry: Double,
    val efficiencyVsIndustry: Double,
    val growthVsIndustry: Double,
    val customersVsIndustry: Double
)