package com.mass.marketplace.domain.usecase.branch

import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.repository.BranchRepository

class GetBranchByIdUseCase(
    private val branchRepository: BranchRepository
) {
    suspend operator fun invoke(id: Int): Result<Branch> {
        if (id <= 0) {
            return Result.failure(Exception("El ID de la sucursal debe ser mayor que cero."))
        }

        return branchRepository.getBranchById(id)
    }
}