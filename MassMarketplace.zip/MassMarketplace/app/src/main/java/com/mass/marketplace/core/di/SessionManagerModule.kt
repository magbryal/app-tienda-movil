package com.mass.marketplace.core.di

import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.data.repository.AuthRepositoryImpl
import com.mass.marketplace.domain.repository.AuthRepository
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

val sessionManagerModule = module {
    single { SessionManager(androidContext()) }
}
