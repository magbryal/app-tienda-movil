package com.mass.marketplace.domain.usecase.branch

import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.repository.BranchRepository

class GetBranchesUseCase(
    private val branchRepository: BranchRepository
) {
    suspend operator fun invoke(): Result<List<Branch>> {
        return branchRepository.getBranches()
    }
}