package com.mass.marketplace.presentation.ui.utils

import android.annotation.SuppressLint
import java.text.NumberFormat
import java.util.Locale

object CurrencyUtils {
    @SuppressLint("DefaultLocale")
    fun formatPEN(amount: Double): String {
        return "S/ ${String.format("%.2f", amount)}"
    }

    @SuppressLint("DefaultLocale")
    fun formatPENCompact(amount: Double): String {
        return when {
            amount >= 1000000 -> "S/ ${String.format("%.1f", amount / 1000000)}M"
            amount >= 1000 -> "S/ ${String.format("%.1f", amount / 1000)}K"
            else -> "S/ ${String.format("%.2f", amount)}"
        }
    }

    fun formatPENWithLocale(amount: Double): String {
        val format = NumberFormat.getCurrencyInstance(Locale("es", "PE"))
        return format.format(amount).replace("PEN", "S/")
    }
}
