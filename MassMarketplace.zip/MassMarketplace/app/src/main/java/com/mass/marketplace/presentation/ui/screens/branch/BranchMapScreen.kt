package com.mass.marketplace.presentation.ui.screens.branch

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.mass.marketplace.core.viewmodel.BranchViewModel
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.LocationManager
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import androidx.core.net.toUri

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun BranchMapScreen(
    onNavigateBack: () -> Unit,
    onBranchSelected: (Branch) -> Unit,
    onNavigateToDetail: (Branch) -> Unit,
    viewModel: BranchViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    var mapView by remember { mutableStateOf<MapView?>(null) }
    var selectedBranch by remember { mutableStateOf<Branch?>(null) }
    var userLocation by remember { mutableStateOf<GeoPoint?>(null) }
    var showBranchList by remember { mutableStateOf(false) }
    var mapType by remember { mutableStateOf(MapType.NORMAL) }

    val locationManager = remember { LocationManager(context) }

    // Permisos de ubicación
    val locationPermissions = rememberMultiplePermissionsState(
        permissions = listOf(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    LaunchedEffect(Unit) {
        // Configurar osmdroid
        Configuration.getInstance().load(context, context.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))

        // Cargar sucursales
        viewModel.getBranches()

        // Solicitar permisos si no los tiene
        if (!locationPermissions.allPermissionsGranted) {
            locationPermissions.launchMultiplePermissionRequest()
        }
    }

    // Obtener ubicación cuando se concedan los permisos
    LaunchedEffect(locationPermissions.allPermissionsGranted) {
        if (locationPermissions.allPermissionsGranted) {
            scope.launch {
                val location = locationManager.getCurrentLocation()
                location?.let {
                    userLocation = GeoPoint(it.latitude, it.longitude)
                    viewModel.setUserLocation(it.latitude, it.longitude)
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Mapa OpenStreetMap
        AndroidView(
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(getTileSource(mapType))
                    setMultiTouchControls(true)
                    setBuiltInZoomControls(false)

                    // Configurar ubicación inicial (Lima, Perú)
                    controller.setZoom(12.0)
                    controller.setCenter(GeoPoint(-12.0464, -77.0428))

                    mapView = this
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { map ->
                updateMapOverlays(
                    map = map,
                    context = context,
                    branches = uiState.branches,
                    selectedBranch = selectedBranch,
                    userLocation = userLocation,
                    hasLocationPermission = locationPermissions.allPermissionsGranted,
                    onBranchSelected = { branch ->
                        selectedBranch = branch
                        onBranchSelected(branch)
                    }
                )
            }
        )

        // Controles superiores
        BranchMapTopControls(
            onNavigateBack = onNavigateBack,
            onToggleBranchList = { showBranchList = !showBranchList },
            showBranchList = showBranchList,
            mapType = mapType,
            onMapTypeChange = { newType ->
                mapType = newType
                mapView?.setTileSource(getTileSource(newType))
            },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.systemBars)
        )

        // Controles laterales
        BranchMapSideControls(
            onZoomIn = { mapView?.controller?.zoomIn() },
            onZoomOut = { mapView?.controller?.zoomOut() },
            onMyLocation = {
                userLocation?.let { location ->
                    mapView?.controller?.animateTo(location)
                }
            },
            onFitAllBranches = {
                if (uiState.branches.isNotEmpty()) {
                    val bounds = calculateBounds(uiState.branches)
                    mapView?.zoomToBoundingBox(bounds, true)
                }
            },
            hasUserLocation = userLocation != null,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(16.dp)
        )

        // Lista de sucursales (overlay)
        AnimatedVisibility(
            visible = showBranchList,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            BranchMapList(
                branches = uiState.branches,
                selectedBranch = selectedBranch,
                userLocation = userLocation?.let { it.latitude to it.longitude },
                onBranchSelected = { branch ->
                    selectedBranch = branch
                    onBranchSelected(branch)
                    // Centrar mapa en la sucursal
                    mapView?.controller?.animateTo(GeoPoint(branch.latitude, branch.longitude))
                },
                onNavigateToDetail = onNavigateToDetail,
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.4f)
            )
        }

        // Card de sucursal seleccionada
        selectedBranch?.let { branch ->
            AnimatedVisibility(
                visible = !showBranchList,
                enter = slideInVertically { it },
                exit = slideOutVertically { it },
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                BranchMapSelectedCard(
                    branch = branch,
                    userLocation = userLocation?.let { it.latitude to it.longitude },
                    onNavigateToDetail = { onNavigateToDetail(branch) },
                    onGetDirections = {
                        openDirectionsIntent(context, branch)
                    },
                    onClose = { selectedBranch = null },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                )
            }
        }

        // Solicitud de permisos
        if (!locationPermissions.allPermissionsGranted) {
            BranchMapPermissionRequest(
                onRequestPermissions = {
                    locationPermissions.launchMultiplePermissionRequest()
                },
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Indicador de carga
        if (uiState.isLoading) {
            BranchMapLoadingIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        }
    }
}

// Enum para tipos de mapa
enum class MapType(val displayName: String) {
    NORMAL("Normal"),
    //SATELLITE("Satélite"),
    //TERRAIN("Terreno")
}

// Función para obtener el tile source según el tipo de mapa
private fun getTileSource(mapType: MapType) = when (mapType) {
    MapType.NORMAL -> TileSourceFactory.MAPNIK
    //MapType.SATELLITE -> TileSourceFactory.USGS_SAT
    //MapType.TERRAIN -> TileSourceFactory.USGS_TOPO
}

// Función para actualizar overlays del mapa
@SuppressLint("UseCompatLoadingForDrawables")
private fun updateMapOverlays(
    map: MapView,
    context: Context,
    branches: List<Branch>,
    selectedBranch: Branch?,
    userLocation: GeoPoint?,
    hasLocationPermission: Boolean,
    onBranchSelected: (Branch) -> Unit
) {
    // Limpiar overlays anteriores
    map.overlays.clear()

    // Agregar overlay de ubicación del usuario - CÓDIGO CORREGIDO
    if (hasLocationPermission) {
        val myLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(context), map).apply {
            enableMyLocation()
            enableFollowLocation()
            setDrawAccuracyEnabled(true)

            // Si tenemos la ubicación del usuario, centrar ahí
            userLocation?.let { location ->
                runOnFirstFix {
                    // Este callback se ejecuta cuando se obtiene la primera ubicación
                    map.post {
                        map.controller.animateTo(location)
                    }
                }

                //  Usar el LocationProvider para establecer la ubicación
                val locationProvider = GpsMyLocationProvider(context)
                locationProvider.startLocationProvider { loc, source ->
                    // Callback cuando se obtiene la ubicación
                }
            }
        }

        // Agregar el overlay al mapa
        map.overlays.add(myLocationOverlay)

        // ALTERNATIVA: Si quieres forzar una ubicación específica,
        // puedes usar un marcador personalizado en lugar del overlay automático
        userLocation?.let { location ->
            val userMarker = Marker(map).apply {
                position = location
                title = "Mi ubicación"
                icon = context.getDrawable(android.R.drawable.ic_menu_mylocation)?.apply {
                    setTint(android.graphics.Color.BLUE)
                }
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            }
            map.overlays.add(userMarker)
        }
    }

    // Resto del código permanece igual...
    // Agregar marcadores de sucursales
    branches.forEach { branch ->
        val marker = Marker(map).apply {
            position = GeoPoint(branch.latitude, branch.longitude)
            title = branch.name
            snippet = branch.address

            // Personalizar ícono según estado
            icon = if (branch.isActive) {
                context.getDrawable(android.R.drawable.ic_dialog_map)?.apply {
                    setTint(SuccessColor.toArgb())
                }
            } else {
                context.getDrawable(android.R.drawable.ic_dialog_map)?.apply {
                    setTint(Color.Gray.toArgb())
                }
            }

            setOnMarkerClickListener { _, _ ->
                onBranchSelected(branch)
                true
            }
        }
        map.overlays.add(marker)
    }

    // Agregar ruta desde ubicación del usuario a sucursal seleccionada
    selectedBranch?.let { branch ->
        userLocation?.let { userLoc ->
            val routeLine = Polyline().apply {
                addPoint(userLoc)
                addPoint(GeoPoint(branch.latitude, branch.longitude))
                color = MassOrange.toArgb()
                width = 8f
            }
            map.overlays.add(routeLine)
        }
    }

    // Forzar invalidación del mapa
    map.invalidate()
}

// Función para calcular bounds de las sucursales
private fun calculateBounds(branches: List<Branch>): BoundingBox {
    if (branches.isEmpty()) {
        return BoundingBox(-12.0, -77.0, -12.1, -77.1) // Lima por defecto
    }

    val latitudes = branches.map { it.latitude }
    val longitudes = branches.map { it.longitude }

    return BoundingBox(
        latitudes.maxOrNull() ?: -12.0,
        longitudes.maxOrNull() ?: -77.0,
        latitudes.minOrNull() ?: -12.1,
        longitudes.minOrNull() ?: -77.1
    )
}

// Función para abrir direcciones en Google Maps o app de mapas
@SuppressLint("QueryPermissionsNeeded")
private fun openDirectionsIntent(context: Context, branch: Branch) {
    val uri =
        "geo:${branch.latitude},${branch.longitude}?q=${branch.latitude},${branch.longitude}(${branch.name})".toUri()
    val intent = Intent(Intent.ACTION_VIEW, uri)

    // Intentar abrir con Google Maps primero
    intent.setPackage("com.google.android.apps.maps")

    if (intent.resolveActivity(context.packageManager) != null) {
        context.startActivity(intent)
    } else {
        // Si no tiene Google Maps, usar cualquier app de mapas
        intent.setPackage(null)
        context.startActivity(Intent.createChooser(intent, "Abrir con"))
    }
}

@Composable
private fun BranchMapTopControls(
    onNavigateBack: () -> Unit,
    onToggleBranchList: () -> Unit,
    showBranchList: Boolean,
    mapType: MapType,
    onMapTypeChange: (MapType) -> Unit,
    modifier: Modifier = Modifier
) {
    var showMapTypeMenu by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Botón de volver
        BranchMapControlButton(
            icon = Icons.Default.ArrowBack,
            contentDescription = "Volver",
            onClick = onNavigateBack,
            tint = Color.White
        )

        // Controles de la derecha
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Tipo de mapa
//            BranchMapControlButton(
//                icon = Icons.Default.Menu,
//                contentDescription = "Tipo de mapa",
//                onClick = { showMapTypeMenu = true },
//                tint = Color.White
//            )

            // Lista de sucursales
            BranchMapControlButton(
                icon = if (showBranchList) Icons.Default.KeyboardArrowUp else Icons.AutoMirrored.Filled.List,
                contentDescription = "Lista",
                onClick = onToggleBranchList,
                tint = if (showBranchList) MassOrange else Color.White
            )
        }
    }

    // Menú de tipo de mapa
    DropdownMenu(
        expanded = showMapTypeMenu,
        onDismissRequest = { showMapTypeMenu = false }
    ) {
        MapType.entries.forEach { type ->
        DropdownMenuItem(
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (mapType == type) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Seleccionado",
                                tint = MassOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(type.displayName)
                    }
                },
                onClick = {
                    onMapTypeChange(type)
                    showMapTypeMenu = false
                }
            )
        }
    }
}

@Composable
private fun BranchMapSideControls(
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    onMyLocation: () -> Unit,
    onFitAllBranches: () -> Unit,
    hasUserLocation: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Zoom in
        BranchMapControlButton(
            icon = Icons.Default.KeyboardArrowUp,
            contentDescription = "Acercar",
            onClick = onZoomIn
        )

        // Zoom out
        BranchMapControlButton(
            icon = Icons.Default.ArrowDropDown,
            contentDescription = "Alejar",
            onClick = onZoomOut
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Mi ubicación
        if (hasUserLocation) {
            BranchMapControlButton(
                icon = Icons.Default.Place,
                contentDescription = "Mi ubicación",
                onClick = onMyLocation,
                tint = MassBlue
            )
        }

        // Ver todas las sucursales
        BranchMapControlButton(
            icon = Icons.Default.FavoriteBorder,
            contentDescription = "Ver todas",
            onClick = onFitAllBranches,
            tint = MassOrange
        )
    }
}

@Composable
private fun BranchMapControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    tint: Color = Color.White
) {
    GlassmorphicCard(
        modifier = Modifier.size(48.dp),
        alpha = 0.9f,
        cornerRadius = 24.dp,
        onClick = onClick
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.7f),
                            Color.Black.copy(alpha = 0.5f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
private fun BranchMapList(
    branches: List<Branch>,
    selectedBranch: Branch?,
    userLocation: Pair<Double, Double>?,
    onBranchSelected: (Branch) -> Unit,
    onNavigateToDetail: (Branch) -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier,
        alpha = 0.95f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.9f),
                            Color.White.copy(alpha = 0.95f)
                        )
                    )
                )
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "📍 Sucursales (${branches.size})",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                if (userLocation != null) {
                    Text(
                        text = "Ordenadas por distancia",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.Gray
                        )
                    )
                }
            }

            // Lista de sucursales
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = branches.sortedBy { branch ->
                        userLocation?.let { (lat, lng) ->
                            branch.distanceTo(lat, lng)
                        } ?: 0.0
                    },
                    key = { it.id }
                ) { branch ->
                    BranchMapListItem(
                        branch = branch,
                        isSelected = selectedBranch?.id == branch.id,
                        userLocation = userLocation,
                        onBranchSelected = { onBranchSelected(branch) },
                        onNavigateToDetail = { onNavigateToDetail(branch) }
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchMapListItem(
    branch: Branch,
    isSelected: Boolean,
    userLocation: Pair<Double, Double>?,
    onBranchSelected: () -> Unit,
    onNavigateToDetail: () -> Unit
) {
    val distance = userLocation?.let { (lat, lng) ->
        branch.distanceTo(lat, lng)
    }

    GlassmorphicCard(
        alpha = if (isSelected) 0.3f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onBranchSelected
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = if (isSelected) {
                        Brush.horizontalGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.2f),
                                Color.Transparent
                            )
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                )
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ícono de sucursal
            GlassmorphicCard(
                modifier = Modifier.size(40.dp),
                alpha = 0.3f,
                cornerRadius = 20.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.radialGradient(
                                colors = if (branch.isActive) {
                                    listOf(SuccessColor, SuccessColor.copy(alpha = 0.7f))
                                } else {
                                    listOf(Color.Gray, Color.Gray.copy(alpha = 0.7f))
                                }
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Sucursal",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Información de la sucursal
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = branch.name,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) MassOrange else MassBlue
                    )
                )

                Text(
                    text = branch.address,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    ),
                    maxLines = 1
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (branch.isActive) Icons.Default.CheckCircle else Icons.Default.Close,
                        contentDescription = if (branch.isActive) "Abierta" else "Cerrada",
                        tint = if (branch.isActive) SuccessColor else ErrorColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (branch.isActive) "Abierta" else "Cerrada",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (branch.isActive) SuccessColor else ErrorColor
                        )
                    )
                }
            }

            // Distancia y botón de detalles
            Column(
                horizontalAlignment = Alignment.End
            ) {
                if (distance != null) {
                    GlassmorphicCard(
                        alpha = 0.2f,
                        cornerRadius = 8.dp
                    ) {
                        Text(
                            text = "${String.format("%.1f", distance)} km",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MassOrange,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                TextButton(
                    onClick = onNavigateToDetail,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MassBlue
                    )
                ) {
                    Text(
                        text = "Ver detalles",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun BranchMapSelectedCard(
    branch: Branch,
    userLocation: Pair<Double, Double>?,
    onNavigateToDetail: () -> Unit,
    onGetDirections: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val distance = userLocation?.let { (lat, lng) ->
        branch.distanceTo(lat, lng)
    }

    GlassmorphicCard(
        modifier = modifier,
        alpha = 0.95f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.9f),
                            Color.White.copy(alpha = 0.95f)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            // Header con botón de cerrar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(40.dp),
                        alpha = 0.3f,
                        cornerRadius = 20.dp
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    brush = Brush.radialGradient(
                                        colors = if (branch.isActive) {
                                            listOf(SuccessColor, SuccessColor.copy(alpha = 0.7f))
                                        } else {
                                            listOf(Color.Gray, Color.Gray.copy(alpha = 0.7f))
                                        }
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Sucursal",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = branch.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MassBlue
                            )
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (branch.isActive) Icons.Default.CheckCircle else Icons.Default.Close,
                                contentDescription = if (branch.isActive) "Abierta" else "Cerrada",
                                tint = if (branch.isActive) SuccessColor else ErrorColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (branch.isActive) "Abierta" else "Cerrada",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (branch.isActive) SuccessColor else ErrorColor
                                )
                            )
                        }
                    }
                }

                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cerrar",
                        tint = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Información de la sucursal
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Dirección
                Row(
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Dirección",
                        tint = MassOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = branch.address,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Distancia
                if (distance != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Done,
                            contentDescription = "Distancia",
                            tint = MassBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${String.format("%.1f", distance)} km de distancia",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }

                // Teléfono
                if (branch.phone.isNotEmpty()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Teléfono",
                            tint = SuccessColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = branch.phone,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }

                // Horarios
                if (branch.schedule.isNotEmpty()) {
                    Row(
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Done,
                            contentDescription = "Horarios",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = branch.schedule,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Botones de acción
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Botón de direcciones
                Button(
                    onClick = onGetDirections,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MassOrange,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = "Direcciones",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Cómo llegar")
                }

                // Botón de detalles
                OutlinedButton(
                    onClick = onNavigateToDetail,
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, MassBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Detalles",
                        tint = MassBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Ver detalles",
                        color = MassBlue
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchMapPermissionRequest(
    onRequestPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        alpha = 0.95f,
        cornerRadius = 20.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.9f),
                            Color.White.copy(alpha = 0.95f)
                        )
                    )
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "Ubicación",
                tint = MassOrange,
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Permiso de ubicación requerido",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                ),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Para mostrarte las sucursales más cercanas y calcular distancias, necesitamos acceso a tu ubicación.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.Gray
                ),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onRequestPermissions,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MassOrange,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Permitir ubicación",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Permitir ubicación")
            }
        }
    }
}

@Composable
private fun BranchMapLoadingIndicator(
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier,
        alpha = 0.9f,
        cornerRadius = 16.dp
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.9f),
                            Color.White.copy(alpha = 0.7f)
                        )
                    )
                )
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    color = MassOrange,
                    modifier = Modifier.size(32.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Cargando sucursales...",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MassBlue
                    )
                )
            }
        }
    }
}

// Extensión para calcular distancia en Branch
fun Branch.distanceTo(latitude: Double, longitude: Double): Double {
    val results = FloatArray(1)
    android.location.Location.distanceBetween(
        this.latitude, this.longitude,
        latitude, longitude,
        results
    )
    return (results[0] / 1000.0) // Convertir a kilómetros
}

