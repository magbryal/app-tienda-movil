package com.mass.marketplace.data.model.response

import com.mass.marketplace.presentation.ui.screens.home.Category
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color

data class CategoryResponse(
    val category_id: Int,
    val name: String,
    val description: String?,
    val image: String?,
    val product_count: Int = 0,
    val is_active: Int = 1
)

fun CategoryResponse.toDomain(): Category {
    return Category(
        id = category_id.toString(),
        name = name,
        description = description ?: "",
        imageUrl = image ?: "",
        productCount = product_count,
        isActive = is_active == 1,
        icon = when (name.lowercase()) {
            "electrónicos", "electronics" -> Icons.Default.Phone
            "ropa", "fashion" -> Icons.Default.ShoppingCart
            "comida", "food" -> Icons.Default.Favorite
            "hogar", "home" -> Icons.Default.Home
            "deportes", "sports" -> Icons.Default.Face
            else -> Icons.Default.Star
        },
        color = when (name.lowercase()) {
            "electrónicos", "electronics" -> listOf(Color(0xFF2196F3), Color(0xFF21CBF3))
            "ropa", "fashion" -> listOf(Color(0xFFE91E63), Color(0xFFF06292))
            "comida", "food" -> listOf(Color(0xFFFF9800), Color(0xFFFFB74D))
            "hogar", "home" -> listOf(Color(0xFF4CAF50), Color(0xFF81C784))
            "deportes", "sports" -> listOf(Color(0xFF9C27B0), Color(0xFFBA68C8))
            else -> listOf(Color(0xFF607D8B), Color(0xFF90A4AE))
        }
    )
}
