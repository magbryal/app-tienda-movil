package com.mass.marketplace.presentation.ui.screens.search

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.presentation.ui.components.cards.ProductCardHorizontal
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.screens.home.Product
import com.mass.marketplace.presentation.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }
    var searchResults by remember { mutableStateOf<List<Product>>(emptyList()) }
    var recentSearches by remember { mutableStateOf(listOf("iPhone", "Samsung", "Nike", "Pizza")) }
    var popularSearches by remember { mutableStateOf(listOf("Ofertas", "Electrónicos", "Ropa", "Comida")) }
    var isVisible by remember { mutableStateOf(false) }

    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(key1 = true) {
        isVisible = true
        focusRequester.requestFocus()
    }

    // Simulate search
    LaunchedEffect(searchQuery) {
        if (searchQuery.isNotEmpty()) {
            isSearching = true
            kotlinx.coroutines.delay(500) // Simulate network delay
            searchResults = simulateSearch(searchQuery)
            isSearching = false
        } else {
            searchResults = emptyList()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.05f),
                        Color.White,
                        MassBlue.copy(alpha = 0.03f)
                    )
                )
            )
    ) {
        // Search Header
        SearchHeader(
            searchQuery = searchQuery,
            onSearchQueryChange = { searchQuery = it },
            onNavigateBack = onNavigateBack,
            focusRequester = focusRequester,
            keyboardController = keyboardController,
            isVisible = isVisible
        )

        // Content
        if (searchQuery.isEmpty()) {
            // Empty state with suggestions
            SearchEmptyState(
                recentSearches = recentSearches,
                popularSearches = popularSearches,
                onSearchClick = { searchQuery = it },
                onClearRecent = { recentSearches = emptyList() },
                isVisible = isVisible
            )
        } else {
            // Search results
            SearchResults(
                query = searchQuery,
                results = searchResults,
                isSearching = isSearching,
                isVisible = isVisible
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchHeader(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onNavigateBack: () -> Unit,
    focusRequester: FocusRequester,
    keyboardController: androidx.compose.ui.platform.SoftwareKeyboardController?,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
            .background(Color.White)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Back button
        IconButton(
            onClick = onNavigateBack,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MassOrange.copy(alpha = 0.1f))
        ) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Volver",
                tint = MassOrange
            )
        }

        // Search field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
                .weight(1f)
                .focusRequester(focusRequester),
            placeholder = {
                Text(
                    text = "¿Qué estás buscando?",
                    color = Color.Gray
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Buscar",
                    tint = MassOrange
                )
            },
            trailingIcon = if (searchQuery.isNotEmpty()) {
                {
                    IconButton(
                        onClick = { onSearchQueryChange("") }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Limpiar",
                            tint = Color.Gray
                        )
                    }
                }
            } else null,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MassOrange,
                unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f)
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(
                onSearch = {
                    keyboardController?.hide()
                }
            ),
            singleLine = true
        )
    }
}

@Composable
private fun SearchEmptyState(
    recentSearches: List<String>,
    popularSearches: List<String>,
    onSearchClick: (String) -> Unit,
    onClearRecent: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .alpha(alpha),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Recent searches
        if (recentSearches.isNotEmpty()) {
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Búsquedas recientes",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MassBlue
                            )
                        )

                        TextButton(
                            onClick = onClearRecent
                        ) {
                            Text(
                                text = "Limpiar",
                                color = MassOrange
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    recentSearches.forEach { search ->
                        SearchSuggestionItem(
                            text = search,
                            icon = Icons.Default.AccountCircle,
                            onClick = { onSearchClick(search) }
                        )
                    }
                }
            }
        }

        // Popular searches
        item {
            Column {
                Text(
                    text = "Búsquedas populares",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(popularSearches) { search ->
                        SuggestionChip(
                            onClick = { onSearchClick(search) },
                            label = { Text(search) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = MassOrange.copy(alpha = 0.1f),
                                labelColor = MassOrange
                            )
                        )
                    }
                }
            }
        }

        // Categories quick access
        item {
            Column {
                Text(
                    text = "Explorar categorías",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                val categories = listOf(
                    "Electrónicos" to Icons.Default.Phone,
                    "Moda" to Icons.Default.ShoppingCart,
                    "Comida" to Icons.Default.LocationOn,
                    "Hogar" to Icons.Default.Home
                )

                categories.forEach { (category, icon) ->
                    SearchSuggestionItem(
                        text = category,
                        icon = icon,
                        onClick = { onSearchClick(category) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchResults(
    query: String,
    results: List<Product>,
    isSearching: Boolean,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .alpha(alpha)
    ) {
        // Results header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isSearching) "Buscando..." else "Resultados para \"$query\"",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            if (!isSearching && results.isNotEmpty()) {
                Text(
                    text = "${results.size} productos",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }
        }

        // Loading or results
        if (isSearching) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(
                        color = MassOrange,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Buscando productos...",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        } else if (results.isEmpty()) {
            // No results
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🔍",
                        fontSize = 64.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No encontramos resultados",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassBlue
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Intenta con otras palabras clave",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        } else {
            // Results list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(results) { product ->
                    ProductCardHorizontal(
                        product = product,
                        onClick = { /* Navigate to product detail */ }
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchSuggestionItem(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )

        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Buscar",
            tint = Color.Gray.copy(alpha = 0.6f),
            modifier = Modifier.size(16.dp)
        )
    }
}

private fun simulateSearch(query: String): List<Product> {
    val allProducts = listOf(
        Product(1, "iPhone 15 Pro", 1199.99, 1299.99, "", "TechStore", 4.8f, "0.5 km"),
        Product(2, "Samsung Galaxy S24", 849.99, null, "", "MobileWorld", 4.6f, "1.2 km"),
        Product(3, "Nike Air Max", 129.99, 159.99, "", "SportsFashion", 4.5f, "0.7 km"),
        Product(4, "Pizza Margherita", 12.99, null, "", "Pizzería Luigi", 4.7f, "0.3 km"),
        Product(5, "MacBook Air M2", 1299.99, null, "", "AppleCenter", 4.9f, "2.1 km"),
        Product(6, "Levi's Jeans", 79.99, null, "", "DenimStore", 4.3f, "1.1 km")
    )

    return allProducts.filter { product ->
        product.name.contains(query, ignoreCase = true) ||
                product.store.contains(query, ignoreCase = true)
    }
}