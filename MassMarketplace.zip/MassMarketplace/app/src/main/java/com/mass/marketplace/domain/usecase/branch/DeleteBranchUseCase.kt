package com.mass.marketplace.domain.usecase.branch

import com.mass.marketplace.domain.repository.BranchRepository

class DeleteBranchUseCase(
    private val branchRepository: BranchRepository
) {
    suspend operator fun invoke(id: Int): Result<String> {
        if (id <= 0) {
            return Result.failure(Exception("El ID de la sucursal debe ser mayor que cero."))
        }

        return branchRepository.deleteBranch(id)
    }
}