package com.mass.marketplace.core.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.domain.usecase.product.GetProductsUseCase
import com.mass.marketplace.presentation.ui.screens.home.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProductsUiState(
    val isLoading: Boolean = false,
    val products: List<Product> = emptyList(),
    val filteredProducts: List<Product> = emptyList(),
    val errorMessage: String? = null,
    val currentCategory: String = "all"
)

class ProductsViewModel(
    private val getProductsUseCase: GetProductsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProductsUiState())
    val uiState: StateFlow<ProductsUiState> = _uiState.asStateFlow()

    fun loadProducts(category: String = "all") {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                errorMessage = null,
                currentCategory = category
            )

            getProductsUseCase().fold(
                onSuccess = { products ->
                    val filteredProducts = if (category == "all") {
                        products
                    } else {
                        // Filtrar productos por categoría
                        products.filter { product ->
                            product.categoryId.toString() == category ||
                                    getCategoryName(product.categoryId).equals(category, ignoreCase = true)
                        }
                    }

                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        products = products,
                        filteredProducts = filteredProducts
                    )
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Error al cargar productos"
                    )
                }
            )
        }
    }

    fun retryLoadProducts() {
        loadProducts(_uiState.value.currentCategory)
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    private fun getCategoryName(categoryId: Int): String {
        return when (categoryId) {
            1 -> "electronics"
            2 -> "fashion"
            3 -> "food"
            4 -> "home"
            5 -> "sports"
            else -> "other"
        }
    }
}
