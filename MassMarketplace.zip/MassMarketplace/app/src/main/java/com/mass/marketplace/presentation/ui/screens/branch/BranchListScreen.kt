package com.mass.marketplace.presentation.ui.screens.branch

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mass.marketplace.core.viewmodel.BranchViewModel
import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.presentation.ui.components.branch.BranchCard
import com.mass.marketplace.presentation.ui.components.branch.BranchEmptyState
import com.mass.marketplace.presentation.ui.components.branch.BranchErrorSnackbar
import com.mass.marketplace.presentation.ui.components.branch.BranchGridCard
import com.mass.marketplace.presentation.ui.components.branch.BranchLoadingState
import com.mass.marketplace.presentation.ui.components.branch.BranchNearbyCard
import com.mass.marketplace.presentation.ui.components.branch.BranchSuccessSnackbar
import com.mass.marketplace.presentation.ui.components.branch.BranchFiltersBottomSheet
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.LocationManager
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import org.koin.androidx.compose.koinViewModel

enum class BranchViewMode {
    LIST, GRID, MAP
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchListScreen(
    onNavigateBack: () -> Unit,
    onNavigateToDetail: (Branch) -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToCreate: () -> Unit,
    viewModel: BranchViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var isVisible by remember { mutableStateOf(false) }
    var viewMode by remember { mutableStateOf(BranchViewMode.LIST) }
    var searchQuery by remember { mutableStateOf("") }
    var showFilters by remember { mutableStateOf(false) }

    // Estados para ubicación
    var isRequestingLocation by remember { mutableStateOf(false) }
    var locationPermissionGranted by remember { mutableStateOf(false) }

    val locationManager = remember { LocationManager(context) }

    // Función para obtener ubicación - UNA SOLA DECLARACIÓN
    val getCurrentUserLocation: suspend () -> Unit = {
        isRequestingLocation = true
        try {
            val location = locationManager.getCurrentLocation()
            if (location != null) {
                println("BranchListScreen: Ubicación real obtenida - Lat: ${location.latitude}, Lng: ${location.longitude}")
                viewModel.setUserLocation(location.latitude, location.longitude, isRealLocation = true)
            } else {
                println("BranchListScreen: No se pudo obtener ubicación, usando Lima como fallback")
                viewModel.setUserLocation(-12.0464, -77.0428, isRealLocation = false)
            }
        } catch (e: Exception) {
            println("BranchListScreen: Error obteniendo ubicación - ${e.message}")
            viewModel.setUserLocation(-12.0464, -77.0428, isRealLocation = false)
        } finally {
            isRequestingLocation = false
        }
    }

    // Launcher para permisos de ubicación
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseLocationGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        locationPermissionGranted = fineLocationGranted || coarseLocationGranted

        if (locationPermissionGranted) {
            println("BranchListScreen: Permisos concedidos, obteniendo ubicación")
        } else {
            println("BranchListScreen: Permisos de ubicación denegados")
            // Usar ubicación por defecto - MARCAR COMO NO REAL
            viewModel.setUserLocation(-12.0464, -77.0428, isRealLocation = false)
        }
    }

    // Función para solicitar permisos (SIMPLIFICADA)
    val requestLocationPermissions = {
        when {
            locationManager.hasPermissions() -> {
                locationPermissionGranted = true
            }
            else -> {
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        }
    }

    val displayBranches = remember(uiState.branches, uiState.nearbyBranches, searchQuery) {
        when {
            searchQuery.isNotEmpty() -> {
                uiState.branches.filter { branch ->
                    branch.name.contains(searchQuery, ignoreCase = true) ||
                            branch.address.contains(searchQuery, ignoreCase = true) ||
                            branch.phone.contains(searchQuery, ignoreCase = true)
                }
            }
            uiState.nearbyBranches.isNotEmpty() -> {
                val nearby = uiState.nearbyBranches.take(3)
                val others = uiState.branches.filter { branch ->
                    !uiState.nearbyBranches.any { it.id == branch.id }
                }.take(7)
                nearby + others
            }
            else -> uiState.branches
        }
    }

    // LaunchedEffect para inicialización
    LaunchedEffect(key1 = true) {
        isVisible = true
        viewModel.loadBranches()

        // Verificar permisos y solicitar ubicación
        if (locationManager.hasPermissions()) {
            locationPermissionGranted = true
            getCurrentUserLocation()
        } else {
            requestLocationPermissions()
        }
    }

    // LaunchedEffect para obtener ubicación después de conceder permisos
    LaunchedEffect(locationPermissionGranted) {
        if (locationPermissionGranted) {
            getCurrentUserLocation()
        }
    }

    // Loading overlay
    LoadingOverlay(
        isVisible = (uiState.isLoading && uiState.branches.isEmpty()) || isRequestingLocation,
        message = when {
            isRequestingLocation -> "Obteniendo tu ubicación..."
            uiState.isLoading -> "Cargando sucursales..."
            else -> ""
        }
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MassOrange.copy(alpha = 0.08f),
                        Color.White,
                        MassBlue.copy(alpha = 0.06f)
                    )
                )
            )
    ) {
        PullToRefreshBox(
            isRefreshing = uiState.isRefreshing,
            onRefresh = {
                viewModel.refreshBranches()
                // También refrescar sucursales cercanas
                uiState.userLocation?.let { (lat, lng) ->
                    viewModel.loadNearbyBranches(lat, lng)
                }
            },
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.systemBars),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Header mejorado
                item {
                    BranchHeader(
                        branchCount = uiState.branches.size,
                        nearbyCount = uiState.nearbyBranches.size,
                        hasLocation = viewModel.hasUserLocation(),
                        onNavigateBack = onNavigateBack,
                        onNavigateToCreate = onNavigateToCreate,
                        isVisible = isVisible
                    )
                }

                // Stats Cards mejoradas
                item {
                    BranchStatsSection(
                        totalBranches = uiState.branches.size,
                        nearbyBranches = uiState.nearbyBranches.size,
                        activeBranches = uiState.branches.count { it.isActive },
                        isVisible = isVisible
                    )
                }

                // Search y View Mode Selector
                item {
                    BranchSearchAndControls(
                        searchQuery = searchQuery,
                        onSearchChange = { searchQuery = it },
                        viewMode = viewMode,
                        onViewModeChange = { viewMode = it },
                        onShowFilters = { showFilters = true },
                        onNavigateToMap = onNavigateToMap,
                        isVisible = isVisible
                    )
                }

                if (uiState.nearbyBranches.isNotEmpty() && searchQuery.isEmpty()) {
                    item {
                        NearbyBranchesSection(
                            branches = uiState.nearbyBranches,
                            onBranchClick = onNavigateToDetail,
                            userLocation = uiState.userLocation,
                            isVisible = isVisible
                        )
                    }
                }

                // Lista/Grid de Sucursales usando displayBranches
                item {
                    when {
                        uiState.isLoading && displayBranches.isEmpty() -> {
                            BranchLoadingState()
                        }
                        displayBranches.isEmpty() -> {
                            BranchEmptyState(
                                onRetry = { viewModel.loadBranches() },
                                onCreateNew = onNavigateToCreate,
                                searchQuery = searchQuery
                            )
                        }
                        else -> {
                            // Título dinámico según el contexto
                            BranchContentSection(
                                title = when {
                                    searchQuery.isNotEmpty() -> "Resultados de búsqueda (${displayBranches.size})"
                                    uiState.nearbyBranches.isNotEmpty() -> "Todas las sucursales"
                                    else -> "Sucursales disponibles"
                                },
                                branches = displayBranches,
                                viewMode = viewMode,
                                onBranchClick = onNavigateToDetail,
                                userLocation = uiState.userLocation,
                                onNavigateToMap = onNavigateToMap,
                                isVisible = isVisible
                            )
                        }
                    }
                }
            }
        }

        // Error y Success Messages
        uiState.errorMessage?.let { error ->
            BranchErrorSnackbar(
                message = error,
                onDismiss = { viewModel.clearError() },
                onRetry = { viewModel.loadBranches() },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        uiState.successMessage?.let { message ->
            BranchSuccessSnackbar(
                message = message,
                onDismiss = { viewModel.clearSuccessMessage() },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }

    // Filters Bottom Sheet
    if (showFilters) {
        BranchFiltersBottomSheet(
            onDismiss = { showFilters = false },
            onSortByDistance = { viewModel.sortBranchesByDistance() },
            onSortByName = { viewModel.sortBranchesByName() }
        )
    }
}

@Composable
private fun BranchHeader(
    branchCount: Int,
    nearbyCount: Int,
    hasLocation: Boolean,
    onNavigateBack: () -> Unit,
    onNavigateToCreate: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        alpha = 0.15f,
        cornerRadius = 24.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp)
        ) {
            // Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassmorphicCard(
                        modifier = Modifier.size(48.dp),
                        alpha = 0.2f,
                        cornerRadius = 24.dp,
                        onClick = onNavigateBack
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Volver",
                                tint = MassOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = "🏢 Sucursales",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MassBlue
                            )
                        )
                        Text(
                            text = if (hasLocation)
                                "$branchCount sucursales • $nearbyCount cercanas"
                            else
                                "$branchCount sucursales disponibles",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Location Status
            if (hasLocation) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Ubicación",
                        tint = SuccessColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Ubicación detectada • Mostrando sucursales cercanas",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = SuccessColor,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Sin ubicación",
                        tint = WarningColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Activa la ubicación para ver sucursales cercanas",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = WarningColor,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchStatsSection(
    totalBranches: Int,
    nearbyBranches: Int,
    activeBranches: Int,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 200),
        label = "alpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Total Branches
        BranchStatCard(
            title = "Total",
            value = totalBranches.toString(),
            subtitle = "sucursales",
            icon = Icons.Default.ShoppingCart,
            gradient = listOf(MassBlue, MassBlueLight),
            modifier = Modifier.weight(1f)
        )

        // Nearby Branches (solo si hay ubicación)
        if (nearbyBranches > 0) {
            BranchStatCard(
                title = "Cercanas",
                value = nearbyBranches.toString(),
                subtitle = "< 10km",
                icon = Icons.Default.Home,
                gradient = listOf(MassOrange, MassYellow),
                modifier = Modifier.weight(1f)
            )
        }

        // Active Status
        BranchStatCard(
            title = "Activas",
            value = activeBranches.toString(),
            subtitle = "${if (totalBranches > 0) ((activeBranches.toFloat() / totalBranches) * 100).toInt() else 0}%",
            icon = Icons.Default.CheckCircle,
            gradient = listOf(SuccessColor, Color(0xFF059669)),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun NearbyBranchesSection(
    branches: List<Branch>,
    onBranchClick: (Branch) -> Unit,
    userLocation: Pair<Double, Double>?,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 600),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "📍 Sucursales Cercanas",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
                Text(
                    text = "Ordenadas por proximidad a tu ubicación",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.Gray
                    )
                )
            }

            // Badge con el número de sucursales cercanas
            GlassmorphicCard(
                alpha = 0.2f,
                cornerRadius = 12.dp
            ) {
                Text(
                    text = "${branches.size}",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MassOrange,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(branches.take(5)) { branch ->
                BranchNearbyCard(
                    branch = branch,
                    onClick = { onBranchClick(branch) }
                )
            }
        }
    }
}

@Composable
private fun BranchContentSection(
    title: String,
    branches: List<Branch>,
    viewMode: BranchViewMode,
    onBranchClick: (Branch) -> Unit,
    userLocation: Pair<Double, Double>?,
    onNavigateToMap: () -> Unit,
    isVisible: Boolean
) {
    Column {
        // Título de la sección
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            ),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Contenido según el modo de vista
        when (viewMode) {
            BranchViewMode.LIST -> {
                BranchListContent(
                    branches = branches,
                    onBranchClick = onBranchClick,
                    userLocation = userLocation,
                    isVisible = isVisible
                )
            }
            BranchViewMode.GRID -> {
                BranchGridContent(
                    branches = branches,
                    onBranchClick = onBranchClick,
                    userLocation = userLocation,
                    isVisible = isVisible
                )
            }
            BranchViewMode.MAP -> {
                BranchMapPreview(
                    branches = branches,
                    onNavigateToFullMap = onNavigateToMap,
                    isVisible = isVisible
                )
            }
        }
    }
}

@Composable
private fun BranchStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    gradient: List<Color>,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.height(100.dp),
        alpha = 0.1f,
        cornerRadius = 20.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.linearGradient(
                        colors = gradient.map { it.copy(alpha = 0.1f) }
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = gradient.first(),
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = gradient.first(),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = gradient.first()
                        )
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color.Gray
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchSearchAndControls(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    viewMode: BranchViewMode,
    onViewModeChange: (BranchViewMode) -> Unit,
    onShowFilters: () -> Unit,
    onNavigateToMap: () -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 400),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
    ) {
        // Search Bar
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            alpha = 0.1f,
            cornerRadius = 20.dp
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text(
                        text = "Buscar sucursales...",
                        color = Color.Gray
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Buscar",
                        tint = MassOrange
                    )
                },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Limpiar",
                                tint = Color.Gray
                            )
                        }
                    }
                } else null,
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MassOrange,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = MassBlue,
                    unfocusedTextColor = MassBlue
                ),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // View Mode Selector
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BranchViewModeButton(
                    icon = Icons.AutoMirrored.Filled.List,
                    isSelected = viewMode == BranchViewMode.LIST,
                    onClick = { onViewModeChange(BranchViewMode.LIST) },
                    modifier = Modifier.weight(1f)
                )

                BranchViewModeButton(
                    icon = Icons.Default.Menu,
                    isSelected = viewMode == BranchViewMode.GRID,
                    onClick = { onViewModeChange(BranchViewMode.GRID) },
                    modifier = Modifier.weight(1f)
                )
            }

            // Filters Button
            GlassmorphicCard(
                alpha = 0.15f,
                cornerRadius = 16.dp,
                onClick = onShowFilters
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Filtros",
                        tint = MassBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Filtros",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MassBlue,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }

            // Map Button
            GlassmorphicCard(
                alpha = 0.15f,
                cornerRadius = 16.dp,
                onClick = onNavigateToMap
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Mapa",
                        tint = SuccessColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Mapa",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = SuccessColor,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BranchViewModeButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier.height(44.dp),
        alpha = if (isSelected) 0.25f else 0.1f,
        cornerRadius = 16.dp,
        onClick = onClick
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = if (isSelected) {
                        Brush.linearGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.2f),
                                MassYellow.copy(alpha = 0.1f)
                            )
                        )
                    } else {
                        Brush.linearGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) MassOrange else Color.Gray,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun NearbyBranchesSection(
    branches: List<Branch>,
    onBranchClick: (Branch) -> Unit,
    isVisible: Boolean
) {
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(800, delayMillis = 600),
        label = "alpha"
    )

    Column(
        modifier = Modifier.alpha(alpha)
    ) {
        Text(
            text = "Sucursales Cercanas",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = MassBlue
            )
        )

        Text(
            text = "Las más próximas a tu ubicación",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = Color.Gray
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(horizontal = 4.dp)
        ) {
            items(branches.take(5)) { branch ->
                BranchNearbyCard(
                    branch = branch,
                    onClick = { onBranchClick(branch) }
                )
            }
        }
    }
}

@Composable
fun BranchListContent(
    branches: List<Branch>,
    onBranchClick: (Branch) -> Unit,
    userLocation: Pair<Double, Double>?,
    isVisible: Boolean
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        branches.forEach { branch ->
            BranchCard(
                branch = branch,
                onClick = { onBranchClick(branch) },
                userLocation = userLocation
            )
        }
    }
}

@Composable
fun BranchGridContent(
    branches: List<Branch>,
    onBranchClick: (Branch) -> Unit,
    userLocation: Pair<Double, Double>?,
    isVisible: Boolean
) {
    val chunkedBranches = branches.chunked(2)

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        chunkedBranches.forEach { rowBranches ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowBranches.forEach { branch ->
                    BranchGridCard(
                        branch = branch,
                        onClick = { onBranchClick(branch) },
                        userLocation = userLocation,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Si hay un elemento impar, agregar spacer
                if (rowBranches.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun BranchMapPreview(
    branches: List<Branch>,
    onNavigateToFullMap: () -> Unit,
    isVisible: Boolean
) {
    GlassmorphicCard(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
        alpha = 0.1f,
        cornerRadius = 16.dp,
        onClick = onNavigateToFullMap
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = "Mapa",
                    tint = MassBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Ver en mapa",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MassBlue
                    )
                )
            }
        }
    }
}