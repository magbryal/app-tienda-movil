package com.mass.marketplace.domain.model

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Branch(
    val id: Int,
    val name: String,
    val address: String,
    val phone: String,
    val latitude: Double,
    val longitude: Double,
    val isActive: Boolean,
    val schedule: String = "",
    val createdAt: String = "",
    val updatedAt: String = "",

    val email: String? = null,
    val description: String? = null,
    val openingHours: String? = null,
    val managerId: Int? = null,
    val capacity: Int? = null,
    val hasParking: Boolean? = null,
    val hasWifi: Boolean? = null,
    val hasAccessibility: Boolean? = null,
    val is24Hours: Boolean? = null,
    val hasDriveThrough: Boolean? = null,
    val rating: Double? = null
) {
    fun distanceTo(userLatitude: Double, userLongitude: Double): Double {
        val earthRadius = 6371.0 // Radio de la Tierra en km

        val dLat = Math.toRadians(latitude - userLatitude)
        val dLon = Math.toRadians(longitude - userLongitude)

        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(userLatitude)) * cos(Math.toRadians(latitude)) *
                sin(dLon / 2) * sin(dLon / 2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return earthRadius * c
    }

    fun isOpenNow(): Boolean {
        return isActive && schedule.isNotEmpty()
    }
}