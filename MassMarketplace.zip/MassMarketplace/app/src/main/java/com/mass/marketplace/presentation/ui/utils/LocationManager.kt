package com.mass.marketplace.presentation.ui.utils

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class LocationManager(private val context: Context) {

    private val fusedLocationClient: FusedLocationProviderClient by lazy {
        LocationServices.getFusedLocationProviderClient(context)
    }

    private val locationRequest = LocationRequest.Builder(
        Priority.PRIORITY_HIGH_ACCURACY,
        10000L // 10 segundos
    ).apply {
        setMinUpdateDistanceMeters(10f) // 10 metros
        setGranularity(Granularity.GRANULARITY_PERMISSION_LEVEL)
        setWaitForAccurateLocation(true)
    }.build()

    /**
     * Obtiene la ubicación actual del usuario
     * @return Location si tiene permisos y obtiene la ubicación, null en caso contrario
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): Location? {
        if (!hasLocationPermission()) {
            println("LocationManager: Sin permisos de ubicación")
            return null
        }

        return try {
            suspendCancellableCoroutine { continuation ->
                fusedLocationClient.getCurrentLocation(
                    Priority.PRIORITY_HIGH_ACCURACY,
                    null
                ).addOnSuccessListener { location ->
                    if (location != null) {
                        println("LocationManager: Ubicación obtenida - Lat: ${location.latitude}, Lng: ${location.longitude}")
                        continuation.resume(location)
                    } else {
                        println("LocationManager: Ubicación es null, intentando con última ubicación conocida")
                        // Intentar obtener la última ubicación conocida
                        getLastKnownLocation { lastLocation ->
                            continuation.resume(lastLocation)
                        }
                    }
                }.addOnFailureListener { exception ->
                    println("LocationManager: Error al obtener ubicación - ${exception.message}")
                    // Intentar obtener la última ubicación conocida como fallback
                    getLastKnownLocation { lastLocation ->
                        continuation.resume(lastLocation)
                    }
                }
            }
        } catch (e: SecurityException) {
            println("LocationManager: SecurityException - ${e.message}")
            null
        } catch (e: Exception) {
            println("LocationManager: Exception - ${e.message}")
            null
        }
    }

    /**
     * Obtiene la última ubicación conocida como fallback
     */
    @SuppressLint("MissingPermission")
    private fun getLastKnownLocation(callback: (Location?) -> Unit) {
        if (!hasLocationPermission()) {
            callback(null)
            return
        }

        try {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        println("LocationManager: Última ubicación conocida - Lat: ${location.latitude}, Lng: ${location.longitude}")
                    } else {
                        println("LocationManager: No hay última ubicación conocida")
                    }
                    callback(location)
                }
                .addOnFailureListener { exception ->
                    println("LocationManager: Error al obtener última ubicación - ${exception.message}")
                    callback(null)
                }
        } catch (e: SecurityException) {
            println("LocationManager: SecurityException en última ubicación - ${e.message}")
            callback(null)
        }
    }

    /**
     * Proporciona actualizaciones continuas de ubicación
     */
    @SuppressLint("MissingPermission")
    fun getLocationUpdates(): Flow<Location> = callbackFlow {
        if (!hasLocationPermission()) {
            println("LocationManager: Sin permisos para actualizaciones de ubicación")
            close()
            return@callbackFlow
        }

        val locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.locations.forEach { location ->
                    println("LocationManager: Nueva ubicación - Lat: ${location.latitude}, Lng: ${location.longitude}")
                    trySend(location)
                }
            }

            override fun onLocationAvailability(availability: LocationAvailability) {
                super.onLocationAvailability(availability)
                if (!availability.isLocationAvailable) {
                    println("LocationManager: Ubicación no disponible")
                }
            }
        }

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
            println("LocationManager: Actualizaciones de ubicación iniciadas")
        } catch (e: SecurityException) {
            println("LocationManager: SecurityException en actualizaciones - ${e.message}")
            close()
            return@callbackFlow
        }

        awaitClose {
            try {
                fusedLocationClient.removeLocationUpdates(locationCallback)
                println("LocationManager: Actualizaciones de ubicación detenidas")
            } catch (e: Exception) {
                println("LocationManager: Error al detener actualizaciones - ${e.message}")
            }
        }
    }

    /**
     * Verifica si la aplicación tiene permisos de ubicación
     */
    private fun hasLocationPermission(): Boolean {
        val fineLocation = ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseLocation = ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fineLocation || coarseLocation
    }

    /**
     * Verifica si tiene permisos de ubicación precisa
     */
    fun hasFineLocationPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Verifica si tiene permisos de ubicación aproximada
     */
    fun hasCoarseLocationPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Función pública para verificar permisos
     */
    fun hasPermissions(): Boolean = hasLocationPermission()

    /**
     * Obtiene información detallada sobre el estado de los permisos
     */
    fun getPermissionStatus(): LocationPermissionStatus {
        return LocationPermissionStatus(
            hasFineLocation = hasFineLocationPermission(),
            hasCoarseLocation = hasCoarseLocationPermission(),
            hasAnyPermission = hasLocationPermission()
        )
    }

    /**
     * Calcula la distancia entre dos puntos geográficos
     * @param lat1 Latitud del primer punto
     * @param lon1 Longitud del primer punto
     * @param lat2 Latitud del segundo punto
     * @param lon2 Longitud del segundo punto
     * @return Distancia en kilómetros
     */
    fun calculateDistance(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        return try {
            val results = FloatArray(1)
            Location.distanceBetween(lat1, lon1, lat2, lon2, results)
            (results[0] / 1000.0) // Convertir metros a kilómetros
        } catch (e: Exception) {
            println("LocationManager: Error calculando distancia - ${e.message}")
            0.0
        }
    }

    /**
     * Calcula la distancia desde una ubicación a otra
     */
    fun calculateDistanceFromLocation(
        fromLocation: Location,
        toLat: Double,
        toLng: Double
    ): Double {
        return calculateDistance(
            fromLocation.latitude,
            fromLocation.longitude,
            toLat,
            toLng
        )
    }

    /**
     * Formatea la distancia para mostrar al usuario
     */
    @SuppressLint("DefaultLocale")
    fun formatDistance(distanceKm: Double): String {
        return when {
            distanceKm < 0.1 -> "< 100m"
            distanceKm < 1.0 -> "${(distanceKm * 1000).toInt()}m"
            distanceKm < 10.0 -> String.format("%.1f km", distanceKm)
            else -> String.format("%.0f km", distanceKm)
        }
    }

    /**
     * Verifica si una ubicación está dentro de un radio específico
     */
    fun isWithinRadius(
        centerLat: Double, centerLng: Double,
        targetLat: Double, targetLng: Double,
        radiusKm: Double
    ): Boolean {
        val distance = calculateDistance(centerLat, centerLng, targetLat, targetLng)
        return distance <= radiusKm
    }

    /**
     * Obtiene las coordenadas como un par
     */
    fun getCoordinates(location: Location): Pair<Double, Double> {
        return Pair(location.latitude, location.longitude)
    }

    companion object {
        // Constantes para permisos
        const val FINE_LOCATION_PERMISSION = Manifest.permission.ACCESS_FINE_LOCATION
        const val COARSE_LOCATION_PERMISSION = Manifest.permission.ACCESS_COARSE_LOCATION

        // Array de permisos necesarios
        val REQUIRED_PERMISSIONS = arrayOf(
            FINE_LOCATION_PERMISSION,
            COARSE_LOCATION_PERMISSION
        )
    }
}

/**
 * Data class para el estado de permisos de ubicación
 */
data class LocationPermissionStatus(
    val hasFineLocation: Boolean,
    val hasCoarseLocation: Boolean,
    val hasAnyPermission: Boolean
) {
    val permissionLevel: String
        get() = when {
            hasFineLocation -> "Precisa"
            hasCoarseLocation -> "Aproximada"
            else -> "Sin permisos"
        }
}
