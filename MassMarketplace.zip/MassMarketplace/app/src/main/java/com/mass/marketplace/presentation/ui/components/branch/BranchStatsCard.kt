package com.mass.marketplace.presentation.ui.components.branch

class BranchStatsCard {
}