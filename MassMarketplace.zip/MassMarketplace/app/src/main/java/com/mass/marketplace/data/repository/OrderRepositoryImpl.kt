package com.mass.marketplace.data.repository

import com.mass.marketplace.core.network.ApiService
import com.mass.marketplace.data.local.dao.OrderDao
import com.mass.marketplace.data.local.entity.OrderEntity
import com.mass.marketplace.data.local.entity.OrderItemEntity
import com.mass.marketplace.data.model.request.OrderItemRequest
import com.mass.marketplace.data.model.request.OrderRequest
import com.mass.marketplace.domain.model.Order
import com.mass.marketplace.domain.model.OrderStatus
import com.mass.marketplace.domain.repository.OrderRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.*

class OrderRepositoryImpl(
    private val apiService: ApiService,
    private val orderDao: OrderDao
) : OrderRepository {

    override suspend fun createOrder(order: Order): Result<String> {
        return try {
            println("OrderRepository: Iniciando creación de orden")
            println("   - User ID: ${order.userId}")
            println("   - Total Amount: ${order.total}")
            println("   - Items Count: ${order.items.size}")
            println("   - Payment Proof URL: ${order.paymentProofUrl}")

            val validUserId = if (order.userId.startsWith("temp_")) {
                println("User ID no válido: ${order.userId}, usando 1 por defecto")
                1
            } else {
                try {
                    order.userId.toInt()
                } catch (e: NumberFormatException) {
                    println("Error convirtiendo User ID: ${order.userId}, usando 1 por defecto")
                    1
                }
            }

            val orderRequest = OrderRequest(
                user_id = validUserId,
                order_date = getCurrentDateTime(),
                total_amount = order.total,
                status = "processing",
                payment_method = mapPaymentMethod(order.paymentMethod),
                shipping_address = order.shippingAddress,
                branch_id = 1,
                payment_proof_url = order.paymentProofUrl
            )

            println("Enviando orden a API:")
            println("   - user_id: ${orderRequest.user_id}")
            println("   - order_date: ${orderRequest.order_date}")
            println("   - total_amount: ${orderRequest.total_amount}")
            println("   - status: ${orderRequest.status}")
            println("   - payment_method: ${orderRequest.payment_method}")
            println("   - shipping_address: ${orderRequest.shipping_address}")
            println("   - branch_id: ${orderRequest.branch_id}")
            println("   - payment_proof_url: ${orderRequest.payment_proof_url}")

            val orderResponse = apiService.createOrder(orderRequest)
            println("Orden creada: ${orderResponse["message"]}")

            // Extraer el order_id de la respuesta si está disponible
            val orderId = orderResponse["order_id"]?.toIntOrNull() ?: run {
                // Si no está disponible, generar uno temporal
                System.currentTimeMillis().toInt()
            }

            // GUARDAR EN BASE DE DATOS LOCAL
            val orderEntity = OrderEntity(
                id = orderId.toString(),
                userId = order.userId,
                orderDate = orderRequest.order_date,
                subtotal = order.subtotal,
                tax = order.tax,
                shipping = order.shipping,
                total = order.total,
                status = order.status.name,
                shippingAddress = order.shippingAddress,
                paymentMethod = order.paymentMethod,
                paymentProofUrl = order.paymentProofUrl
            )

            val orderItems = order.items.map { item ->
                OrderItemEntity(
                    orderId = orderId.toString(),
                    productId = item.productId,
                    productName = item.productName,
                    productImage = item.productImage,
                    quantity = item.quantity,
                    unitPrice = item.unitPrice,
                    subtotal = item.subtotal
                )
            }

            // Guardar en Room
            orderDao.insertOrder(orderEntity)
            orderDao.insertOrderItems(orderItems)

            println("Orden guardada localmente: ${orderId}")

            // 2. Crear los items de la orden en la API
            println("Creando ${order.items.size} items de la orden...")
            order.items.forEachIndexed { index, cartItem ->
                val orderItemRequest = OrderItemRequest(
                    order_id = orderId,
                    product_id = cartItem.productId,
                    quantity = cartItem.quantity,
                    unit_price = cartItem.unitPrice,
                    subtotal = cartItem.subtotal
                )

                println("Enviando item ${index + 1}:")
                println("   - order_id: ${orderItemRequest.order_id}")
                println("   - product_id: ${orderItemRequest.product_id}")
                println("   - quantity: ${orderItemRequest.quantity}")
                println("   - unit_price: ${orderItemRequest.unit_price}")
                println("   - subtotal: ${orderItemRequest.subtotal}")

                val itemResponse = apiService.createOrderItem(orderItemRequest)
                println("Item ${index + 1} agregado: ${itemResponse["message"]}")
            }

            println("Orden completa creada exitosamente")
            Result.success(orderResponse["message"] ?: "Orden creada exitosamente")

        } catch (e: Exception) {
            println("Error creando orden: ${e.message}")
            println("Stack trace: ${e.stackTrace.joinToString("\n")}")
            Result.failure(e)
        }
    }

    override suspend fun getOrders(): Result<List<Order>> {
        return try {
            println("OrderRepository: Obteniendo órdenes de API...")
            val ordersResponse = apiService.getOrders()
            println("Recibidas ${ordersResponse.size} órdenes de API")

            // Mapear y guardar en BD local
            ordersResponse.forEach { orderResponse ->
                val orderEntity = OrderEntity(
                    id = orderResponse.id.toString(),
                    userId = orderResponse.user_id.toString(),
                    orderDate = orderResponse.created_at,
                    subtotal = orderResponse.total_amount,
                    tax = 0.0,
                    shipping = 0.0,
                    total = orderResponse.total_amount,
                    status = orderResponse.status,
                    shippingAddress = "",
                    paymentMethod = "",
                    paymentProofUrl = orderResponse.payment_proof_url
                )
                orderDao.insertOrder(orderEntity)
            }

            val orders = ordersResponse.map { orderResponse ->
                Order(
                    id = orderResponse.id.toString(),
                    userId = orderResponse.user_id.toString(),
                    items = emptyList(),
                    subtotal = orderResponse.total_amount,
                    tax = 0.0,
                    shipping = 0.0,
                    total = orderResponse.total_amount,
                    status = mapOrderStatus(orderResponse.status),
                    createdAt = orderResponse.created_at,
                    shippingAddress = "",
                    paymentMethod = "",
                    paymentProofUrl = orderResponse.payment_proof_url
                )
            }

            println("${orders.size} órdenes mapeadas correctamente")
            Result.success(orders)
        } catch (e: Exception) {
            println("Error obteniendo órdenes de API: ${e.message}")
            Result.failure(e)
        }
    }

    // IMPLEMENTAR MÉTODOS DE ROOM
    override fun getLocalOrders(): Flow<List<Order>> {
        return orderDao.getAllOrders().map { entities ->
            entities.map { entity ->
                Order(
                    id = entity.id,
                    userId = entity.userId,
                    items = emptyList(), // Se cargarán por separado
                    subtotal = entity.subtotal,
                    tax = entity.tax,
                    shipping = entity.shipping,
                    total = entity.total,
                    status = try {
                        OrderStatus.valueOf(entity.status.uppercase())
                    } catch (e: Exception) {
                        OrderStatus.PENDING
                    },
                    createdAt = entity.orderDate,
                    shippingAddress = entity.shippingAddress,
                    paymentMethod = entity.paymentMethod,
                    paymentProofUrl = entity.paymentProofUrl
                )
            }
        }
    }

    override suspend fun getOrderById(orderId: String): Order? {
        return try {
            val orderEntity = orderDao.getOrderById(orderId)
            val orderItems = orderDao.getOrderItems(orderId)

            orderEntity?.let { entity ->
                Order(
                    id = entity.id,
                    userId = entity.userId,
                    items = orderItems.map { item ->
                        // Convertir OrderItemEntity a CartItem
                        com.mass.marketplace.domain.model.CartItem(
                            productId = item.productId,
                            productName = item.productName,
                            productImage = item.productImage,
                            quantity = item.quantity,
                            unitPrice = item.unitPrice,
                            subtotal = item.subtotal
                        )
                    },
                    subtotal = entity.subtotal,
                    tax = entity.tax,
                    shipping = entity.shipping,
                    total = entity.total,
                    status = try {
                        OrderStatus.valueOf(entity.status.uppercase())
                    } catch (e: Exception) {
                        OrderStatus.PENDING
                    },
                    createdAt = entity.orderDate,
                    shippingAddress = entity.shippingAddress,
                    paymentMethod = entity.paymentMethod,
                    paymentProofUrl = entity.paymentProofUrl
                )
            }
        } catch (e: Exception) {
            println("Error obteniendo orden por ID: ${e.message}")
            null
        }
    }

    override suspend fun deleteOrder(orderId: String) {
        try {
            orderDao.deleteOrderWithItems(orderId)
            println("Orden $orderId eliminada localmente")
        } catch (e: Exception) {
            println("Error eliminando orden: ${e.message}")
        }
    }

    private fun getCurrentDateTime(): String {
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val currentDateTime = formatter.format(Date())
        println("Fecha/hora actual: $currentDateTime")
        return currentDateTime
    }

    private fun mapPaymentMethod(method: String): String {
        val mapped = when (method.lowercase()) {
            "yape" -> "yape"
            "plin" -> "plin"
            "tarjeta de crédito" -> "credit_card"
            "tarjeta de débito" -> "debit_card"
            "efectivo" -> "cash"
            else -> "cash"
        }
        println("Método de pago mapeado: '$method' -> '$mapped'")
        return mapped
    }

    private fun mapOrderStatus(status: String): OrderStatus {
        val mapped = when (status.lowercase()) {
            "pending" -> OrderStatus.PENDING
            "processing", "en proceso" -> OrderStatus.PROCESSING
            "confirmed" -> OrderStatus.CONFIRMED
            "shipped" -> OrderStatus.SHIPPED
            "delivered" -> OrderStatus.DELIVERED
            "cancelled" -> OrderStatus.CANCELLED
            else -> OrderStatus.PENDING
        }
        println("Estado mapeado: '$status' -> '$mapped'")
        return mapped
    }
}
