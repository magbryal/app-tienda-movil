package com.mass.marketplace.core.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.domain.usecase.category.GetCategoriesUseCase
import com.mass.marketplace.domain.usecase.product.GetProductsUseCase
import com.mass.marketplace.presentation.ui.screens.home.Category
import com.mass.marketplace.presentation.ui.screens.home.Product
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(
    private val getProductsUseCase: GetProductsUseCase,
    private val getCategoriesUseCase: GetCategoriesUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            // Cargar productos y categorías en paralelo
            val productsDeferred = async { getProductsUseCase() }
            val categoriesDeferred = async { getCategoriesUseCase() }

            val productsResult = productsDeferred.await()
            val categoriesResult = categoriesDeferred.await()

            productsResult.fold(
                onSuccess = { products ->
                    println("Productos cargados exitosamente: ${products.size}")

                    val productIds = products.map { it.id }
                    val uniqueIds = productIds.toSet()

                    println("Análisis de IDs:")
                    println("   - Total productos: ${products.size}")
                    println("   - IDs únicos: ${uniqueIds.size}")

                    if (uniqueIds.size != products.size) {
                        println("¡PROBLEMA ENCONTRADO! Hay IDs duplicados:")
                        productIds.groupBy { it }.forEach { (id, occurrences) ->
                            if (occurrences.size > 1) {
                                println("   - ID '$id' aparece ${occurrences.size} veces")
                                val duplicatedProducts = products.filter { it.id == id }
                                duplicatedProducts.forEach { product ->
                                    println("     * ${product.name} (${product.store})")
                                }
                            }
                        }
                    } else {
                        println("Todos los productos tienen IDs únicos")
                        // Mostrar algunos ejemplos
                        products.take(5).forEach { product ->
                            println("   - ${product.id}: ${product.name}")
                        }
                    }

                    _uiState.value = _uiState.value.copy(
                        products = products,
                        featuredProducts = products.take(10)
                    )
                },
                onFailure = { error ->
                    println("Error al cargar productos: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        errorMessage = error.message
                    )
                }
            )

            categoriesResult.fold(
                onSuccess = { categories ->
                    println("Categorías cargadas exitosamente: ${categories.size}")
                    _uiState.value = _uiState.value.copy(
                        categories = categories
                    )
                },
                onFailure = { error ->
                    println("Error al cargar categorías: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        categories = emptyList()
                    )
                }
            )

            _uiState.value = _uiState.value.copy(isLoading = false)
        }
    }

    fun loadProducts() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

            getProductsUseCase().fold(
                onSuccess = { products ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        products = products,
                        featuredProducts = products.take(10)
                    )
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.message
                    )
                }
            )
        }
    }

    fun loadCategories() {
        viewModelScope.launch {
            println("Iniciando carga manual de categorías...")
            _uiState.value = _uiState.value.copy(isLoading = true)

            getCategoriesUseCase().fold(
                onSuccess = { categories ->
                    println("Categorías cargadas manualmente: ${categories.size}")
                    _uiState.value = _uiState.value.copy(
                        categories = categories,
                        isLoading = false
                    )
                },
                onFailure = { error ->
                    println("Error en carga manual de categorías: ${error.message}")
                    _uiState.value = _uiState.value.copy(
                        categories = emptyList(),
                        isLoading = false
                    )
                }
            )
        }
    }

    fun refreshProducts() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isRefreshing = true, errorMessage = null)

            // Refresh tanto productos como categorías
            val productsDeferred = async { getProductsUseCase() }
            val categoriesDeferred = async { getCategoriesUseCase() }

            val productsResult = productsDeferred.await()
            val categoriesResult = categoriesDeferred.await()

            productsResult.fold(
                onSuccess = { products ->
                    _uiState.value = _uiState.value.copy(
                        products = products,
                        featuredProducts = products.take(10)
                    )
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        errorMessage = error.message
                    )
                }
            )

            // Actualizar categorías también en el refresh
            categoriesResult.fold(
                onSuccess = { categories ->
                    _uiState.value = _uiState.value.copy(
                        categories = categories
                    )
                },
                onFailure = { error ->
                    println("Error al refrescar categorías: ${error.message}")
                    // Mantener categorías existentes o vacías si es la primera vez
                }
            )

            _uiState.value = _uiState.value.copy(isRefreshing = false)
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}

data class HomeUiState(
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,
    val products: List<Product> = emptyList(),
    val featuredProducts: List<Product> = emptyList(),
    val categories: List<Category> = emptyList(),
    val errorMessage: String? = null
)
