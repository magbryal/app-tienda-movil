package com.mass.marketplace.core.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.data.local.SessionManager
import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.domain.model.Order
import com.mass.marketplace.domain.model.OrderStatus
import com.mass.marketplace.domain.usecase.cart.ClearCartUseCase
import com.mass.marketplace.domain.usecase.cart.GetCartItemsUseCase
import com.mass.marketplace.domain.usecase.order.CreateOrderUseCase
import com.mass.marketplace.domain.usecase.payment.UploadPaymentProofUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CheckoutUiState(
    val cartItems: List<CartItem> = emptyList(),
    val subtotal: Double = 0.0,
    val tax: Double = 0.0,
    val shipping: Double = 0.0,
    val total: Double = 0.0,
    val isLoading: Boolean = false,
    val isProcessingPayment: Boolean = false,
    val orderCreated: Boolean = false,
    val errorMessage: String? = null,
    val userInfo: com.mass.marketplace.data.local.UserInfo? = null,
    val paymentProofUri: Uri? = null,
    val isUploadingProof: Boolean = false,
    val proofUploadError: String? = null,
    val uploadedProofUrl: String? = null
)

class CheckoutViewModel(
    private val getCartItemsUseCase: GetCartItemsUseCase,
    private val createOrderUseCase: CreateOrderUseCase,
    private val clearCartUseCase: ClearCartUseCase,
    private val sessionManager: SessionManager,
    private val uploadPaymentProofUseCase: UploadPaymentProofUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(CheckoutUiState())
    val uiState: StateFlow<CheckoutUiState> = _uiState.asStateFlow()

    fun setPaymentProof(uri: Uri) {
        _uiState.value = _uiState.value.copy(paymentProofUri = uri)
    }

    fun uploadPaymentProof(context: Context) {
        viewModelScope.launch {
            try {
                val currentState = _uiState.value
                val proofUri = currentState.paymentProofUri

                if (proofUri == null) {
                    _uiState.value = _uiState.value.copy(
                        proofUploadError = "No hay comprobante seleccionado"
                    )
                    return@launch
                }

                _uiState.value = _uiState.value.copy(
                    isUploadingProof = true,
                    proofUploadError = null,
                    uploadedProofUrl = null
                )

                println("🔄 Subiendo comprobante...")
                val result = uploadPaymentProofUseCase(context, proofUri)

                result.fold(
                    onSuccess = { uploadedUrl ->
                        println("Comprobante subido: $uploadedUrl")
                        _uiState.value = _uiState.value.copy(
                            isUploadingProof = false,
                            uploadedProofUrl = uploadedUrl
                        )
                    },
                    onFailure = { error ->
                        println("Error subiendo: ${error.message}")
                        _uiState.value = _uiState.value.copy(
                            isUploadingProof = false,
                            proofUploadError = "Error al subir: ${error.message}"
                        )
                    }
                )

            } catch (e: Exception) {
                println("Exception en uploadPaymentProof: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isUploadingProof = false,
                    proofUploadError = "Error inesperado: ${e.message}"
                )
            }
        }
    }

    init {
        loadCartItems()
        loadUserInfo()
    }

    private fun loadUserInfo() {
        viewModelScope.launch {
            try {
                val userInfo = sessionManager.getUserInfo()
                _uiState.value = _uiState.value.copy(userInfo = userInfo)

                println("🔍 CheckoutViewModel: Usuario cargado")
                println("   - ID: ${userInfo?.id}")
                println("   - Email: ${userInfo?.email}")
                println("   - Name: ${userInfo?.name}")
                println("   - Is Logged In: ${userInfo?.isLoggedIn}")
            } catch (e: Exception) {
                println("Error cargando info del usuario: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al cargar información del usuario"
                )
            }
        }
    }

    private fun loadCartItems() {
        viewModelScope.launch {
            getCartItemsUseCase().collect { items ->
                val subtotal = items.sumOf { it.subtotal }
                val tax = subtotal * 0.18 // IGV 18%
                val shipping = if (subtotal > 100.0) 0.0 else 15.0
                val total = subtotal + tax + shipping

                _uiState.value = _uiState.value.copy(
                    cartItems = items,
                    subtotal = subtotal,
                    tax = tax,
                    shipping = shipping,
                    total = total
                )
            }
        }
    }

    fun createOrder(
        shippingAddress: String,
        paymentMethod: String,
        paymentProofUrl: String? = null
    ) {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(
                    isProcessingPayment = true,
                    errorMessage = null
                )

                val currentState = _uiState.value

                val userInfo = currentState.userInfo
                if (userInfo == null || !userInfo.isLoggedIn) {
                    _uiState.value = _uiState.value.copy(
                        isProcessingPayment = false,
                        errorMessage = "Debes iniciar sesión para realizar un pedido"
                    )
                    return@launch
                }

                val order = Order(
                    userId = userInfo.id,
                    items = currentState.cartItems,
                    subtotal = currentState.subtotal,
                    tax = currentState.tax,
                    shipping = currentState.shipping,
                    total = currentState.total,
                    status = OrderStatus.PENDING,
                    shippingAddress = shippingAddress,
                    paymentMethod = paymentMethod,
                    paymentProofUrl = paymentProofUrl
                )

                println("CheckoutViewModel: Creando orden con comprobante")
                println("   - Comprobante URL: $paymentProofUrl")

                val result = createOrderUseCase(order)

                result.fold(
                    onSuccess = { message ->
                        println("Orden creada exitosamente: $message")
                        clearCartUseCase()
                        _uiState.value = _uiState.value.copy(
                            isProcessingPayment = false,
                            orderCreated = true
                        )
                    },
                    onFailure = { error ->
                        println("Error creando orden: ${error.message}")
                        _uiState.value = _uiState.value.copy(
                            isProcessingPayment = false,
                            errorMessage = "Error al procesar el pedido: ${error.message}"
                        )
                    }
                )

            } catch (e: Exception) {
                println("Exception en createOrder: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    isProcessingPayment = false,
                    errorMessage = "Error inesperado: ${e.message}"
                )
            }
        }
    }

    fun clearProofError() {
        _uiState.value = _uiState.value.copy(proofUploadError = null)
    }

    fun checkUserSession() {
        viewModelScope.launch {
            try {
                val isValidSession = sessionManager.hasValidSession()
                if (!isValidSession) {
                    _uiState.value = _uiState.value.copy(
                        errorMessage = "Tu sesión ha expirado. Inicia sesión nuevamente."
                    )
                }
            } catch (e: Exception) {
                println("Error verificando sesión: ${e.message}")
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    fun resetOrderCreated() {
        _uiState.value = _uiState.value.copy(orderCreated = false)
    }
}
