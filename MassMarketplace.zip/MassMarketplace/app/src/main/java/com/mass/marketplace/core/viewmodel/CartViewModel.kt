package com.mass.marketplace.core.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.domain.usecase.cart.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CartUiState(
    val items: List<CartItem> = emptyList(),
    val subtotal: Double = 0.0,
    val tax: Double = 0.0,
    val shipping: Double = 0.0,
    val total: Double = 0.0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class CartViewModel(
    private val getCartItemsUseCase: GetCartItemsUseCase,
    private val addToCartUseCase: AddToCartUseCase,
    private val updateCartQuantityUseCase: UpdateCartQuantityUseCase,
    private val removeFromCartUseCase: RemoveFromCartUseCase,
    private val clearCartUseCase: ClearCartUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(CartUiState())
    val uiState: StateFlow<CartUiState> = _uiState.asStateFlow()

    init {
        observeCartItems()
    }

    private fun observeCartItems() {
        viewModelScope.launch {
            getCartItemsUseCase().collect { items ->
                val subtotal = items.sumOf { it.subtotal }
                val tax = subtotal * 0.16 // 16% tax
                val shipping = if (subtotal > 50.0) 0.0 else 5.99 // Free shipping over $50
                val total = subtotal + tax + shipping

                _uiState.value = _uiState.value.copy(
                    items = items,
                    subtotal = subtotal,
                    tax = tax,
                    shipping = shipping,
                    total = total
                )
            }
        }
    }

    fun addToCart(item: CartItem) {
        viewModelScope.launch {
            try {
                println("CartViewModel: Recibiendo item para agregar")
                println("   - Product ID: ${item.productId}")
                println("   - Product Name: ${item.productName}")
                println("   - Unit Price: ${item.unitPrice}")
                println("   - Quantity: ${item.quantity}")

                // Log del estado ANTES de agregar
                val currentItemsBefore = _uiState.value.items
                println("Estado ANTES de agregar:")
                println("   - Total items únicos: ${currentItemsBefore.size}")
                println("   - Total productos: ${currentItemsBefore.sumOf { it.quantity }}")
                currentItemsBefore.forEachIndexed { index, cartItem ->
                    println("     $index: ${cartItem.productName} (ID: ${cartItem.productId}) - Qty: ${cartItem.quantity}")
                }

                addToCartUseCase(item)

                // Log del estado DESPUÉS de agregar
                kotlinx.coroutines.delay(100)
                val currentItemsAfter = _uiState.value.items
                println("Estado DESPUÉS de agregar:")
                println("   - Total items únicos: ${currentItemsAfter.size}")
                println("   - Total productos: ${currentItemsAfter.sumOf { it.quantity }}")
                currentItemsAfter.forEachIndexed { index, cartItem ->
                    println("     $index: ${cartItem.productName} (ID: ${cartItem.productId}) - Qty: ${cartItem.quantity}")
                }

            } catch (e: Exception) {
                println("CartViewModel: Error al agregar al carrito: ${e.message}")
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al agregar al carrito: ${e.message}"
                )
            }
        }
    }

    fun updateQuantity(productId: Int, quantity: Int) {
        viewModelScope.launch {
            try {
                updateCartQuantityUseCase(productId, quantity)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al actualizar cantidad: ${e.message}"
                )
            }
        }
    }

    fun removeFromCart(productId: Int) {
        viewModelScope.launch {
            try {
                removeFromCartUseCase(productId)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al eliminar del carrito: ${e.message}"
                )
            }
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            try {
                clearCartUseCase()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Error al limpiar carrito: ${e.message}"
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
