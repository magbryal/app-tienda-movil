package com.mass.marketplace.data.model.response

data class OrderItemResponse(
    val id: Int,
    val order_id: Int,
    val product_id: Int,
    val quantity: Int,
    val unit_price: Double,
    val subtotal: Double
)