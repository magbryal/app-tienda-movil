package com.mass.marketplace.domain.repository

import com.mass.marketplace.data.model.response.AuthResponse

interface AuthRepository {
    suspend fun register(
        name: String,
        lastName: String,
        email: String,
        password: String,
        phone: String,
        address: String
    ): Result<AuthResponse>

    suspend fun login(
        email: String,
        password: String
    ): Result<AuthResponse>
}
