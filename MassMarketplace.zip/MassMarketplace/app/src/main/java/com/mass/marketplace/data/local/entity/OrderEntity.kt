package com.mass.marketplace.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val orderDate: String,
    val subtotal: Double,
    val tax: Double,
    val shipping: Double,
    val total: Double,
    val status: String,
    val shippingAddress: String,
    val paymentMethod: String,
    val paymentProofUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "order_items",
    foreignKeys = [
        ForeignKey(
            entity = OrderEntity::class,
            parentColumns = ["id"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderId: String,
    val productId: Int,
    val productName: String,
    val productImage: String,
    val quantity: Int,
    val unitPrice: Double,
    val subtotal: Double
)
