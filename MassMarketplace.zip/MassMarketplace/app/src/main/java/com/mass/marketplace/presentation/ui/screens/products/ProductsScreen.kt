package com.mass.marketplace.presentation.ui.screens.products

import android.annotation.SuppressLint
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mass.marketplace.core.viewmodel.CartViewModel
import com.mass.marketplace.core.viewmodel.ProductsViewModel
import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.presentation.ui.components.buttons.MassButton
import com.mass.marketplace.presentation.ui.components.cards.ProductCard
import com.mass.marketplace.presentation.ui.components.cards.ProductCardHorizontal
import com.mass.marketplace.presentation.ui.components.glassmorphic.GlassmorphicCard
import com.mass.marketplace.presentation.ui.components.loading.LoadingOverlay
import com.mass.marketplace.presentation.ui.screens.home.Product
import com.mass.marketplace.presentation.ui.theme.*
import com.mass.marketplace.presentation.ui.utils.SetupEdgeToEdge
import org.koin.androidx.compose.koinViewModel

enum class ProductViewType {
    GRID, LIST
}

enum class ProductSortType(val displayName: String) {
    PRICE_LOW_HIGH("Precio: Menor a Mayor"),
    PRICE_HIGH_LOW("Precio: Mayor a Menor"),
    RATING("Mejor Calificados"),
    DISTANCE("Más Cercanos"),
    NEWEST("Más Recientes")
}

data class ProductFilters(
    val priceRange: ClosedFloatingPointRange<Float> = 0f..1000f,
    val minRating: Int = 0,
    val maxDistance: Float = 50f,
    val searchQuery: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductsScreen(
    category: String,
    onNavigateBack: () -> Unit,
    viewModel: ProductsViewModel = koinViewModel(),
    cartViewModel: CartViewModel = koinViewModel()
) {
    SetupEdgeToEdge()

    var viewType by remember { mutableStateOf(ProductViewType.GRID) }
    var sortType by remember { mutableStateOf(ProductSortType.PRICE_LOW_HIGH) }
    var showFilters by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var isVisible by remember { mutableStateOf(false) }
    var filters by remember { mutableStateOf(ProductFilters()) }

    val uiState by viewModel.uiState.collectAsState()
    val cartUiState by cartViewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(category) {
        isVisible = true
        viewModel.loadProducts(category)
    }

    // Aplicar filtros y ordenamiento
    val filteredAndSortedProducts = remember(sortType, uiState.filteredProducts, filters) {
        var products = uiState.filteredProducts

        // Aplicar filtros
        products = products.filter { product ->
            val matchesPrice = product.price in filters.priceRange
            val matchesRating = filters.minRating == 0 || product.rating >= filters.minRating
            val matchesDistance = filters.maxDistance >= 50f ||
                    (product.distance.replace(" km", "").toFloatOrNull() ?: 0f) <= filters.maxDistance
            val matchesSearch = filters.searchQuery.isEmpty() ||
                    product.name.contains(filters.searchQuery, ignoreCase = true) ||
                    product.store.contains(filters.searchQuery, ignoreCase = true)

            matchesPrice && matchesRating && matchesDistance && matchesSearch
        }

        // Aplicar ordenamiento
        when (sortType) {
            ProductSortType.PRICE_LOW_HIGH -> products.sortedBy { it.price }
            ProductSortType.PRICE_HIGH_LOW -> products.sortedByDescending { it.price }
            ProductSortType.RATING -> products.sortedByDescending { it.rating }
            ProductSortType.DISTANCE -> products.sortedBy {
                it.distance.replace(" km", "").toFloatOrNull() ?: 0f
            }
            ProductSortType.NEWEST -> products.shuffled()
        }
    }

    // Loading overlay
    LoadingOverlay(
        isVisible = uiState.isLoading && uiState.products.isEmpty(),
        message = "Cargando productos..."
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            MassOrange.copy(alpha = 0.05f),
                            Color.White,
                            MassBlue.copy(alpha = 0.03f)
                        )
                    )
                )
        ) {
            // Top App Bar con indicador de carrito
            ProductsTopBar(
                category = getCategoryDisplayName(category),
                productCount = filteredAndSortedProducts.size,
                cartItemCount = cartUiState.items.sumOf { it.quantity },
                viewType = viewType,
                sortType = sortType,
                showSearch = showSearch,
                searchQuery = filters.searchQuery,
                onNavigateBack = onNavigateBack,
                onViewTypeChange = { viewType = it },
                onSortTypeChange = { sortType = it },
                onShowFilters = { showFilters = true },
                onToggleSearch = { showSearch = !showSearch },
                onSearchQueryChange = { query ->
                    filters = filters.copy(searchQuery = query)
                },
                isVisible = isVisible
            )

            // Content
            when {
                uiState.isLoading && uiState.products.isNotEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = MassOrange)
                    }
                }
                uiState.errorMessage != null -> {
                    ErrorState(
                        message = uiState.errorMessage!!,
                        onRetry = { viewModel.retryLoadProducts() },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                filteredAndSortedProducts.isEmpty() && !uiState.isLoading -> {
                    EmptyProductsState(
                        category = getCategoryDisplayName(category),
                        hasFilters = filters.let {
                            it.searchQuery.isNotEmpty() || it.minRating > 0 ||
                                    it.priceRange != 0f..1000f || it.maxDistance < 50f
                        },
                        onRetry = { viewModel.retryLoadProducts() },
                        onClearFilters = { filters = ProductFilters() },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    when (viewType) {
                        ProductViewType.GRID -> {
                            ProductsGrid(
                                products = filteredAndSortedProducts,
                                isVisible = isVisible,
                                onAddToCart = { cartItem ->
                                    cartViewModel.addToCart(cartItem)
                                }
                            )
                        }
                        ProductViewType.LIST -> {
                            ProductsList(
                                products = filteredAndSortedProducts,
                                isVisible = isVisible,
                                onAddToCart = { cartItem ->
                                    cartViewModel.addToCart(cartItem)
                                }
                            )
                        }
                    }
                }
            }
        }

        // Snackbar Host
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.TopCenter)
                .padding(46.dp)
        )

        // Floating Cart Button (solo si hay items)
        if (cartUiState.items.isNotEmpty()) {
            FloatingCartButton(
                itemCount = cartUiState.items.sumOf { it.quantity },
                total = cartUiState.total,
                onCartClick = onNavigateBack, // Navegar al carrito
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(46.dp)
            )
        }
    }

    // Filters Bottom Sheet
    if (showFilters) {
        FiltersBottomSheet(
            currentFilters = filters,
            onFiltersChanged = { newFilters ->
                filters = newFilters
            },
            onDismiss = { showFilters = false }
        )
    }

    // Mostrar feedback cuando se agrega al carrito
    LaunchedEffect(cartUiState.items.size) {
        if (cartUiState.items.isNotEmpty()) {
            val lastItem = cartUiState.items.lastOrNull()
            lastItem?.let {
                snackbarHostState.showSnackbar(
                    message = "${it.productName} agregado al carrito",
                    duration = SnackbarDuration.Short
                )
            }
        }
    }

    // Error handling del carrito
    cartUiState.errorMessage?.let { error ->
        LaunchedEffect(error) {
            snackbarHostState.showSnackbar(
                message = error,
                duration = SnackbarDuration.Short
            )
            cartViewModel.clearError()
        }
    }

    // Clear error after showing
    LaunchedEffect(uiState.errorMessage) {
        if (uiState.errorMessage != null) {
            kotlinx.coroutines.delay(5000)
            viewModel.clearError()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductsTopBar(
    category: String,
    productCount: Int,
    cartItemCount: Int,
    viewType: ProductViewType,
    sortType: ProductSortType,
    showSearch: Boolean,
    searchQuery: String,
    onNavigateBack: () -> Unit,
    onViewTypeChange: (ProductViewType) -> Unit,
    onSortTypeChange: (ProductSortType) -> Unit,
    onShowFilters: () -> Unit,
    onToggleSearch: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    isVisible: Boolean
) {
    var showSortMenu by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current

    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(alpha)
            .background(Color.White)
            .padding(16.dp)
    ) {
        // Main toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Back button and title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MassOrange.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Volver",
                        tint = MassOrange
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = category,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MassBlue
                        ),
                        maxLines = 1
                    )
                    if (productCount > 0) {
                        Text(
                            text = "$productCount productos",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.Gray
                            )
                        )
                    }
                }
            }

            // Action buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // View type toggle
                IconButton(
                    onClick = {
                        onViewTypeChange(
                            if (viewType == ProductViewType.GRID) ProductViewType.LIST
                            else ProductViewType.GRID
                        )
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MassBlue.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = if (viewType == ProductViewType.GRID) Icons.AutoMirrored.Filled.List
                        else Icons.Default.Menu,
                        contentDescription = "Cambiar vista",
                        tint = MassBlue
                    )
                }

                // Search button
                IconButton(
                    onClick = onToggleSearch,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (showSearch) MassYellow.copy(alpha = 0.3f)
                            else MassYellow.copy(alpha = 0.1f)
                        )
                ) {
                    Icon(
                        imageVector = if (showSearch) Icons.Default.Close else Icons.Default.Search,
                        contentDescription = if (showSearch) "Cerrar búsqueda" else "Buscar",
                        tint = MassYellow
                    )
                }
            }
        }

        // Search bar
        if (showSearch) {
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar productos...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = MassYellow
                    )
                },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Limpiar",
                                tint = Color.Gray
                            )
                        }
                    }
                } else null,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = { keyboardController?.hide() }
                ),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MassYellow,
                    cursorColor = MassYellow
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filter and sort buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Sort button with dropdown
            Box(
                modifier = Modifier.weight(1f)
            ) {
                OutlinedButton(
                    onClick = { showSortMenu = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MassBlue
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Ordenar",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Ordenar",
                        fontSize = 14.sp
                    )
                }

                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false }
                ) {
                    ProductSortType.entries.forEach { sort ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = sort.displayName,
                                    color = if (sort == sortType) MassOrange else Color.Black
                                )
                            },
                            onClick = {
                                onSortTypeChange(sort)
                                showSortMenu = false
                            },
                            leadingIcon = if (sort == sortType) {
                                {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MassOrange
                                    )
                                }
                            } else null
                        )
                    }
                }
            }

            // Filter button
            OutlinedButton(
                onClick = onShowFilters,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MassOrange
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Filtros",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Filtros",
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun ProductsGrid(
    products: List<Product>,
    isVisible: Boolean,
    onAddToCart: (CartItem) -> Unit
) {
    LazyVerticalStaggeredGrid(
        columns = StaggeredGridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalItemSpacing = 12.dp
    ) {
        items(products) { product ->
            ProductCard(
                product = product,
                onClick = {
                    println("Producto clickeado: ${product.name}")
                    /* Navigate to product detail */
                },
                onAddToCart = onAddToCart
            )
        }
    }
}

@Composable
private fun ProductsList(
    products: List<Product>,
    isVisible: Boolean,
    onAddToCart: (CartItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(products) { product ->
            ProductCardHorizontalWithCart(
                product = product,
                onClick = {
                    println("Producto clickeado: ${product.name}")
                    /* Navigate to product detail */
                },
                onAddToCart = onAddToCart
            )
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun ProductCardHorizontalWithCart(
    product: Product,
    onClick: () -> Unit,
    onAddToCart: (CartItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }
    var isAddingToCart by remember { mutableStateOf(false) }
    var showAddedToCart by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "scale"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
            .scale(scale)
            .clickable() {
                isPressed = true
                onClick()
            },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Product image
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                MassOrange.copy(alpha = 0.1f),
                                MassBlue.copy(alpha = 0.1f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    placeholder = rememberVectorPainter(Icons.Default.ShoppingCart),
                    error = rememberVectorPainter(Icons.Default.Clear),
                    fallback = rememberVectorPainter(Icons.Default.Warning)
                )

                if (product.imageUrl.isBlank()) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Sin imagen",
                        modifier = Modifier.size(48.dp),
                        tint = Color.Gray
                    )
                }

                // Success feedback overlay
                if (showAddedToCart) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(40.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(SuccessColor.copy(alpha = 0.9f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Agregado",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Product info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MassBlue
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = product.store,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Gray
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rating",
                        tint = MassYellow,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = product.rating.toString(),
                        style = MaterialTheme.typography.labelSmall
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = product.distance,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.Gray
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "S/.${String.format("%.2f", product.price)}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassOrange
                    )
                )
            }

            // Add to cart button
            IconButton(
                onClick = {
                    if (!isAddingToCart) {
                        isAddingToCart = true

                        val cartItem = CartItem(
                            productId = product.id,
                            productName = product.name,
                            productImage = product.imageUrl,
                            unitPrice = product.price,
                            quantity = 1,
                            store = product.store,
                            maxStock = product.stock.coerceAtLeast(1)
                        )

                        onAddToCart(cartItem)
                        showAddedToCart = true
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        if (isAddingToCart) Color.Gray
                        else MassOrange
                    ),
                enabled = !isAddingToCart
            ) {
                if (isAddingToCart) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Agregar al carrito",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    // Reset states
    LaunchedEffect(isPressed) {
        if (isPressed) {
            kotlinx.coroutines.delay(100)
            isPressed = false
        }
    }

    LaunchedEffect(showAddedToCart) {
        if (showAddedToCart) {
            kotlinx.coroutines.delay(1500)
            showAddedToCart = false
            isAddingToCart = false
        }
    }
}

@SuppressLint("DefaultLocale")
@Composable
private fun FloatingCartButton(
    itemCount: Int,
    total: Double,
    onCartClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier,
        alpha = 0.9f,
        cornerRadius = 28.dp,
        onClick = onCartClick
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = "Carrito",
                    tint = MassOrange,
                    modifier = Modifier.size(24.dp)
                )

                // Badge
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .background(ErrorColor, CircleShape)
                        .align(Alignment.TopEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (itemCount > 9) "9+" else itemCount.toString(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            Column {
                Text(
                    text = "$itemCount ${if (itemCount == 1) "producto" else "productos"}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray
                    )
                )
                Text(
                    text = "S/.${String.format("%.2f", total)}",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )
            }
        }
    }
}

@Composable
private fun ErrorState(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "⚠️",
                fontSize = 64.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Error al cargar productos",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.Gray
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            MassButton(
                text = "Reintentar",
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun EmptyProductsState(
    category: String,
    hasFilters: Boolean,
    onRetry: () -> Unit,
    onClearFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (hasFilters) "🔍" else "📦",
                fontSize = 64.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (hasFilters) "Sin resultados" else "No hay productos",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (hasFilters) {
                    "No se encontraron productos que coincidan con los filtros aplicados"
                } else if (category == "Todos los productos") {
                    "No se encontraron productos disponibles"
                } else {
                    "No hay productos disponibles en la categoría $category"
                },
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.Gray
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            if (hasFilters) {
                MassButton(
                    text = "Limpiar filtros",
                    onClick = onClearFilters,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            OutlinedButton(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MassBlue
                )
            ) {
                Text("Actualizar")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FiltersBottomSheet(
    currentFilters: ProductFilters,
    onFiltersChanged: (ProductFilters) -> Unit,
    onDismiss: () -> Unit
) {
    var tempFilters by remember { mutableStateOf(currentFilters) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filtros",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MassBlue
                    )
                )

                TextButton(
                    onClick = {
                        tempFilters = ProductFilters()
                    }
                ) {
                    Text(
                        text = "Limpiar",
                        color = MassOrange
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Price range
            Text(
                text = "Rango de precio",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold
                )
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "S/.${tempFilters.priceRange.start.toInt()} - S/.${tempFilters.priceRange.endInclusive.toInt()}",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MassOrange
                )
            )

            RangeSlider(
                value = tempFilters.priceRange,
                onValueChange = { range ->
                    tempFilters = tempFilters.copy(priceRange = range)
                },
                valueRange = 0f..1000f,
                colors = SliderDefaults.colors(
                    thumbColor = MassOrange,
                    activeTrackColor = MassOrange
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Rating filter
            Text(
                text = "Calificación mínima",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold
                )
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                FilterChip(
                    onClick = { tempFilters = tempFilters.copy(minRating = 0) },
                    label = { Text("Todas") },
                    selected = tempFilters.minRating == 0,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MassOrange.copy(alpha = 0.2f),
                        selectedLabelColor = MassOrange
                    )
                )

                (1..5).forEach { rating ->
                    FilterChip(
                        onClick = { tempFilters = tempFilters.copy(minRating = rating) },
                        label = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                repeat(rating) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MassYellow
                                    )
                                }
                                Text(
                                    text = "+",
                                    modifier = Modifier.padding(start = 2.dp)
                                )
                            }
                        },
                        selected = tempFilters.minRating == rating,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MassOrange.copy(alpha = 0.2f),
                            selectedLabelColor = MassOrange
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Distance filter
            Text(
                text = "Distancia máxima: ${if (tempFilters.maxDistance >= 50f) "Sin límite" else "${tempFilters.maxDistance.toInt()} km"}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold
                )
            )

            Slider(
                value = tempFilters.maxDistance,
                onValueChange = { distance ->
                    tempFilters = tempFilters.copy(maxDistance = distance)
                },
                valueRange = 1f..50f,
                steps = 49,
                colors = SliderDefaults.colors(
                    thumbColor = MassBlue,
                    activeTrackColor = MassBlue
                )
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Apply button
            MassButton(
                text = "Aplicar filtros",
                onClick = {
                    onFiltersChanged(tempFilters)
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

private fun getCategoryDisplayName(category: String): String {
    return when (category.lowercase()) {
        "all" -> "Todos los productos"
        "electronics" -> "Electrónicos"
        "fashion" -> "Moda"
        "food" -> "Comida"
        "home" -> "Hogar"
        "sports" -> "Deportes"
        else -> category.replaceFirstChar { it.uppercase() }
    }
}