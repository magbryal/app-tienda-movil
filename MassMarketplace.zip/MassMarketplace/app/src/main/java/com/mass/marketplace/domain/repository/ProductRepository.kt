package com.mass.marketplace.domain.repository

import com.mass.marketplace.presentation.ui.screens.home.Product

interface ProductRepository {
    suspend fun getProducts(): Result<List<Product>>
}
