package com.mass.marketplace.domain.usecase.cart

import com.mass.marketplace.domain.model.CartItem
import com.mass.marketplace.domain.repository.CartRepository

class AddToCartUseCase(
    private val cartRepository: CartRepository
) {
    suspend operator fun invoke(item: CartItem) {
        cartRepository.addToCart(item)
    }
}
