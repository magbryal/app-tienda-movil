package com.mass.marketplace.domain.usecase.cart

import com.mass.marketplace.domain.repository.CartRepository

class GetCartItemsUseCase(
    private val cartRepository: CartRepository
) {
    operator fun invoke() = cartRepository.getCartItems()
}