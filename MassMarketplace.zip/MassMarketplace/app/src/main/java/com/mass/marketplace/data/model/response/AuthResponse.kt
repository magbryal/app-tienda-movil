package com.mass.marketplace.data.model.response

data class AuthResponse(
    val message: String,
    val token: String? = null,
    val user: UserResponse? = null,

    val isRegistration: Boolean = false
)
data class UserResponse(
    val id: Int,
    val name: String,
    val email: String,
    val phone: String? = null,
    val address: String? = null
)
