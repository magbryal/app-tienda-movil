package com.mass.marketplace.domain.usecase.cart

import com.mass.marketplace.domain.repository.CartRepository

class UpdateCartQuantityUseCase(
    private val cartRepository: CartRepository
) {
    suspend operator fun invoke(productId: Int, quantity: Int) {
        cartRepository.updateQuantity(productId, quantity)
    }
}