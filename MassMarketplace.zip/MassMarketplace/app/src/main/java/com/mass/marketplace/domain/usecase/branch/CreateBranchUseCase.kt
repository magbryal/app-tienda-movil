package com.mass.marketplace.domain.usecase.branch

import com.mass.marketplace.domain.model.Branch
import com.mass.marketplace.domain.repository.BranchRepository

class CreateBranchUseCase(
    private val branchRepository: BranchRepository
) {
    suspend operator fun invoke(branch: Branch): Result<String> {
        // Validaciones de negocio
        if (branch.name.isBlank()) {
            return Result.failure(Exception("El nombre de la sucursal no puede estar vacío."))
        }

        if (branch.address.isBlank()) {
            return Result.failure(Exception("La dirección de la sucursal no puede estar vacía."))
        }

        if (branch.phone.isBlank()) {
            return Result.failure(Exception("El teléfono de la sucursal no puede estar vacío."))
        }

        // Validación de coordenadas
        if (branch.latitude < -90 || branch.latitude > 90) {
            return Result.failure(Exception("La latitud de la sucursal debe estar entre -90 y 90."))
        }

        if (branch.longitude < -180 || branch.longitude > 180) {
            return Result.failure(Exception("La longitud de la sucursal debe estar entre -180 y 180."))
        }

        return branchRepository.createBranch(branch)
    }
}