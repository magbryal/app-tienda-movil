package com.mass.marketplace.data.model.request

data class OrderRequest(
    val user_id: Int,
    val order_date: String,
    val total_amount: Double,
    val status: String,
    val payment_method: String,
    val shipping_address: String,
    val branch_id: Int,
    val payment_proof_url: String? = null
)
